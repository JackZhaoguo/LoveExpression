package com.meizu.flyme.activeview.utils;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;

public class PasswordUtils {
    private static final String BANNER_ID = "banner_id";

    /**
     * Get the pssward for extracting zip file.
     */
    public static String getZipPassward(Context context) {
        if (context == null) {
            return null;
        }
        String value = null;
        try {
            ApplicationInfo info = context.getPackageManager().getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);
            if (info != null && info.metaData != null) {
                value = info.metaData.getString(BANNER_ID);
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        return value != null ? MD5Util.MD5Encode(value) : null;
    }
}
