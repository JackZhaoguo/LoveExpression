package com.meizu.flyme.activeview.moveline;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by suyouxiong on 16-6-22.
 */
public abstract class TimelineTicker {

    private static final int DEFAULT_FRAME_DELAY = 10;
    protected static long sFrameDelay = DEFAULT_FRAME_DELAY;
    protected List<TimelineTickerListener> mListeners;

    protected TimelineTicker(){

    }
    public abstract void start();

    public abstract void stop();

    public abstract long getTime();

    public abstract boolean isActive();

    public abstract void wake();

    public void addListener(TimelineTickerListener listener) {
        if (mListeners == null) {
            mListeners = new ArrayList<>();
        }
        mListeners.add(listener);
    }

    public void removeListener(TimelineTickerListener listener) {
        if (mListeners == null) return;
        mListeners.remove(listener);
    }

    public interface TimelineTickerListener {

        void onUpdate(long time);
    }

    public abstract int getFrame();

    public static void setFrameDelay(long frameDelay) {
        sFrameDelay = frameDelay;
    }
}
