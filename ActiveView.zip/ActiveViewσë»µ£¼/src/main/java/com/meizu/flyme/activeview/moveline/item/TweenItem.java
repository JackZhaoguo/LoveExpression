package com.meizu.flyme.activeview.moveline.item;

/**
 * Created by suyouxiong on 16-6-21.
 */
public interface TweenItem {

    /**
     * 是否可执行更新
     * @return
     */
    boolean isUpdatable();

    /**
     * 更新属性值
     * @param propertyName 属性名
     * @param value 经过时间进度计算出的进度值，如果是不可计算的属性值，默认传递style中的设置值
     * @param fraction 时间进度（经过插值器处理）
     */
    void updateProperty(String propertyName, Object value, float fraction);

    /**
     * 获取属性值，在每一帧开始动画被调用，为了获取动画的初始值
     * @param propertyName
     * @return
     */
    Object getPropertyValue(String propertyName);

    /**
     * 创建一个和此动画实现对象相对应的属性样式
     *
     * @return
     */
    FrameStyle buildFrameStyle();
}
