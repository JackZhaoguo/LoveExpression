package com.meizu.flyme.activeview.moveline;

import android.animation.Animator;
import android.view.animation.Interpolator;

import com.meizu.flyme.activeview.moveline.item.FrameStyle;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by suyouxiong on 16-6-21.
 */
public abstract class Animation {
    static final int STOPPED    = 0; // Not yet playing
    static final int RUNNING    = 1; // Playing normally
    static final int SEEKED     = 2; // Seeked to some time value
    protected static TimelineTicker timelineTicker = TimelineTickerFactory.create();
    private static RootTimeline sRootTimeline = new RootTimeline();
    protected long startTime;
    protected int duration;
    protected boolean dirty;
    protected long time;
    protected boolean paused;
    protected int mPlayingState = STOPPED;
    protected long pauseTime;
    protected long delayTime;

    protected Animation next;
    protected Animation prev;

    protected BaseTimeline timeline;
    protected RootTimeline rootTimeline;
    protected boolean isActive;

    protected boolean mReversing;
    private Interpolator mInterpolator;

    private AnimationListener mAnimationListener;


    public Animation() {
        this.startTime = 0;
        this.timeline = sRootTimeline;
        this.rootTimeline = sRootTimeline;
    }

    protected abstract void update(long curTime);

    public int getDuration() {
        return duration;
    }

    protected void setActive(boolean active) {
        this.isActive = active;
    }

    public Interpolator getInterpolator() {
        return mInterpolator;
    }

    public void setInterpolator(Interpolator interpolator) {
        mInterpolator = interpolator;
    }

    public AnimationListener getAnimationListener() {
        return mAnimationListener;
    }

    /**
     *
     * @param animationListener
     * @deprecated use {@link #addListener(AnimationListener)} instead
     */
    public void setAnimationListener(AnimationListener animationListener) {
        mAnimationListener = animationListener;
    }

    public void play() {

    }

    public void stop() {

    }

    public void reverse() {

    }

    public void pause() {

    }

    public void resume() {

    }

    public boolean isPaused() {
        return paused;
    }

    public boolean isActive() {
        return isActive;
    }

    protected ArrayList<AnimationListener> mListeners = new ArrayList<>();

    public void addListener(AnimationListener listener) {
        mListeners.add(listener);
    }

    protected void notifyStartListeners() {
        if (mListeners != null) {
            ArrayList<AnimationListener> tmpListeners =
                    (ArrayList<AnimationListener>) mListeners.clone();
            int numListeners = tmpListeners.size();
            for (int i = 0; i < numListeners; ++i) {
                tmpListeners.get(i).onAnimationStart(this);
            }
        }
    }

    protected void notifyEndListeners() {
        if (mListeners != null) {
            ArrayList<AnimationListener> tmpListeners =
                    (ArrayList<AnimationListener>) mListeners.clone();
            int numListeners = tmpListeners.size();
            for (int i = 0; i < numListeners; ++i) {
                tmpListeners.get(i).onAnimationEnd(this);
            }
        }
    }

    public FrameStyle getFrameStyle() {
        return null;
    }

    protected abstract void initAnimationValue();

    /**
     * 设置延迟
     * @param time
     */
    public void setDelayTime(int time) {
        delayTime = time;
    }
}
