package com.meizu.flyme.activeview.json;

/**
 * Created by meizu on 16/7/22.
 */
public class Args {
    private final static int PATH_ARRAY_LENGTH = 4;

    private float frequency;
    private float[] path = new float[PATH_ARRAY_LENGTH];

    public Args() {}

    public float[] getPath() {
        return path;
    }

    public void setPath(float[] path) {
        if (path.length != PATH_ARRAY_LENGTH) {
            return;
        }
        this.path = path;
    }

    public void setFrequency(float frq) {
        frequency = frq;
    }

    public float getFrequency() {
        return frequency;
    }
}
