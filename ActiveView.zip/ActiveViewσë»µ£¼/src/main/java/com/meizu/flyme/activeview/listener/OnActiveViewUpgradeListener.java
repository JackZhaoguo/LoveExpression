package com.meizu.flyme.activeview.listener;

/**
 * Created by meizu on 16/10/22.
 */
public interface OnActiveViewUpgradeListener {
    // result state
    int UPGRADE_STATE_FAIL = 0x00;
    int UPGRADE_STATE_SUCCESS = 0x01;
    // download update file
    int UPGRADE_JAR_FILE_DOWNLOAD = 0x07;

    void onUpgradeFinished(int type, int state, String result);
}
