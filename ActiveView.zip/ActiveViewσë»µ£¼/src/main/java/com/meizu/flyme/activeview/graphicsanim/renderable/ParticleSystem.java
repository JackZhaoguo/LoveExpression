package com.meizu.flyme.activeview.graphicsanim.renderable;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.util.Log;

import com.meizu.flyme.activeview.graphicsanim.utils.MathHelper;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * 该类主要用于生成粒子效果：
 * 1）根据时间周期发射粒子，每个周期可发射多个粒子
 * 2）根据粒子移动的绝对距离决定是否超出范围，超出范围则移除粒子
 * 3）每个粒子的速度是根据速度基数加上随机速度偏移值得出每个粒子的最终速度，所以每一个粒子的速度不一样
 * 4）每个粒子的起始位置是根据起始点坐标加上XY轴随机偏移值得出每个粒子的最终的起始位置，所以每一个粒子的起始位置不一样
 */
public class ParticleSystem extends Renderable {

    public static final String TAG = "ParticleSystem";

    public static String CLASS_NAME = ParticleSystem.class.getSimpleName();

    /**
     * 粒子类型
     * 参数类型： String
     * 取值范围： {@link #TYPE_BITMAP}、{@link #TYPE_CIRCLE}、{@link #TYPE_RECT}
     */
    public static final String ATTR_TYPE = "particleType";

    /**
     * 粒子起点坐标偏移范围
     * 参数类型： float
     */
    public static final String ATTR_RANDOM_POS_X = "randomOutsetX";
    public static final String ATTR_RANDOM_POS_Y = "randomOutsetY";

    /*
     * 粒子方向速度
     * 参数类型： float
     */
    public static final String ATTR_SPEED_X = "speedX";
    public static final String ATTR_SPEED_Y = "speedY";

    /**
     * 粒子方向速度偏移范围
     * 参数类型： float
     */
    public static final String ATTR_RANDOM_SPEED_X = "randomSpeedX";
    public static final String ATTR_RANDOM_SPEED_Y = "randomSpeedY";

    /**
     * 粒子生成最短周期，最小值16
     * 参数类型： int
     */
    public static final String ATTR_TRANSMIT_CYCLE = "transmitCycle";


    /**
     * 每个周期生成粒子个数
     * 参数类型： int
     */
    public static final String ATTR_TRANSMIT_NUM = "transmitNum";

    /**
     * 粒子飘移范围，以起点为中心的圆形区域
     * 参数类型：float
     */
    public static final String ATTR_REGION_RADIUS = "regionRadius";

    /**
     * 粒子宽度
     * 参数类型：float[]
     */
    public static final String ATTR_PARTICLE_WIDTH = "particleWidth";

    /**
     * 粒子高度
     * 参数类型：float[]
     */
    public static final String ATTR_PARTICLE_HEIGHT = "particleHeight";

    /**
     * 粒子颜色数组
     * 参数类型：int[]
     */
    public static final String ATTR_COLOR_LIST = "colorList";

    /**
     * 位图路径
     * 参数类型：String
     */
    public static final String ATTR_BITMAP_PATH = "bitmapPath";

    //粒子类型
    public static final String TYPE_BITMAP = "image";
    public static final String TYPE_CIRCLE = "circle";
    public static final String TYPE_RECT = "rect";

    private static final int DURATION = 2000;

    private static final float DEFAULT_SIZE = 15;

    private boolean mIsDebugDraw = false;

    private Paint mParticlePaint;

    @Override
    public void setTranslationY(Float translationY) {
        super.setTranslationY(translationY);
    }

    //上次发射粒子时间
    private long mLastTransmitTime;

    //粒子发射时间间隔
    private int mTransmitCycle;
    private int mTransmitNum;

    private float mSpeedY;
    private float mSpeedX;

    //粒子飘移高度
    private float mFloatingRegionRadius;

    private float mRandomSpeedX;
    private float mRandomSpeedY;

    private float mRandomOffsetX;
    private float mRandomOffsetY;

    private int mRandomMovementChangeInterval = 5000;

    private ValueAnimator mColorAnimator, mWidthAnimator, mHeightAnimator;

    private float mParticleWidth;

    private float mParticleHeight;

    private List<Particle> mParticles = new ArrayList<Particle>();

    private List<Particle> mParticlesPool = new ArrayList<Particle>();

    private String mBitmapPath;

    private String mParticleType;

    private RectF mDrawRect = new RectF();

    public ParticleSystem(Bundle bundle) {
        super(bundle);
    }

    @Override
    protected void init() {
        super.init();

        mTransmitCycle = 100;
        mTransmitNum = 1;
        mSpeedY = 100;
        mSpeedX = 100;
        mFloatingRegionRadius = 100;
        mParticleType = TYPE_RECT;
        mParticleWidth = DEFAULT_SIZE;
        mParticleHeight = DEFAULT_SIZE;

        mParticlePaint = new Paint();
    }


    @Override
    public void updateAttributes(Bundle bundle) {
        super.updateAttributes(bundle);
        if (bundle != null) {
            mTransmitCycle = bundle.getInt(ATTR_TRANSMIT_CYCLE, mTransmitCycle);
            mTransmitNum = bundle.getInt(ATTR_TRANSMIT_NUM, mTransmitNum);

            mSpeedY = bundle.getFloat(ATTR_SPEED_Y, mSpeedY);
            mSpeedX = bundle.getFloat(ATTR_SPEED_X, mSpeedX);

            mRandomOffsetX = bundle.getFloat(ATTR_RANDOM_POS_X, mRandomOffsetX);
            mRandomOffsetY = bundle.getFloat(ATTR_RANDOM_POS_Y, mRandomOffsetY);

            mRandomSpeedX = bundle.getFloat(ATTR_RANDOM_SPEED_X, mRandomSpeedX);
            mRandomSpeedY = bundle.getFloat(ATTR_RANDOM_SPEED_Y, mRandomOffsetY);

            mFloatingRegionRadius = bundle.getFloat(ATTR_REGION_RADIUS, mFloatingRegionRadius);

            mParticleType = bundle.getString(ATTR_TYPE, mParticleType);
            if (mParticleType.equals(TYPE_BITMAP)) {
                mBitmapPath = bundle.getString(ATTR_BITMAP_PATH);
                if (new File(mBitmapPath).exists() && new File(mBitmapPath).canRead()) {
                    mBitmap = BitmapFactory.decodeFile(mBitmapPath);
                } else {
                    Log.d(TAG, "can not found bitmap file : " + mBitmapPath);
                }
            }

            int[] colors = bundle.getIntArray(ATTR_COLOR_LIST);
            if (colors != null) {
                setColors(colors);
            }

            float[] particleWidths = bundle.getFloatArray(ATTR_PARTICLE_WIDTH);
            if (particleWidths != null) {
                setParticleWidth(particleWidths);
            }

            float[] particleHeights = bundle.getFloatArray(ATTR_PARTICLE_HEIGHT);
            if (particleHeights != null) {
                setParticleHeight(particleHeights);
            }
        }
    }

    @Override
    public void draw(Canvas canvas) {
        for (int i = 0; i < mParticles.size(); i++) {
            Particle p = mParticles.get(i);
            calculateParticlePaintColor(p);
            calculateParticleSize(p);
            mDrawRect.set(p.x, p.y, p.x + p.width, p.y + p.height);

            if (TYPE_CIRCLE.equals(mParticleType)) {

                canvas.drawOval(mDrawRect, mParticlePaint);
            } else if (TYPE_RECT.equals(mParticleType)) {
                canvas.drawRect(mDrawRect, mParticlePaint);
            } else if (TYPE_BITMAP.equals(mParticleType)) {
                if (mBitmap != null) {
                    canvas.drawBitmap(mBitmap, null, mDrawRect, mParticlePaint);
                }
            }
        }
    }

    @Override
    public void update(float deltaTime) {
        long currentTimeMillis = System.currentTimeMillis();
        if (mLastTransmitTime + mTransmitCycle < currentTimeMillis) {
            mLastTransmitTime = currentTimeMillis;
            addParticle();
        }
        for (int i = 0; i < mParticles.size(); i++) {
            Particle particle = mParticles.get(i);
            particle.y += mSpeedY * deltaTime;
            particle.y += particle.randomSpeedY * deltaTime;
            particle.x += particle.randomSpeedX * deltaTime;
            particle.x += mSpeedX * deltaTime;

            /*if (particle.lastRandomSizeChange + mRandomMovementChangeInterval < currentTimeMillis) {
                particle.lastRandomSizeChange = System.currentTimeMillis();
                particle.setRandomSpeed(MathHelper.randomRange(-mRandomSpeedX, mRandomSpeedX), MathHelper.randomRange(-mRandomSpeedY, mRandomSpeedY));
            }*/

            particle.moveDistance = getAbsoluteDistance(particle.startX, particle.startY, particle.x, particle.y);
            if (particle.moveDistance > mFloatingRegionRadius) {
                mParticles.remove(i);
                i--;
                mParticlesPool.add(particle);
            }

            if (mIsDebugDraw) {
                if (i == 0) {
                    Log.i(TAG, "\n\n");
                    Log.i(TAG, " ------ particle0 move ----- ");
                    Log.i(TAG, "update particle0: " + "deltaTime: " + deltaTime);
                    Log.i(TAG, "update particle0: " + "mSpeedY: " + mSpeedY + "    moveUp: " + mSpeedY * deltaTime);
                    Log.i(TAG, "update particle0: " + "randomSpeedY: " + particle.randomSpeedY + "    moveY: " + particle.randomSpeedY * deltaTime);
                    Log.i(TAG, "update particle0: " + "randomSpeedX: " + particle.randomSpeedX + "    moveX: " + particle.randomSpeedX * deltaTime);
                    Log.i(TAG, "update particle0: " + "wind: " + mSpeedX + "    windMove: " + mSpeedX * deltaTime);
                    Log.i(TAG, "update particle0: " + "mY: " + mY + "    particle.y: " + particle.y);
                    Log.i(TAG, "update particle0: " + "mFloatingRegionRadius: " + mFloatingRegionRadius);
                    Log.i(TAG, " ------ particle0 end ----- ");
                    Log.i(TAG, "\n\n");
                }
            }
        }
    }

    /**
     * 生成粒子
     */
    private void addParticle() {
        for (int i = 0; i < mTransmitNum; i++) {
            Particle particle;
            float x = mX + MathHelper.randomRange(-mRandomOffsetX, mRandomOffsetX);
            float y = mY + MathHelper.randomRange(-mRandomOffsetY, mRandomOffsetY);
            if (mParticlesPool.size() > 0) {
                particle = mParticlesPool.remove(0);
                particle.x = x;
                particle.y = y;
            } else {
                particle = new Particle(x, y, MathHelper.randomRange(-mRandomSpeedX, mRandomSpeedX), MathHelper.randomRange(-mRandomSpeedY, mRandomSpeedY));
            }
            mParticles.add(particle);

        }
    }

    /**
     * 求两个点绝对距离
     *
     * @param x1
     * @param y1
     * @param x2
     * @param y2
     * @return
     */
    private float getAbsoluteDistance(float x1, float y1, float x2, float y2) {
        float deltaX = Math.abs(x1 - x2);
        float deltaY = Math.abs(y1 - y2);
        return (float) Math.sqrt(Math.pow(deltaX, 2) + Math.pow(deltaY, 2));
    }

    /**
     * 根据粒子位置计算粒子颜色
     *
     * @param particle
     */
    private void calculateParticlePaintColor(Particle particle) {
        if (mColorAnimator != null) {
            float travelDistanceInPercentOfMax = particle.moveDistance / mFloatingRegionRadius;
            mColorAnimator.setCurrentPlayTime((long) (DURATION * travelDistanceInPercentOfMax));
            int color = (Integer) mColorAnimator.getAnimatedValue();
            mParticlePaint.setColor(color);
        }
    }


    /**
     * 计算粒子大小
     *
     * @param particle
     */
    private void calculateParticleSize(Particle particle) {

        float travelDistanceInPercentOfMax = particle.moveDistance / mFloatingRegionRadius;

        if (mWidthAnimator != null) {
            mWidthAnimator.setCurrentPlayTime((long) (DURATION * travelDistanceInPercentOfMax));
            particle.width = (Float) mWidthAnimator.getAnimatedValue();
        } else {
            particle.width = mParticleWidth;
        }

        if (mHeightAnimator != null) {
            mHeightAnimator.setCurrentPlayTime((long) (DURATION * travelDistanceInPercentOfMax));
            particle.height = (Float) mHeightAnimator.getAnimatedValue();
        } else {
            particle.height = mParticleHeight;
        }
    }


    /**
     * 设置粒子颜色，多个颜色可渐变
     *
     * @param colors
     */
    public void setColors(int... colors) {
        if (colors.length == 1) {
            mParticlePaint.setColor(colors[0]);
        } else if (colors.length > 1) {
            mColorAnimator = ValueAnimator.ofInt(colors).setDuration(DURATION);
            mColorAnimator.setEvaluator(new ArgbEvaluator());
        }
    }

    /**
     * 粒子宽度
     *
     * @param widths
     */
    public void setParticleWidth(float... widths) {
        if (widths.length == 1) {
            mParticleWidth = widths[0];
        } else if (widths.length > 1) {
            mWidthAnimator = ValueAnimator.ofFloat(widths).setDuration(DURATION);
        }

    }

    /**
     * 粒子高度
     *
     * @param heights
     */
    public void setParticleHeight(float... heights) {
        if (heights.length == 1) {
            mParticleHeight = heights[0];
        } else if (heights.length > 1) {
            mHeightAnimator = ValueAnimator.ofFloat(heights).setDuration(DURATION);
        }

    }

    /**
     * Y轴速度随机偏移范围【-randomSpeedY， randomSpeedY】
     *
     * @param randomSpeedY
     */
    public void setRandomSpeedY(float randomSpeedY) {
        this.mRandomSpeedY = randomSpeedY;
    }

    /**
     * X轴速度随机偏移范围【-randomSpeedX， randomSpeedX】
     *
     * @param randomSpeedX
     */
    public void setRandomSpeedX(float randomSpeedX) {
        this.mRandomSpeedX = randomSpeedX;
    }


    /**
     * 粒子发射周期
     *
     * @param cycle
     */
    public void setTransmitCycle(int cycle) {
        mTransmitCycle = cycle;
    }

    /**
     * 每个周期粒子发射的个数
     *
     * @param num
     */
    public void setTransmitNum(int num) {
        mTransmitNum = num;
    }

    /**
     * 粒子在Y轴上的速度
     *
     * @param speedY
     */
    public void setSpeedY(float speedY) {
        mSpeedY = speedY;
    }

    /**
     * 粒子在X轴上的速度
     *
     * @param speedX
     */
    public void setSpeedX(float speedX) {
        mSpeedX = speedX;
    }


    /**
     * 粒子飘移范围半径
     *
     * @param floatingRegionRadius
     */
    public void setFloatingRegionRadius(float floatingRegionRadius) {
        mFloatingRegionRadius = floatingRegionRadius;
    }


    /**
     * 粒子起始坐标Y偏移量【-randomOffsetX，randomOffsetX】
     *
     * @param randomOffsetX
     */
    public void setRandomOffsetX(float randomOffsetX) {
        mRandomOffsetX = randomOffsetX;
    }


    /**
     * 粒子起始坐标Y偏移量【-randomOffsetY，randomOffsetY】
     *
     * @param randomOffsetY
     */
    public void setRandomOffsetY(float randomOffsetY) {
        mRandomOffsetY = randomOffsetY;
    }


    /**
     * 位图绝对路径
     *
     * @param bitmapPath
     */
    public void setBitmapPath(String bitmapPath) {
        mBitmapPath = bitmapPath;
    }


    /**
     * 粒子样式
     * {@link #TYPE_BITMAP}、{@link #TYPE_CIRCLE}、{@link #TYPE_RECT}
     *
     * @param type
     */
    public void setParticleType(String type) {
        mParticleType = type;
    }

}
