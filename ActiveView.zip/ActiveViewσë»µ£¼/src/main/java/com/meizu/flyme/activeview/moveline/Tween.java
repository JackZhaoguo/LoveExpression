package com.meizu.flyme.activeview.moveline;

import android.util.Log;

import com.meizu.flyme.activeview.moveline.item.FrameStyle;
import com.meizu.flyme.activeview.moveline.item.TweenItem;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Created by suyouxiong on 16-6-21.
 */
public class Tween extends Animation {
    private FrameStyle mFrameStyle;
    private TweenItem mTarget;

    final private Map<String, Object> mTargetFromValues;

    public Tween(TweenItem target, int duration, FrameStyle itemStyle) {
        this.mTarget = target;
        this.duration = duration;
        this.mFrameStyle = itemStyle;
        mTargetFromValues = new HashMap<>();
    }

    @Override
    protected void update(long curTime) {
        if (Config.LOCAL_LOG) {
            Log.i(Config.MOVELINE_LOG_TAG, "Tween update:curTime=" + curTime + "; startTime = " + this.startTime);
        }
        boolean isComplete = false;
        long prevTime = this.time;
        if (curTime >= duration) {
            time = duration;
            isComplete = true;
        } else if (curTime < 0){
            time = 0;
            isComplete = true;
        } else {
            time = curTime;
        }
        if (prevTime == time) {//无变化
            return;
        }
        if (mPlayingState != RUNNING) {
            mPlayingState = RUNNING;
            notifyStartListeners();
        }
        if (!isActive) {
            isActive = true;
        }
        if (!mTarget.isUpdatable()) {//是否允许更新
            isComplete = true;
            if (Config.LOCAL_LOG) {
                Log.i(Config.MOVELINE_LOG_TAG, "Tween update:target can't be updated ");
            }
        } else {
            float fraction = time / (float)duration;

            if (getInterpolator() != null ) {
                fraction = getInterpolator().getInterpolation(fraction);
            } else if (this.timeline.getInterpolator() != null) {
                fraction = this.timeline.getInterpolator().getInterpolation(fraction);
            }

            updateFrame(fraction);
        }

        if (isComplete) {
            setActive(false);
            mPlayingState = STOPPED;
            notifyEndListeners();
        }
    }

    private void updateFrame(float fraction) {
        if (mFrameStyle != null) {
            Set<String> updateStyles = mFrameStyle.getUpdateProperties();
            if (updateStyles != null && updateStyles.size() > 0) {
                for (String property : updateStyles) {
                    FrameStyle.PropertyValueType valueType = mFrameStyle.getPropertyValueType(property);
                    Object newValue;
                    if (valueType == FrameStyle.PropertyValueType.OTHER) {//不支持计算进度值的类型，直接将帧样式传入
                        newValue = mFrameStyle.getPropertyValue(property);
                    } else {
                        Object fromValue;
                        if (!mTargetFromValues.containsKey(property)) {
                            fromValue = mTarget.getPropertyValue(property);
                            mTargetFromValues.put(property, fromValue);
                        } else {
                            fromValue = mTargetFromValues.get(property);
                        }
                        Object toValue = mFrameStyle.getPropertyValue(property);

                        if (fromValue == null || toValue == null) {
                            return;
                        }

                        if (valueType == FrameStyle.PropertyValueType.INT) {
                            int intFromValue = (int) fromValue;
                            int intToValue = (int) toValue;
                            newValue = intFromValue + (intToValue - intFromValue) * fraction;

                        } else {
                            float intFromValue = (float) fromValue;
                            float intToValue = (float) toValue;
                            newValue = intFromValue + (intToValue - intFromValue) * fraction;
                        }


                    }
                    mTarget.updateProperty(property, newValue, fraction);
                    if (Config.LOCAL_LOG) {
                        Log.i(Config.MOVELINE_LOG_TAG, "Tween updateProperty:property=" + property + "; newValue = " + newValue);
                    }
                }
            }
        }
    }

    @Override
    public FrameStyle getFrameStyle() {
        return mFrameStyle;
    }

    @Override
    protected void initAnimationValue() {
        if (mTargetFromValues.size() > 0) {
            Set<Map.Entry<String, Object>> entrySet = mTargetFromValues.entrySet();
            for (Map.Entry<String, Object> entry : entrySet) {
                String key = entry.getKey();
                Object value = entry.getValue();
                mTarget.updateProperty(key, value, 0);
            }
        }
    }
}
