package com.meizu.flyme.activeview.utils;

import android.content.Context;

import com.meizu.statsapp.UsageStatsProxy;

import java.util.Map;

/**
 * Created by meizu on 17/1/3.
 */
public class ActiveUsageStatsUtils {

    // 事件公共参数
    public static final String FILE_URL = "_file_url_";

    // 下载事件及属性
    public static final String EVENT_DOWNLOAD = "download_resource_file";

    // 热更新事件及属性
    public static final String EVENT_UPGRADE = "version_upgrade";
    public static final String UPGRADE_PROPERTY_LOCAL_VERSION = "upgrade_local_version";
    public static final String UPGRADE_PROPERTY_ACT_VERSION = "upgrade_act_file_version";
    public static final String UPGRADE_PROPERTY_JAR_VERSION = "upgrade_jar_file_version";

    // 加载事件及属性
    public static final String EVENT_LOAD_ACT_FILE = "load_act_file";

    // 加载图片事件
    public static final String EVENT_LOAD_IMAGE_FILE = "load_image_file";

    // 版本使用频率情况
    public static final String EVENT_VERSION_FREQUENCY = "version_frequency";
    public static final String VERSION_NUMBER= "version_number";

    // 控件所在应用包名
    public static final String EVENT_APP_PACKAGE_INFO = "event_app_package_info";
    public static final String APP_PACKAGE_NAME = "_app_package_name_";
    public static final String APP_PACKAGE_VERSION_NAME = "_app_package_version_name_";

    private volatile static ActiveUsageStatsUtils mActiveUsageStatsUtilsInstance = null;
    private UsageStatsProxy mUsageStatsProxy = null;

    public static ActiveUsageStatsUtils getInstance(Context context) {
        if (mActiveUsageStatsUtilsInstance == null) {
            synchronized (ImageCacheUtils.class) {
                if (mActiveUsageStatsUtilsInstance == null && context != null) {
                    mActiveUsageStatsUtilsInstance = new ActiveUsageStatsUtils(context.getApplicationContext());
                }
            }
        }
        return mActiveUsageStatsUtilsInstance;
    }

    private ActiveUsageStatsUtils(Context context) {
        if (mUsageStatsProxy == null && context != null) {
            mUsageStatsProxy = UsageStatsProxy.getOnlineInstance(context, true);
        }
    }

    public void setEnableUploaded(boolean enabled) {
        if (mUsageStatsProxy != null) {
            mUsageStatsProxy.setUploaded(enabled);
        }
    }

    public static void recordEvent(Context context, String eventName, String pageName, Map properties) {
        if (context != null) {
            ActiveUsageStatsUtils.getInstance(context).onEvent(eventName, pageName, properties);
        }
    }

    public static void recordEvent(Context context, String eventName, String pageName, String property) {
        if (context != null) {
            ActiveUsageStatsUtils.getInstance(context).onEvent(eventName, pageName, property);
        }
    }

    /**
     * 使用外部设置的UsageStatsProxy
     *
     * @param usageStatsProxy
     */
    public void setUsageStatsProxy(UsageStatsProxy usageStatsProxy) {
        mUsageStatsProxy = usageStatsProxy;
    }

    /**
     * 记录一个事件。（property的默认key为value）
     *
     * @param eventName 事件名称
     * @param pageName  事件发生的页面，可以为空
     * @param property  事件的属性，可以为空
     */

    public void onEvent(String eventName, String pageName, String property) {
        if (eventName == null || eventName.isEmpty() || mUsageStatsProxy == null) {
            return;
        }
        mUsageStatsProxy.onEvent(eventName, pageName, property);
    }

    /**
     * 记录一个事件。（property的默认key为value）
     *
     * @param eventName   事件名称
     * @param pageName    事件发生的页面，可以为空
     * @param properties  事件的属性，可以为空
     */
    public void onEvent(String eventName, String pageName, Map properties) {
        if (eventName == null || eventName.isEmpty() || mUsageStatsProxy == null) {
            return;
        }
        mUsageStatsProxy.onEvent(eventName, pageName, properties);
    }
}
