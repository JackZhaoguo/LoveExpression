package com.meizu.flyme.activeview.utils;

import android.graphics.Outline;
import android.os.Build;
import android.view.View;
import android.view.ViewOutlineProvider;

/**
 * Provide some methods to implement somo certain features.
 */
public class ActiveViewHelper {

    /**
     * Set background's Round Corner.
     * Note: Above Android 5.x has this feature.
     * @param radius    The round corner radius .
     */
    public static void setBackgroundRoundCorner(View view, final float radius) {
        if (view == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            ViewOutlineProvider viewOutlineProvider = new ViewOutlineProvider() {
                @Override
                public void getOutline(View view, Outline outline) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                    }
                }
            };
            view.setOutlineProvider(viewOutlineProvider);
            view.setClipToOutline(true);
        }
    }
}
