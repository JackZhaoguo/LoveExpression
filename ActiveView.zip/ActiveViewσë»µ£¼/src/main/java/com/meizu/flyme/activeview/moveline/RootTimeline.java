package com.meizu.flyme.activeview.moveline;

/**
 * Created by suyouxiong on 16-6-23.
 */
public final class RootTimeline extends BaseTimeline implements TimelineTicker.TimelineTickerListener{
    private int autoStop = 60;
    private int mNextSleepFrame = autoStop;

    RootTimeline() {
        super();
        startTime = timelineTicker.getTime();
        timelineTicker.addListener(this);
    }

    @Override
    public void onUpdate(long tickerTime) {

        long thisLineTime = tickerTime - startTime;
        update(thisLineTime);
    }

    @Override
    protected void update(long time) {
        Animation animation = this.first;
        while (animation != null) {
            Animation next = animation.next;
            if ((animation.isActive || time > animation.startTime) && !animation.isPaused()) {
                if (!animation.mReversing) {
                    animation.update(time - animation.startTime);
                } else {
                    animation.update(animation.getDuration() - (time - animation.startTime));
                }
            }
            animation = next;
        }

        //判断是否需要停止刷新
        if (timelineTicker.getFrame() >= mNextSleepFrame) {
            mNextSleepFrame = timelineTicker.getFrame() + autoStop;
            animation = this.first;
            if (animation == null) {
                timelineTicker.stop();
            } else {
                boolean isAllPaused = true;
                while (animation != null) {
                    if (!animation.isPaused()) {
                        isAllPaused = false;
                        break;
                    }
                    animation = animation.next;
                }
                if (isAllPaused) {
                    timelineTicker.stop();
                }
            }
        }
    }

    /**
     * 根时间线没有时长，是以时钟运行来调度其中的动画
     *
     * @return
     */
    @Override
    public int getDuration() {
        return 0;
    }
}
