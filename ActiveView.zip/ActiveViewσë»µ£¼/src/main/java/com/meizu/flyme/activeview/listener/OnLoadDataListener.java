package com.meizu.flyme.activeview.listener;

/**
 * Created by meizu on 16/9/21.
 */
public interface OnLoadDataListener {
    int LOAD_FAIL = 0x0;
    int LOAD_SUCESS = 0x1;
    // void onLoadDataResult(int result, T info);
    <T> void onLoadDataResult(int result, T t);
}
