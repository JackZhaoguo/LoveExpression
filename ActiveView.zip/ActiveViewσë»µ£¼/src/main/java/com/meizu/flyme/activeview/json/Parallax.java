package com.meizu.flyme.activeview.json;

/**
 * Created by meizu on 16/10/22.
 */
public class Parallax {
    private String type;

    private Parameter parameter;

    public Parallax() {}

    public void setType(String type){
        this.type = type;
    }
    public String getType(){
        return this.type;
    }
    public void setParameter(Parameter parameter){
        this.parameter = parameter;
    }
    public Parameter getParameter(){
        return this.parameter;
    }
}
