package com.meizu.flyme.activeview.json;

import java.util.List;

/**
 * Created by meizu on 16/9/26.
 */
public class NewElementData {
    private String id;
    private String type;
    private Data data;
    private List<Event> events;

    public NewElementData() {}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public List<Event> getEvents() {
        return events;
    }

    public void setEvents(List<Event> events) {
        this.events = events;
    }
}
