package com.meizu.flyme.activeview.listener;

/**
 * Created by meizu on 16/9/21.
 */
public interface OnJsonParserListener {
    <T> void onParseResult(T t);
}
