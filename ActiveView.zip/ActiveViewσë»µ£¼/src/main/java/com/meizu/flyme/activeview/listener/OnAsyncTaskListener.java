package com.meizu.flyme.activeview.listener;

import android.os.AsyncTask;

/**
 * Created by meizu on 16/9/21.
 */
public interface OnAsyncTaskListener {
    void onLoadFinished(AsyncTask asyncTask);
}

