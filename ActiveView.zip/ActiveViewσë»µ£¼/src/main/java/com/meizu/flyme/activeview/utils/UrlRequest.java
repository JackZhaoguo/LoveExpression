package com.meizu.flyme.activeview.utils;

import android.util.Pair;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;

public class UrlRequest {

    public static String request(String url, List<Pair<String, String>> params) {
        try {
            return requestBase(url, params);
        } catch (HttpLoadException e) {
            LogUtil.e("UrlRequest --> request Error: " + e.getMessage());
        }
        return null;
    }

    public static String requestBase(String url, List<Pair<String, String>> params) throws HttpLoadException {
        OutputStream connectOutputStream = null;
        HttpURLConnection connection = null;
        InputStream inputStream = null;
        try {
            connection = (HttpURLConnection) (new URL(url).openConnection());
            connection.setRequestProperty("User-Agent", Constants.USER_AGENT_MEIZU);
            connection.setConnectTimeout(30000);
            connection.setRequestMethod("POST");
            connection.setDoInput(true);
            connection.setDoOutput(true);
            connection.setUseCaches(false);
            connectOutputStream = connection.getOutputStream();
            connectOutputStream.write(encodePostParameters(params, Constants.UTF_8_CODE));

            int responseCode = connection.getResponseCode();
            if (responseCode == Constants.RESPONSE_CODE_OK) {
                inputStream = connection.getInputStream();
                BufferedReader br = new BufferedReader(new InputStreamReader(inputStream, Constants.UTF_8_CODE));
                StringBuffer buf = new StringBuffer();
                String line;
                while (null != (line = br.readLine())) {
                    buf.append(line).append("\n");
                }
                return buf.toString();
            } else {
                throw new HttpLoadException(responseCode, "Server response code : " + responseCode);
            }
        } catch (HttpLoadException e) {
            throw e;
        } catch (Exception e) {
            LogUtil.e("UrlRequest --> requestBase Error: " + e.getMessage());
            throw new HttpLoadException(e.getMessage());
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
                if (connectOutputStream != null) {
                    connectOutputStream.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 格式化请求参数
     * @param params 参数集合
     * @param paramsEncoding 编码格式
     * @return
     */
    public static byte[] encodePostParameters(List<Pair<String, String>> params, String paramsEncoding) {
        StringBuilder encodedParams = new StringBuilder();
        try {
            if (params != null && params.size() > 0) {
                for (Pair<String, String> entry : params) {
                    encodedParams.append(URLEncoder.encode(entry.first, paramsEncoding));
                    encodedParams.append('=');
                    encodedParams.append(URLEncoder.encode(entry.second, paramsEncoding));
                    encodedParams.append('&');
                }
            }
            return encodedParams.toString().getBytes(paramsEncoding);
        } catch (UnsupportedEncodingException uee) {
            throw new RuntimeException("Encoding not supported: " + paramsEncoding, uee);
        }
    }
}
