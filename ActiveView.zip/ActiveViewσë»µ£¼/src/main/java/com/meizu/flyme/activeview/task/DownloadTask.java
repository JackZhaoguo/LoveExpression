package com.meizu.flyme.activeview.task;

import android.os.AsyncTask;
import android.os.SystemClock;

import com.meizu.flyme.activeview.download.FileCheckResult;
import com.meizu.flyme.activeview.download.IFileChecker;
import com.meizu.flyme.activeview.listener.OnDownloadListener;
import com.meizu.flyme.activeview.utils.LogUtil;
import com.meizu.flyme.activeview.utils.MD5Util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Download the file for the given URL asynchronously.
 */
public class DownloadTask extends AsyncTask<Void, Integer, Integer> {
    public static final int DOWNLOAD_RESULT_CODE_CANCEL = 0;
    public static final int FILE_NAME_LENGTH_LIMIT = 255;

    private static final String LOG_TAG = "DownloadTask";
    private URL mUrl;
    private File mFile;
    private OnDownloadListener mDownloadListener;
    private IFileChecker mFileChecker;

    public DownloadTask(String url, String outputDir, OnDownloadListener listener) {
        this(url, outputDir, null, listener);
    }

    public DownloadTask(String url, String outputDir, String fileName, OnDownloadListener listener) {
        super();
        mDownloadListener = listener;

        if (url == null || url.isEmpty() || outputDir == null || outputDir.isEmpty()) {
            if (mDownloadListener != null) {
                mDownloadListener.onDownloadFinished(OnDownloadListener.DOWNLOAD_FAIL, "URL=" + url + ", outputDir=" + outputDir);
                mDownloadListener = null;
            }
            return;
        }

        try {
            mUrl = new URL(url);
            LogUtil.i(LOG_TAG, "mUrl =" + mUrl);
        } catch (MalformedURLException e) {
            LogUtil.e(LOG_TAG, e.toString());
            if (mDownloadListener != null) {
                mDownloadListener.onDownloadFinished(OnDownloadListener.DOWNLOAD_FAIL, "Bad URL:" + url);
                mDownloadListener = null;
            }
            return;
        }

        String file = fileName;
        File outDir = new File(outputDir);

        if (file == null && mUrl != null) {
            try {
                file = new File(mUrl.getFile()).getName();          // file = "output.zip"
            } catch (NullPointerException e) {
                LogUtil.e(LOG_TAG, "Failed to create file, err=" + e.toString());
                if (mDownloadListener != null) {
                    mDownloadListener.onDownloadFinished(OnDownloadListener.DOWNLOAD_FAIL, "Failed to create file :" + mUrl.getFile());
                    mDownloadListener = null;
                }
                return;
            }

            if (!outDir.exists()) {
                if (!outDir.mkdir()) {
                    LogUtil.e(LOG_TAG, "Failed to make directories:" + outDir.getAbsolutePath());
                    if (mDownloadListener != null) {
                        mDownloadListener.onDownloadFinished(OnDownloadListener.DOWNLOAD_FAIL, "Failed to make directories:" + outDir.getAbsolutePath());
                        mDownloadListener = null;
                    }
                    return;
                }
            }
        }

        if (file != null && file.length() > FILE_NAME_LENGTH_LIMIT) {
            file = MD5Util.MD5Encode(file);
        }

        try {
            mFile = new File(outDir, file);
        } catch (NullPointerException e) {
            LogUtil.e(LOG_TAG, "Failed to create file, err=" + e.toString());
            if (mDownloadListener != null) {
                mDownloadListener.onDownloadFinished(OnDownloadListener.DOWNLOAD_FAIL, "Failed to create file :" + outDir.getAbsolutePath() + file);
                mDownloadListener = null;
            }
            return;
        }

    }

    public DownloadTask(String url, String outputDir) {
        this(url, outputDir, null);
    }

    @Override
    protected Integer doInBackground(Void... params) {
        if (isCancelled()) {
            mDownloadListener = null;
            return DOWNLOAD_RESULT_CODE_CANCEL;
        }
        return download();
    }

    @Override
    protected void onPostExecute(Integer result) {
        if (isCancelled()) {
            mDownloadListener = null;
            return;
        }
        setResult(result);
    }

    private void setResult(Integer result) {
        if (mDownloadListener != null) {
            switch (result) {
                case OnDownloadListener.DOWNLOAD_FAIL:
                    mDownloadListener.onDownloadFinished(OnDownloadListener.DOWNLOAD_FAIL, "Download Fail. URL=" + mUrl);
                    break;

                case OnDownloadListener.DOWNLOAD_SUCESS:
                    mDownloadListener.onDownloadFinished(OnDownloadListener.DOWNLOAD_SUCESS, mFile.getAbsolutePath());
                    break;
                default:
                    mDownloadListener.onDownloadError(result);
            }

            mDownloadListener = null;
        }
    }

    public String doDownloadSync() {
        int result = download();
        setResult(result);

        return result == OnDownloadListener.DOWNLOAD_SUCESS ? mFile.getAbsolutePath() : null;
    }

    private int download() {
        if (mUrl == null || mFile == null) {
            return OnDownloadListener.DOWNLOAD_FAIL;
        }

        if (mDownloadListener != null) {
            mDownloadListener.onDownloadStart(mUrl.toString());
        }
        long startTime = SystemClock.currentThreadTimeMillis();
        HttpURLConnection connection;
        int bytesCopied = 0;
        try {
            connection = (HttpURLConnection) mUrl.openConnection();
            if (connection.getResponseCode() == 200) {
                int length = connection.getContentLength();

                if (mFile.exists() && length == mFile.length()) {
                    LogUtil.e(LOG_TAG, "file " + mFile.getName() + " already exits!! Don't download again." + ", mFile.length()=" + mFile.length());
                    return 0;
                }
                FileOutputStream outputStream = new FileOutputStream(mFile);
                long inStreamLength = connection.getContentLength();

                if (mFileChecker != null) {
                    FileCheckResult checkResult = mFileChecker.checkHttpContentLength(0, inStreamLength);
                    if (!checkResult.isMatch()) {
                        return OnDownloadListener.DOWNLOAD_FILE_LENGTH_ERROR;
                    }
                }
                bytesCopied = copy(connection.getInputStream(), outputStream);
                if (bytesCopied != length && length != -1) {
                    LogUtil.e(LOG_TAG, "Download incomplete bytesCopied=" + bytesCopied + ", length" + length);
                }
                outputStream.close();

                if (mFileChecker != null) {
                    FileCheckResult checkResult = mFileChecker.checkFileDataInfo(mFile.getAbsolutePath());
                    if (!checkResult.isMatch()) {
                        return OnDownloadListener.DOWNLOAD_FILE_DATA_ERROR;
                    }
                }
            } else {
                LogUtil.e(LOG_TAG, "error. ResponseCode = " + connection.getResponseCode());

                return connection.getResponseCode();
            }
        } catch (IOException e) {
            LogUtil.e(LOG_TAG, "IOException e=" + e.toString());
            return OnDownloadListener.DOWNLOAD_FAIL;
        }
        long endTime = SystemClock.currentThreadTimeMillis();
        LogUtil.i(LOG_TAG, "Download file:" + mFile + ", UseTime =" + String.valueOf(endTime - startTime));

        return OnDownloadListener.DOWNLOAD_SUCESS;
    }

    private int copy(InputStream input, OutputStream output) {
        byte[] buffer = new byte[1024 * 8];
        BufferedInputStream in = new BufferedInputStream(input, 1024 * 8);
        BufferedOutputStream out = new BufferedOutputStream(output, 1024 * 8);
        int count = 0;
        int n;
        try {
            while ((n = in.read(buffer, 0, 1024 * 8)) != -1) {
                out.write(buffer, 0, n);
                count += n;
            }
            out.flush();
        } catch (IOException e) {
            LogUtil.e(LOG_TAG, "Extracted IOException:" + e.toString());
        } finally {
            try {
                out.close();
            } catch (IOException e) {
                LogUtil.e(LOG_TAG, "out.close() IOException e=" + e.toString());
            }
            try {
                in.close();
            } catch (IOException e) {
                LogUtil.e(LOG_TAG, "in.close() IOException e=" + e.toString());
            }
        }
        return count;
    }

    public void setFileChecker(IFileChecker fileChecker) {
        mFileChecker = fileChecker;
    }

    public File getFile() {
        return mFile;
    }
}
