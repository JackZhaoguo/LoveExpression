package com.meizu.flyme.activeview.download;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.text.TextUtils;

import com.meizu.flyme.activeview.utils.LogUtil;
import com.meizu.flyme.activeview.utils.Md5Helper;
import com.meizu.flyme.activeview.utils.Utility;


/**
 * Created by fengsh on 14-12-5.
 */
public class DownloadFileChecker implements IFileChecker {
    private static final int MASK_FILE_LENGTH = 1;
    private static final int MASK_WHOLE_MD5 = 2;
    private static final int MASK_HEAD_TAIL_MD5 = 4;
    private static final int MASK_PACKAGE_NAME = 8;
    private static final int MASK_VERSION_CODE = 16;

    private Context mContext;
    private int mVerifyMode;
    private String mTargetPackageName;
    private long mTargetLength;
    private String mMd5;
    private int mVersionCode;
    private boolean mEnableCheck = true;// default must be true

    private boolean mNoContentLength = false;

    public DownloadFileChecker(Context context, int verifyMode, String packageName, long fileLength, String fileMd5, int versionCode) {
        mContext = context;
        mVerifyMode = verifyMode;
        mTargetPackageName = packageName;
        mTargetLength = fileLength;
        mMd5 = fileMd5;
        mVersionCode = versionCode;

        logE("Checker limit:" + this.toString());

    }

    @Override
    public String getCheckMd5() {
        if (!TextUtils.isEmpty(mMd5) && isMaskEnable(MASK_WHOLE_MD5)) {
            return mMd5;
        }
        return null;
    }

    @Override
    public String getCheckPartialMd5() {
        if (!TextUtils.isEmpty(mMd5) && isMaskEnable(MASK_HEAD_TAIL_MD5)) {
            return mMd5;
        }
        return null;
    }

    @Override
    public long getCheckFileSize() {
        if (mTargetLength > 0 && isMaskEnable(MASK_FILE_LENGTH)) {
            return mTargetLength;
        }
        return 0;
    }

    private boolean isMaskEnable(int mask) {
        return (mVerifyMode & mask) > 0;
    }

    @Override
    public boolean isFileLengthMatch(long fileLength) {
        FileCheckResult result = checkHttpContentLength(0, fileLength);
        return result.isMatch();
    }

    @Override
    public FileCheckResult checkHttpContentLength(long httpRange, long contentLength) {
        if (mEnableCheck) {
            // 某些下载链接无法获取到文件流长度，则忽略长度判断
            mNoContentLength = contentLength <= 0;

            if (mTargetLength > 0 && !mNoContentLength && isMaskEnable(MASK_FILE_LENGTH)) {
                boolean match = (httpRange + contentLength) == mTargetLength;
                if (!match) {
                    String errorMsg = "File length not match(" + mTargetLength + "->" + (httpRange + contentLength) + ")";
                    logE(errorMsg);
                    return FileCheckResult.instanceErrorResult(errorMsg);
                }
            }
        }
        return FileCheckResult.instanceSuccessResult();
    }

    @Override
    public FileCheckResult checkFileDataInfo(String filePath) {
        if (mEnableCheck) {
            boolean somethingCheck = false;

            if (!TextUtils.isEmpty(mMd5)) {
                if (isMaskEnable(MASK_WHOLE_MD5)) {
                    somethingCheck = true;
                    String fileMd5 = Md5Helper.md5sum(filePath);
                    boolean match = mMd5.equalsIgnoreCase(fileMd5);
                    if (!match) {
                        String errorMsg = "Whole md5 not match(" + mMd5 + "->" + fileMd5 + ")";
                        logE(errorMsg);
                        return FileCheckResult.instanceErrorResult(errorMsg);
                    }
                } else if (isMaskEnable(MASK_HEAD_TAIL_MD5)) {
                    somethingCheck = true;
                    String headTailMd5 = Md5Helper.md5sumHeadTail(filePath, 1024 * 1024);// default size is 1M
                    boolean match = mMd5.equalsIgnoreCase(headTailMd5);
                    if (!match) {
                        String errorMsg = "HeadTail md5 not match(" + mMd5 + "->" + headTailMd5 + ")";
                        logE(errorMsg);
                        return FileCheckResult.instanceErrorResult(errorMsg);
                    }
                }
            }
            // content length无法检查，并且没有其它信息检查时，通过下载的文件长度检查是否匹配
            if (!somethingCheck && mTargetLength > 0 && mNoContentLength && isMaskEnable(MASK_FILE_LENGTH)) {
                mNoContentLength = false;
                long fileLength = Utility.getFileLength(filePath);
                if (fileLength > 0) {
                    boolean match = fileLength == mTargetLength;
                    if (!match) {
                        String errorMsg = "Download File length not match(" + mTargetLength + "->" + fileLength + ")";
                        logE(errorMsg);
                        return FileCheckResult.instanceErrorResult(errorMsg);
                    }
                }
            }
        }
        return FileCheckResult.instanceSuccessResult();
    }

    @Override
    public boolean isFileDataMatch(String filePath) {
        FileCheckResult result = checkFileDataInfo(filePath);
        return result.isMatch();
    }

    @Override
    public void enableCheck(boolean enable) {
        mEnableCheck = enable;
    }

    @Override
    public String getLogVersion() {
        if (mVersionCode > 0) {
            return String.valueOf(mVersionCode);
        }
        return null;
    }

    private void logE(String msg) {
        LogUtil.e(msg);
    }

    @Override
    public String toString() {
        String verifyStr = "";
        if (isMaskEnable(MASK_FILE_LENGTH)) {
            verifyStr += "size ";
        }
        if (isMaskEnable(MASK_HEAD_TAIL_MD5)) {
            verifyStr += "1mmd5 ";
        }
        if (isMaskEnable(MASK_PACKAGE_NAME)) {
            verifyStr += "pkg ";
        }
        if (isMaskEnable(MASK_VERSION_CODE)) {
            verifyStr += "vcode ";
        }
        if (isMaskEnable(MASK_WHOLE_MD5)) {
            verifyStr += "md5 ";
        }
        if (TextUtils.isEmpty(verifyStr)) {
            verifyStr = "null";
        }

        return "verify_mode=" + verifyStr + ",pk=" + mTargetPackageName + ",size=" + mTargetLength + ",md5=" + mMd5 + ",v_code=" + mVersionCode;
    }
}
