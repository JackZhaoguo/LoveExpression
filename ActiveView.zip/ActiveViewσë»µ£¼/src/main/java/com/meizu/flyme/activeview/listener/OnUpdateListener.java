package com.meizu.flyme.activeview.listener;

/**
 * Created by meizu on 16/10/22.
 */
public interface OnUpdateListener {

    /**
     * Result state.
     */
    int UPDATE_STATE_FAIL                      = 0x00;
    int UPDATE_STATE_SUCCESS                   = 0x01;

    /**
     * Dowload result.
     */
    int UPDATE_DOWNLOAD                        = 0x02;

    /**
     * Extract result.
     */
    int UPDATE_EXTRACT                         = 0x03;

    /**
     * Load and parse json file result.
     */
    int UPDATE_LOADJSON                        = 0x04;

    /**
     * Load all images files finished.
     * At this state, ActiveView is created and load resources, but maybe not added to a ViewGroup.
     */
    int UPDATE_LOAD_RESOURCES                  = 0x05;

    /**
     * Check version result.
     */
    int UPDATE_VERSION_COMPATIBALE             = 0x06;

    /**
     * ActiveView is ready and added to a ViewGroup. At this state, load resources has finished, it will be visible.
     */
    int UPDATE_FINISHED                        = 0x07;

    /**
     *  ActiveView is ready but not added to a ViewGroup. At this state, load resources has finished, it won't be visible before added.
     */
    int UPDATE_READY_NOT_ADDED                 = 0x08;

    /**
     *  Video state callback. At this state, MediaPlayer's OnPreparedListener.onPrepared() is called.
     */
    int UPDATE_VIDEO_STATE_PREPARED            = 0x09;

    /**
     *  Video state callback. At this state, MediaPlayer's OnCompletionListener.onCompletion() is called.
     */
    int UPDATE_VIDEO_STATE_COMPLETION          = 0x0A;

    /**
     *  Video state callback. At this state, MediaPlayer's OnErrorListener.onError() is called.
     */
    int UPDATE_VIDEO_STATE_ONERROR             = 0x0B;

    /**
     *  Video state callback. At this state, MediaPlayer's OnInfoListener.onInfo() is called.
     */
    int UPDATE_VIDEO_STATE_ONINFO              = 0x0C;

    /**
     *  Callback for state.
     *  @param    type       The type. {@link #UPDATE_DOWNLOAD, UPDATE_EXTRACT, UPDATE_LOADJSON, UPDATE_LOAD_RESOURCES, UPDATE_VERSION_COMPATIBALE, UPDATE_FINISHED, UPDATE_READY_NOT_ADDED}
     *  @param    state      the result state of the type.   {@link #UPDATE_STATE_FAIL, UPDATE_STATE_SUCCESS}
     *  @param    result     the result string.
     */
    void onUpdateFinished(int type, int state, String result);
}
