package com.meizu.flyme.activeview.json;

import android.content.Context;

import com.meizu.flyme.activeview.utils.DisplayUnitUtil;

/**
 * Created by meizu on 16/11/8.
 */
public class TextAttrs {
    private String text;

    private String textSize;
    private Float mTextSizeValue;

    private String textStyle;

    private Integer textColor;

    private Integer background;

    private String gravity;

    private Integer opacity;

    private Integer maxLength;

    private Integer maxLines;

    private Boolean singleLine;

    private String ellipsize;

    private String fontStyle;
    private String fontFamily;

    private String letterSpacing;
    private Float mLetterSpacingValue;

    private String lineSpacingExtra;
    private Float mLineSpacingExtraValue;

    public void setText(String text){
        this.text = text;
    }

    public String getText(){
        return this.text;
    }

    public void setTextSize(String textSize){
        this.textSize = textSize;
    }

    public String getTextSize(){
        return this.textSize;
    }

    public Float getTextSizeValue(Context context) {
        if (textSize != null && !textSize.isEmpty()) {
            mTextSizeValue = (float)DisplayUnitUtil.getPixelValue(context, textSize);
        }
        return mTextSizeValue;
    }

    public void setTextStyle(String textStyle){
        this.textStyle = textStyle;
    }

    public String getTextStyle(){
        return this.textStyle;
    }

    public void setTextColor(Integer textColor){
        this.textColor = textColor;
    }

    public Integer getTextColor(){
        return this.textColor;
    }

    public void setBackground(Integer background){
        this.background = background;
    }
    public Integer getBackground(){
        return this.background;
    }

    public void setGravity(String gravity){
        this.gravity = gravity;
    }

    public String getGravity(){
        return this.gravity;
    }

    public void setOpacity(Integer opacity){
        this.opacity = opacity;
    }

    public Integer getOpacity(){
        return this.opacity;
    }

    public void setMaxLength(Integer maxLength){
        this.maxLength = maxLength;
    }

    public Integer getMaxLength(){
        return this.maxLength;
    }

    public void setMaxLines(Integer maxLines){
        this.maxLines = maxLines;
    }

    public Integer getMaxLines(){
        return this.maxLines;
    }

    public void setSingleLine(Boolean singleLine){
        this.singleLine = singleLine;
    }

    public Boolean getSingleLine(){
        return this.singleLine;
    }

    public void setEllipsize(String ellipsize){
        this.ellipsize = ellipsize;
    }

    public String getEllipsize(){
        return this.ellipsize;
    }

    public void setFontStyle(String fontStyle){
        this.fontStyle = fontStyle;
    }

    public String getFontStyle(){
        return this.fontStyle;
    }

    public void setFontFamily(String fontFamily){
        this.fontFamily = fontFamily;
    }

    public String getFontFamily(){
        return this.fontFamily;
    }

    public void setLetterSpacing(String letterSpacing){
        this.letterSpacing = letterSpacing;
    }

    public String getLetterSpacing(){
        return this.letterSpacing;
    }

    public Float getLetterSpacingValue(Context context) {
        if (letterSpacing != null && !letterSpacing.isEmpty()) {
            mLetterSpacingValue = (float)DisplayUnitUtil.getPixelValue(context, letterSpacing);
        }
        return mLetterSpacingValue;
    }

    public void setLineSpacingExtra(String lineSpacingExtra){
        this.lineSpacingExtra = lineSpacingExtra;
    }

    public String getLineSpacingExtra(){
        return this.lineSpacingExtra;
    }

    public Float getLineSpacingExtraValue(Context context) {
        if (lineSpacingExtra != null && !lineSpacingExtra.isEmpty()) {
            mLineSpacingExtraValue = (float)DisplayUnitUtil.getPixelValue(context, lineSpacingExtra);
        }
        return mLineSpacingExtraValue;
    }
}
