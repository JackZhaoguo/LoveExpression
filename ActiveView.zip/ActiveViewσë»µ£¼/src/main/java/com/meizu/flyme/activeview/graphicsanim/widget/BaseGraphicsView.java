package com.meizu.flyme.activeview.graphicsanim.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;

import com.meizu.flyme.activeview.graphicsanim.renderable.ParticleSystem;
import com.meizu.flyme.activeview.graphicsanim.renderable.Renderable;
import com.meizu.flyme.activeview.graphicsanim.utils.FrameRateCounter;

import java.util.ArrayList;
import java.util.List;

/**
 * 2D 图形动画视图控件
 * <p/>
 * Created by cjy on 16-11-5.
 */
public class BaseGraphicsView extends View {

    protected List<Renderable> mRenderables = new ArrayList<Renderable>();

    private boolean mAnimationStarted = false;

    private boolean mAnimationPaused = false;

    FrameRateCounter mFrameRateCounter = new FrameRateCounter();

    public BaseGraphicsView(Context context) {
        this(context, null);
    }

    public BaseGraphicsView(Context context, AttributeSet attrs) {
        this(context, attrs, null);
    }

    /**
     * @param context
     * @param attrs       layout文件配置属性
     * @param attrsBundle ActiveView json文件配置属性
     */
    public BaseGraphicsView(Context context, AttributeSet attrs, List<Bundle> attrsBundle) {
        super(context, attrs);

        setRenderables(attrsBundle);
    }

    /**
     * 添加新的Renderable
     *
     * @param renderableAttrs
     */
    private void addRenderable(Bundle renderableAttrs) {
        Renderable renderable = null;
        if (renderableAttrs != null) {
            String className = renderableAttrs.getString(Renderable.ATTR_CLASS_NAME);
            if (className == null) {
                return;
            }
            if (className.equals(Renderable.CLASS_NAME)) {
                renderable = new Renderable(renderableAttrs);
            } else if (className.equals(ParticleSystem.CLASS_NAME)) {
                renderable = new ParticleSystem(renderableAttrs);
            }

            if (renderable != null) {
                mRenderables.add(renderable);
            }
        }
    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if(mAnimationStarted ){
            float deltaTime = mFrameRateCounter.timeStep();
            for (Renderable renderable : mRenderables) {
                if (!(this.getAlpha() > 0.000001f)) {          // if this view's alpha is 0, don't draw.
                    break;
                }
                renderable.draw(canvas);
                renderable.update(deltaTime);
            }

            if(!mAnimationPaused){
                invalidate();
            }
        }
    }

    /**
     * 开始动画
     */
    public void start() {
        if(!mAnimationStarted){
            mAnimationStarted = !mAnimationStarted;
            invalidate();
        }
    }

    /**
     * 停止动画
     */
    public void stop() {
        mAnimationStarted = false;
        mAnimationPaused = false;
        //最后一桢，清空视图
        invalidate();
    }

    /**
     * 暂停动画
     */
    public void pause(){
        if(mAnimationStarted){
            mAnimationPaused = true;
        }
    }

    public void resume(){
        mAnimationPaused = false;
        if(mAnimationStarted){
            invalidate();
        }
    }


    public boolean isPaused(){
        return mAnimationPaused;
    }


    /**
     * 当前是否正在执行动画
     *
     * @return
     */
    public boolean isStarted() {
        return mAnimationStarted;
    }

    /**
     * 重新设置Renderable
     * 规则：
     * 1）id与classname不能为空，classname必须是已存在的renderable类及其子类
     * 2）如id与列表中已存在的renderable一致，则更新已存在的renderable属性，否则，作为新增的renderable
     * @param attrsBundle
     */
    public void setRenderables(List<Bundle> attrsBundle) {
        if (attrsBundle != null && attrsBundle.size() > 0) {
            for (int i = 0; i < attrsBundle.size(); i++) {
                Bundle bundle = attrsBundle.get(i);
                if (bundle != null) {
                    String id = bundle.getString(Renderable.ATTR_ID);
                    if (id == null || id.trim().isEmpty()) {
                        continue;
                    }

                    if (!updateRenderable(id, bundle)) {
                        //没有存在相同id的renderable,作为新的renderable添加
                        addRenderable(bundle);
                    }

                }
            }
        }
    }


    /**
     * 更新renderable 属性,必须匹配id
     *
     * @param id
     * @param bundle
     */
    public boolean updateRenderable(String id, Bundle bundle) {
        if(bundle != null){
            for (int j = 0; j < mRenderables.size(); j++) {
                Renderable renderable = mRenderables.get(j);
                if (id.equals(renderable.getID())) {
                    //重置已经存在的renderable 的属性
                    renderable.updateAttributes(bundle);
                    return true;
                }
            }
        }
        return false;
    }

}
