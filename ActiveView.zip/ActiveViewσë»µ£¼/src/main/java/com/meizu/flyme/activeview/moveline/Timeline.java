package com.meizu.flyme.activeview.moveline;

import android.util.Log;
import android.view.animation.Interpolator;

import com.meizu.flyme.activeview.moveline.item.FrameStyle;
import com.meizu.flyme.activeview.moveline.item.TweenItem;

/**
 * Created by suyouxiong on 16-6-20.
 */
public class Timeline extends BaseTimeline {
    private boolean mStarted;

    private long time;

    /**
     * When the animation reaches the end and <code>repeatCount</code> is INFINITE
     * or a positive value, the animation restarts from the beginning.
     */
    public static final String RESTART = "restart";
    /**
     * When the animation reaches the end and <code>repeatCount</code> is INFINITE
     * or a positive value, the animation reverses direction on every iteration.
     */
    public static final String REVERSE = "reverse";
    /**
     */
    public static final int INFINITE = -1;

    // The number of times the animation will repeat. The default is 0, which means the animation
    // will play only once
    private int mRepeatCount = 0;

    /**
     * The type of repetition that will occur when repeatMode is nonzero. RESTART means the
     * animation will start from the beginning on every new cycle. REVERSE means the animation
     * will reverse directions on each iteration.
     */
    private String mRepeatMode = RESTART;

    /**
     * This variable tracks the current iteration that is playing. When mCurrentIteration exceeds the
     * repeatCount (if repeatCount!=INFINITE), the animation ends
     */
    private int mCurrentIteration = 0;

    private boolean mPlayingBackwards;

    /**
     * Set when setCurrentPlayTime() is called. If negative, animation is not currently seeked
     * to a value.
     */
    float mSeekFraction = -1;

    public Timeline() {
        super();
    }

    @Override
    protected void update(long time) {
        if (Config.LOCAL_LOG) {
            Log.i(Config.MOVELINE_LOG_TAG, this.hashCode() + " timeline update:curTime=" + time + "; startTime=" + startTime + "; duration=" + getDuration());
        }
        boolean isComplete = false;
        int totalDuration = getDuration();
        if (totalDuration <= 0) {//如果总时长为0，开始更新直接完成
            isComplete = true;
        } else {
            long prevTime = this.time;
            if (time  >= totalDuration) {//顺序结束
                this.time = totalDuration;
                if (mCurrentIteration < mRepeatCount || mRepeatCount == INFINITE) {
                    if (mRepeatMode.equals(REVERSE)) {
                        mPlayingBackwards = !mPlayingBackwards;
                        this.time = 0;//为了走完当前这次更新，模拟开始倒退和保证倒退的最终态
                    }
                    startTime += totalDuration;
                    mCurrentIteration++;
                } else if (!mReversing) {
                    isComplete = true;
                }
            } else if (time < 0) {//reverse结束
                // TODO: 2016/11/2 repeat in reversing
                this.time = 0;
                if (mReversing) {
                    isComplete = true;
                }
            } else {
                this.time = time;
            }
            if (prevTime == this.time) {
                return;
            }
            if (!isActive) {
                isActive = true;
            }
            long curTime = this.time;
            if (mPlayingBackwards) {
                curTime = totalDuration - curTime;
            }
            updateChild(curTime);
            mPlayingState = RUNNING;
        }

        if (isComplete) {
            if (Config.LOCAL_LOG) {
                Log.i(Config.MOVELINE_LOG_TAG, this.hashCode() + " timeline is Completed");
            }
            detachFromRoot();
            this.isActive = false;
            this.mStarted = false;
            mPlayingState = STOPPED;
            if (getAnimationListener() != null) {
                AnimationListener listener = getAnimationListener();
                listener.onAnimationEnd(this);
            }
            notifyEndListeners();
        }
    }

    private void updateChild(long curTime) {
        Animation animation = this.first;

        while (animation != null) {//我们必须迭代查找所有动画，因为极端情况下可能所有的动画是并行的
            if (animation.isActive || animation.startTime <= curTime) {//如果到达当前动画的开始时间
                if (!animation.mReversing) {
                    animation.update(curTime - animation.startTime);
                } else {
                    animation.update(animation.getDuration() - (curTime - animation.startTime));
                }

            }
            animation = animation.next;
        }
    }

    /**
     * 移动到某一帧
     *
     * @param target 目标
     * @param duration 时长
     * @param itemStyle 目标帧的样式
     * @param delay 延迟
     * @return
     */
    public Timeline to(TweenItem target, int duration, FrameStyle itemStyle, int delay) {
        return this.to(target, duration, itemStyle, -1, delay);
    }

    /**
     *
     * @param target 目标
     * @param duration 时长
     * @param itemStyle 目标帧的样式
     * @param position 执行帧的时间
     * @param delay 延迟
     * @return
     */
    public Timeline to(TweenItem target, int duration, FrameStyle itemStyle, int position, int delay) {
        return this.to(target, duration, itemStyle, null, position, delay);
    }

    /**
     *
     * @param target
     * @param duration
     * @param itemStyle
     * @param interpolator 帧动画插值器
     * @param position
     * @param delay
     * @return
     */
    public Timeline to(TweenItem target, int duration, FrameStyle itemStyle, Interpolator interpolator, int position, int delay) {
        Tween tween = new Tween(target, duration, itemStyle);
        tween.setInterpolator(interpolator);
        add(tween, position, delay);
        return this;
    }


    @Override
    public void play() {
        start(false);
    }

    @Override
    public void reverse() {
        start(true);
    }

    @Override
    public void stop() {
        //if (!mStarted) return;
        /*if (timelineTicker.isActive()) {
            timelineTicker.stop();
        }*/
        detachFromRoot();
        long destTime = !mReversing ? 0 : getDuration();

        jumpToEnd();

        if (getAnimationListener() != null) {
            AnimationListener listener = getAnimationListener();
            listener.onAnimationStopped(this);
        }

        mStarted = false;
    }

    private void start(boolean playBackwards) {
        initState();
        mPlayingBackwards = playBackwards;
        this.mReversing = playBackwards;
        if (!timelineTicker.isActive()) {
            timelineTicker.wake();
        }

        if (mPlayingState != SEEKED) {
            setCurrentPlayTime(0);
            startTime += delayTime;
            time = mReversing ? getDuration() : 0;
            Animation animation = this.first;
            while (animation != null) {
                animation.time = 0;
                animation = animation.next;
            }
        } else {
            long seekTime = (long) (getDuration() * mSeekFraction);
            startTime = timelineTicker.getTime() - seekTime;
        }

        attachToRoot();
        /*
        if (!mReversing) {//先更新一下回到最初的状态
            update(0);
        } else {
            update(getDuration());
        }*/
        mStarted = true;
        paused = false;
        if (mPlayingState != RUNNING) {
            notifyStartListeners();
        }
        if (Config.LOCAL_LOG) {
            Log.i(Config.MOVELINE_LOG_TAG, this.hashCode() + " timeline start. startTime = " + startTime);
        }
    }

    private void initState() {
        mPlayingState = STOPPED;
    }

    @Override
    public void pause() {
        if (paused || !mStarted) return;
        if (mPlayingState != RUNNING) {
            time = timelineTicker.getTime() - (startTime - delayTime);
        }
        pauseTime = time;
        paused = true;
    }


    @Override
    public void resume() {
        if (!paused) return;
        if (!timelineTicker.isActive()) {
            timelineTicker.wake();
        }
        if (mPlayingState != RUNNING && time < delayTime) {
            startTime = timelineTicker.getTime() + (delayTime - pauseTime);
        } else {
            //时钟调度继续进行，模拟pauseTime前已经开始了
            startTime = timelineTicker.getTime() - (!mReversing ? pauseTime : (getDuration() - pauseTime));
        }
        paused = false;
    }

    private void attachToRoot() {
        this.rootTimeline.add(this, this.startTime, 0);
    }

    private void detachFromRoot() {
        this.rootTimeline.remove(this);
    }

    @Override
    protected void setActive(boolean active) {
        super.setActive(active);
        Animation tween = this.first;
        while (tween != null) {
            tween.setActive(active);
            tween = tween.next;
        }
    }

    @Override
    public int getDuration() {
        if (dirty) {
            long max = 0;
            Animation animation = this.last;
            while (animation != null) {
                Animation prev = animation.prev;
                long end = animation.startTime + animation.getDuration();
                if (end > max) {
                    max = end;
                }
                animation = prev;
            }
            this.duration = (int) max;
            dirty = false;
        }
        return super.getDuration();
    }

    /**
     * Sets how many times the animation should be repeated. If the repeat
     * count is 0, the animation is never repeated. If the repeat count is
     * greater than 0 or {@link #INFINITE}, the repeat mode will be taken
     * into account. The repeat count is 0 by default.
     *
     * @param repeatCount the number of times the animation should be repeated
     */
    public void setRepeatCount(int repeatCount) {
        mRepeatCount = repeatCount;
    }

    /**
     * Defines what this animation should do when it reaches the end. This
     * setting is applied only when the repeat count is either greater than
     * 0 or {@link #INFINITE}. Defaults to {@link #RESTART}.
     *
     * @param repeatMode {@link #RESTART} or {@link #REVERSE}
     */
    public void setRepeatMode(String repeatMode) {
        mRepeatMode = repeatMode;
    }

    /**
     * 跳到最终状态
     */
    private void jumpToEnd() {
        if (!mReversing) {//直接到目标状态
            Animation animation = this.first;
            while (animation != null) {
                if (!animation.mReversing) {
                    animation.update(animation.getDuration());
                } else {
                    animation.update(0);
                }
                animation = animation.next;
            }
        } else {
            Animation animation = this.last;
            while (animation != null) {//执行每一帧的初始样式
                if (!animation.mReversing) {
                    animation.update(0);
                } else {
                    animation.update(animation.getDuration());
                }
                animation = animation.prev;
            }
        }
    }

    /**
     * 设置当前动画的播放时间点，可以是从0到总时长。如果动画没有开始，则设置之后动画会从这个位置开始。
     * 如果动画正在进行会直接跳到这个位置再继续
     *
     * @param time
     */
    public void setCurrentPlayTime(long time) {
        int totalDuration = getDuration();
        float fraction = totalDuration > 0 ? (float) time / totalDuration : 1;
        setCurrentFraction(fraction);
    }

    /**
     * 设置当前动画的播放比例位置，比例位置就是说，如果是0那么就是动画开始，1是动画结尾。如果时间线动画是循环的，
     * 那么大于1就是从新或倒退（根据{@link #setRepeatMode(String)}设置决定），以此类推。
     * @param fraction
     */
    public void setCurrentFraction(float fraction) {
        if (fraction < 0) {
            fraction = 0;
        }
        int iteration = (int) fraction;
        if (fraction == 1) {
            iteration -= 1;//没有进行过循环
        } else if (fraction > 1) {
            if (iteration < (mRepeatCount + 1) || mRepeatCount == INFINITE) {
                if (mRepeatMode == REVERSE) {
                    mPlayingBackwards = (iteration % 2) != 0;
                }
                fraction = fraction % 1f;
            } else {
                fraction = 1;
                iteration -= 1;
            }
        } else {
            mPlayingBackwards = mReversing;
        }
        mCurrentIteration = iteration;
        long seekTime = (long) (fraction * getDuration());
        startTime = timelineTicker.getTime() - seekTime;
        if (mPlayingState != RUNNING) {
            mSeekFraction = fraction;
            mPlayingState = SEEKED;
        }
        if (mPlayingBackwards) {
            seekTime = getDuration() - seekTime;
        }
        initAnimationValue();//先初始化动画开始状态
        setActive(false);//如果在动画运行到超过了seekTime的时间，查过seekTime的tween已经是active状态，使用seekTime去更新它，它也会执行刷新。设置active为false，只有到了seekTime的帧动画才会刷新
        updateChild(seekTime);
    }

    @Override
    protected void initAnimationValue() {
        Animation tween = this.last;
        while (tween != null) {
            tween.initAnimationValue();
            tween = tween.prev;
        }
    }
}
