package com.meizu.flyme.activeview.json;

/**
 * Created by meizu on 16/9/26.
 */
public class Data {
    private String url;
    private String text;

    public Data() {}

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
