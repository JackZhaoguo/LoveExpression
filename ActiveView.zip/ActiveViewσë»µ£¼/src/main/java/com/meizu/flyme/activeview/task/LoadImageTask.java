package com.meizu.flyme.activeview.task;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.os.SystemClock;
import android.widget.ImageView;

import com.meizu.flyme.activeview.listener.OnAsyncTaskListener;
import com.meizu.flyme.activeview.utils.BitmapUtils;
import com.meizu.flyme.activeview.utils.ImageCacheUtils;
import com.meizu.flyme.activeview.utils.LogUtil;

import java.io.File;
import java.io.InputStream;

/**
 * Load and set dom view's background image asynchronously..
 */
public class LoadImageTask extends AsyncTask<Void, Integer, Bitmap> {
    private static final String LOG_TAG = "LoadImageTask";

    private ImageView mView;
    private String mFilePath;
    private Context mContext;
    private boolean mbUseAssetsFile;
    OnAsyncTaskListener mOnAsyncTaskListener;
    boolean mbIsCached;

    private float mReqWidth;
    private float mReqHeight;

    public LoadImageTask(Context context, ImageView iv, String filePath, OnAsyncTaskListener listener, float reqWidth, float reqHeight) {
        this(context, iv, filePath, false, listener, reqWidth, reqHeight);
    }

    public LoadImageTask(Context context, ImageView iv, String filePath, boolean useAssetsFile, OnAsyncTaskListener listener, float reqWidth, float reqHeight) {
        mContext = context;
        mView = iv;
        mFilePath = filePath;
        mbUseAssetsFile = useAssetsFile;
        mOnAsyncTaskListener = listener;

        mReqWidth = reqWidth;
        mReqHeight = reqHeight;
        mbIsCached = false;
    }

    public String getImagePath() {
        return mFilePath;
    }

    @Override
    protected Bitmap doInBackground(Void... params) {
        if (isCancelled()) {
            return null;
        }
        long startTime = SystemClock.currentThreadTimeMillis();
        try {
            Bitmap bitmap = ImageCacheUtils.getInstance().getBitmapFromImageCache(mFilePath);
            LogUtil.i(LOG_TAG, "GET MemoryCache="+ mFilePath + ", bitmap=" + bitmap);
            if (bitmap != null && !bitmap.isRecycled()) {
                mbIsCached = true;
                return bitmap;
            }
            if (mbUseAssetsFile) {
                if (mContext != null && mContext.getAssets() != null) {
                    InputStream imgInputStream = mContext.getAssets().open(mFilePath);
                    bitmap = BitmapUtils.decodeSampledBitmapFromStream(imgInputStream, (int)mReqWidth, (int)mReqHeight);
                    imgInputStream.close();
                }
            } else {
                File file = new File(mFilePath);
                if (file.exists()) {
                    bitmap = BitmapUtils.decodeSampledBitmapFromFile(mFilePath, (int)mReqWidth, (int)mReqHeight);
                }
            }

            long endTime = SystemClock.currentThreadTimeMillis();
            LogUtil.i(LOG_TAG, "Load image file:" + mFilePath + ", UseTime =" + String.valueOf(endTime - startTime));

            return bitmap;
        } catch (Exception e) {
            LogUtil.e(LOG_TAG, "create image error :" + e.getMessage());
            return null;
        }
    }

    @Override
    protected void onPostExecute(Bitmap bitmap) {
        if(mOnAsyncTaskListener != null) {
            mOnAsyncTaskListener.onLoadFinished(this);
            mOnAsyncTaskListener = null;
        }
        if (isCancelled()) {
            removeRetainedViews();
            return;
        }

        if(bitmap != null && mView != null) {
            LogUtil.i(LOG_TAG,  "reqWidth  bm.getWidth()=" + bitmap.getWidth() + ", bm.getHeight()=" + bitmap.getHeight() + ", byteCount=" + bitmap.getByteCount());
            BitmapDrawable  bitmapDrawable = new BitmapDrawable(mContext.getResources(), bitmap);
            mView.setImageDrawable(bitmapDrawable);

            if (!mbIsCached) {
                ImageCacheUtils.getInstance().putBitmapToImageCache(mFilePath, bitmap);
            }

            removeRetainedViews();
        }
    }

    private void removeRetainedViews() {
        mView = null;
        mContext = null;
    }
}
