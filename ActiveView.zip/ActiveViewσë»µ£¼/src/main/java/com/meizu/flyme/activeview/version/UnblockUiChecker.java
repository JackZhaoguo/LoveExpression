package com.meizu.flyme.activeview.version;

import android.content.Context;

import com.meizu.flyme.activeview.json.UpgradeActiveBean;

public class UnblockUiChecker {

    private BaseChecker mBaseChecker;

    public UnblockUiChecker(Context context, CheckListener listener) {
        mBaseChecker = new BaseChecker(context, listener);
    }

    public void startCheck() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                UpgradeActiveBean info = mBaseChecker.invoke();
                if (info != null) {
                    mBaseChecker.endSuccess(info);
                } else {
                    mBaseChecker.endError();
                }
            }
        }).start();
    }
}
