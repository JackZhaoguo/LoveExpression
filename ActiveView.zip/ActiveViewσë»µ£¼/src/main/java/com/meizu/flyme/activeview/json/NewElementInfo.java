package com.meizu.flyme.activeview.json;

import java.util.List;

/**
 * Created by meizu on 16/9/26.
 */
public class NewElementInfo {
    private List<NewElementData> elements;

    public NewElementInfo() {}

    public List<NewElementData> getElements() {
        return elements;
    }

    public void setElements(List<NewElementData> elements) {
        this.elements = elements;
    }
}
