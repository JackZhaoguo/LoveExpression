package com.meizu.flyme.activeview.json;

import android.content.Context;

import com.meizu.flyme.activeview.utils.DisplayUnitUtil;

/**
 * Created by meizu on 16/10/22.
 */
public class Parameter {
    private static final int PARAMETER_2D_ARRAY_LENGTH  = 2;
    private int duration;


    private String[] range;
    private Float[] rangeValue = new Float[PARAMETER_2D_ARRAY_LENGTH];

    private int sensitivity;

    private Interpolator interpolator;

    public Parameter() {}

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getDuration() {
        return this.duration;
    }

    public void setSensitivity(int sensitivity) {
        this.sensitivity = sensitivity;
    }

    public int getSensitivity() {
        return this.sensitivity;
    }

    public Interpolator getInterpolator() {
        return interpolator;
    }

    public void setInterpolator(Interpolator interpolator) {
        this.interpolator = interpolator;
    }

    public String[] getRange() {
        return range;
    }

    public void setRange(String[] range) {
        if (range.length != PARAMETER_2D_ARRAY_LENGTH) {
            return;
        }
        this.range = range;
    }

    public Float[] getRangeValue(Context context) {
        if (range != null && range.length == PARAMETER_2D_ARRAY_LENGTH) {
            for (int i = 0; i < PARAMETER_2D_ARRAY_LENGTH; i++) {
                if (range[i] != null) {
                    rangeValue[i] = (float) DisplayUnitUtil.getPixelValue(context, range[i]);

                }
            }
        }
        return rangeValue;
    }
}
