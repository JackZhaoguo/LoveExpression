package com.meizu.flyme.activeview.listener;

import android.graphics.Bitmap;

/**
 * Created by meizu on 16/10/22.
 */
public interface OnLoadImageListener {
    int LOADIMAGE_FAIL = 0x0;
    int LOADIMAGE_SUCESS = 0x1;
    void onLoadFinished(int state, Bitmap result);
}
