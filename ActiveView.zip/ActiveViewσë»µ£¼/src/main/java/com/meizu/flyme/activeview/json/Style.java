package com.meizu.flyme.activeview.json;

import android.content.Context;
import android.graphics.Color;

import com.meizu.flyme.activeview.utils.DisplayUnitUtil;

public class Style {

    private String width;
    private float mWidthValue;

    private String height;
    private float mHeightValue;

    private String radius;
    private float mRadiusValue;

    private String background;
    private int mBackgroundColorValue;

    private String border;
    private float mBorderValue;

    private int colorPrimary;

    public Style() {}

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public float getWidthValue(Context context) {
        if (width != null && !width.isEmpty()) {
            mWidthValue = (float)DisplayUnitUtil.getPixelValue(context, width); //Float.parseFloat(width.substring(0, width.length() - 2));
        }
        return mWidthValue;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public float getHeightValue(Context context) {
        if (height != null && !height.isEmpty()) {
            mHeightValue = (float)DisplayUnitUtil.getPixelValue(context,height);
        }
        return mHeightValue;
    }

    public String getHeight() {
        return height;
    }

    public String getRadius() {
        return radius;
    }

    public void setRadius(String radius) {
        this.radius = radius;
    }

    public float getRadiusValue() {
        if (radius != null && !radius.isEmpty()) {
            mRadiusValue = Float.parseFloat(radius.substring(0, radius.length() - 2));
        }
        return mRadiusValue;
    }

    public void setBackground(String background) {
        this.background = background;
    }

    public String getBackground() {
        return background;
    }

    public int getBackgroundColorValue() {
        if (background != null && !background.isEmpty()) {
            mBackgroundColorValue = Color.parseColor(background);
        }
        return mBackgroundColorValue;
    }

    public void setColorPrimary(int colorPrimary) {
        this.colorPrimary = colorPrimary;
    }

    public int getColorPrimary() {
        return colorPrimary;
    }

    public void setBorder(String border) {
        this.border = border;
    }

    public float getBorderValue() {
        if (border != null && !border.isEmpty()) {
            mBorderValue = Float.parseFloat(border.substring(0, border.length() - 2));
        }
        return mBorderValue;
    }

    public String getBorder() {
        return border;
    }
}
