package com.meizu.flyme.activeview.json;

/**
 * Created by meizu on 16/11/5.
 */
public class UpgradeActiveBean {

    private boolean existsUpdate;

    private String pluginName;

    private String digest;

    private String latestVersion;

    private String needUpdate;

    private String releaseDate;

    private String releaseNote;

    private String serviceName;

    private long size;

    private int pluginType;

    private String updateUrl;

    private String updateUrl2;

    private int verifyMode;

    private String targetAppName;

    private int customId;

    public UpgradeActiveBean() {}

    public boolean isExistsUpdate() {
        return existsUpdate;
    }

    public void setExistsUpdate(boolean existsUpdate) {
        this.existsUpdate = existsUpdate;
    }

    public String getPluginName() {
        return pluginName;
    }

    public void setPluginName(String pluginName) {
        this.pluginName = pluginName;
    }

    public String getDigest() {
        return digest;
    }

    public void setDigest(String digest) {
        this.digest = digest;
    }

    public String getLatestVersion() {
        return latestVersion;
    }

    public void setLatestVersion(String latestVersion) {
        this.latestVersion = latestVersion;
    }

    public String getNeedUpdate() {
        return needUpdate;
    }

    public void setNeedUpdate(String needUpdate) {
        this.needUpdate = needUpdate;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getReleaseNote() {
        return releaseNote;
    }

    public void setReleaseNote(String releaseNote) {
        this.releaseNote = releaseNote;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public int getPluginType() {
        return pluginType;
    }

    public void setPluginType(int pluginType) {
        this.pluginType = pluginType;
    }

    public String getUpdateUrl() {
        return updateUrl;
    }

    public void setUpdateUrl(String updateUrl) {
        this.updateUrl = updateUrl;
    }

    public String getUpdateUrl2() {
        return updateUrl2;
    }

    public void setUpdateUrl2(String updateUrl2) {
        this.updateUrl2 = updateUrl2;
    }

    public int getVerifyMode() {
        return verifyMode;
    }

    public void setVerifyMode(int verifyMode) {
        this.verifyMode = verifyMode;
    }

    public String getTargetAppName() {
        return targetAppName;
    }

    public void setTargetAppName(String targetAppName) {
        this.targetAppName = targetAppName;
    }

    public int getCustomId() {
        return customId;
    }

    public void setCustomId(int customId) {
        this.customId = customId;
    }

    @Override
    public String toString() {
        return "UpgradeActiveBean{" +
                "existsUpdate=" + existsUpdate +
                ", pluginName='" + pluginName + '\'' +
                ", digest='" + digest + '\'' +
                ", latestVersion='" + latestVersion + '\'' +
                ", needUpdate='" + needUpdate + '\'' +
                ", releaseDate='" + releaseDate + '\'' +
                ", releaseNote='" + releaseNote + '\'' +
                ", serviceName='" + serviceName + '\'' +
                ", size=" + size +
                ", pluginType=" + pluginType +
                ", updateUrl='" + updateUrl + '\'' +
                ", updateUrl2='" + updateUrl2 + '\'' +
                ", verifyMode=" + verifyMode +
                ", targetAppName='" + targetAppName + '\'' +
                ", customId=" + customId +
                '}';
    }
}
