package com.meizu.flyme.activeview.version;

/**
 * Created by suyouxiong on 2016/11/11.
 */
public class Version {
    public static final String VERSION = "2.1.0";
}
