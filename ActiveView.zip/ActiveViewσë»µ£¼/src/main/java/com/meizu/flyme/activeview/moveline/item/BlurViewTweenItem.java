package com.meizu.flyme.activeview.moveline.item;

import android.view.View;

import java.lang.ref.WeakReference;

/**
 * Created by suyouxiong on 16-6-22.
 */
public class BlurViewTweenItem extends ViewTweenItem {

    public static final String BLUR = "blur";

    public BlurViewTweenItem(View target) {
        super(target);
    }

    @Override
    public void updateProperty(String propertyName, Object value, float fraction) {
        super.updateProperty(propertyName, value, fraction);
//        View targetView = mTarget.get();
//        if (targetView == null) return;
//        try {
//            if (propertyName.equals(BLUR)) {
//                BaseActiveItemView animImageView = (BaseActiveItemView)targetView;
//                if (animImageView != null) {
//                    animImageView.setBlurLevel((Float) value);
//                }
//            }
//        } catch (ClassCastException e) {
//            Log.e(Config.MOVELINE_LOG_TAG, "the value type of the property " + propertyName + " is illegal:" + e.getMessage());
//        }
    }

    @Override
    public Object getPropertyValue(String propertyName) {

//        View targetView = mTarget.get();
//        if (targetView == null) return null;
//        if (propertyName.equals(BLUR)) {
//            BaseActiveItemView animImageView = (BaseActiveItemView)targetView;
//            if (animImageView != null) {
//                return animImageView.getBlurLevel();
//            }
//        }
        return super.getPropertyValue(propertyName);
    }

    @Override
    public FrameStyle buildFrameStyle() {
        return new BlurViewFrameStyle();
    }

    public void setTarget(View target) {
        mTarget = new WeakReference<>(target);
    }
}
