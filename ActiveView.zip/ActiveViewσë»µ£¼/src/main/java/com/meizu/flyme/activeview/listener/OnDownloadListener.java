package com.meizu.flyme.activeview.listener;

/**
 * Created by meizu on 16/9/21.
 */
public interface OnDownloadListener {
    int DOWNLOAD_FAIL = 0x0;
    int DOWNLOAD_SUCESS = 0x1;
    int DOWNLOAD_FILE_DATA_ERROR = 0x3;
    int DOWNLOAD_FILE_LENGTH_ERROR = 0x4;

    void onDownloadStart(String url);

    void onDownloadError(int responseCode);

    void onDownloadFinished(int result, String file);
}
