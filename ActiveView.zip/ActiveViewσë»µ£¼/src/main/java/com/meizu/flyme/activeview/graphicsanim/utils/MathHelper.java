package com.meizu.flyme.activeview.graphicsanim.utils;

import java.util.Random;

public class MathHelper {
    public static Random rand = new Random();
    public static float randomRange(float min, float max) {


        int randomNum = rand.nextInt(((int) max - (int) min) + 1) + (int) min;

        return randomNum;
    }


    /**
     * @param value 波动中心值
     * @param amplitude 振幅
     * @return 随机生成一个[value-amplitude, value+amplitude]范围内的值
     */
    public static float getFlexibleValue(float value, float amplitude) {
        return rand.nextFloat() * amplitude * 2 + value - amplitude;
    }
}
