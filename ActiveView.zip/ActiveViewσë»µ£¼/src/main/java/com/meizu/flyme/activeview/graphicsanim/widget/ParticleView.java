package com.meizu.flyme.activeview.graphicsanim.widget;

import android.content.Context;
import android.os.Bundle;
import android.util.AttributeSet;

import com.meizu.flyme.activeview.graphicsanim.renderable.ParticleSystem;
import com.meizu.flyme.activeview.graphicsanim.renderable.Renderable;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by cjy on 16-11-3.
 */
public class ParticleView extends BaseGraphicsView {

    public ParticleView(Context context) {
        this(context, null);
    }

    public ParticleView(Context context, AttributeSet attrs) {
        this(context, attrs, null);
    }

    public ParticleView(Context context, AttributeSet attrs, List<Bundle> Attrsbundle) {
        super(context, attrs, Attrsbundle);
    }

    @Override
    public void setRenderables(List<Bundle> attrsBundle) {
        List<Bundle> filterBundle = new ArrayList<Bundle>();
        for (int i = 0; i < attrsBundle.size(); i++) {
            Bundle bundle = attrsBundle.get(i);
            String className = bundle.getString(Renderable.ATTR_CLASS_NAME);
            if (className == null || !className.equals(ParticleSystem.CLASS_NAME)) {
                continue;
            }
            filterBundle.add(bundle);
        }
        if (filterBundle.size() > 0) {
            super.setRenderables(filterBundle);
        }
    }

}
