package com.meizu.flyme.activeview.json;

/**
 * Created by meizu on 16/11/8.
 */
import java.util.ArrayList;
import java.util.List;
public class GraphicsAnimAttr {
    private String className;

    private String type;

    private String id;

    private String x;
    private Float mXValue;

    private String y;
    private Float mYValue;

    private String translationX;
    private Float mTranslationXValue;

    private String translationY;
    private Float mTranslationYValue;

    private Float scaleX;

    private Float scaleY;

    private String randomX;
    private Float mRandomXValue;

    private String randomY;
    private Float mRandomYValue;

    private String speedX;
    private Float mSpeedXValue;

    private String speedY;
    private Float mSpeedYValue;

    private String randomSpeedX;
    private Float mRandomSpeedXValue;

    private String randomSpeedY;
    private Float mRandomSpeedYValue;

    private Integer transmitCycle;

    private Integer transmitNum;

    private String regionRadius;
    private Float mRegionRadiusValue;

    private List<String> particleWidth;
    private List<Float> mParticleWidthValues;

    private List<String> particleHeight;
    private List<Float> mParticleHeightValues;

    private int[] colorList;

    private String bitmapPath;

    public GraphicsAnimAttr() {}

    public void setClassName(String className) {
        this.className = className;
    }

    public String getClassName() {
        return this.className;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return this.type;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return this.id;
    }

    public void setX(String x) {
        this.x = x;
    }

    public String getX() {
        return this.x;
    }


    public Float getXValue() {
        if(this.x!= null && !this.x.isEmpty()) {
            mXValue = Float.parseFloat(this.x.substring(0, this.x.length() - 2));
        }
        return mXValue;
    }

    public void setY(String y){
        this.y = y;
    }

    public String getY(){
        return this.y;
    }

    public Float getYValue() {
        if(this.y != null && !this.y.isEmpty()) {
            mYValue = Float.parseFloat(this.y.substring(0, this.y.length() - 2));
        }
        return mYValue;
    }

    public void setTranslationX(String translationX){
        this.translationX = translationX;
    }

    public String getTranslationX(){
        return this.translationX;
    }

    public Float getTranslationXValue() {
        if(translationX != null && !translationX.isEmpty()) {
            mTranslationXValue = Float.parseFloat(translationX.substring(0, translationX.length() - 2));
        }
        return mTranslationXValue;
    }

    public void setTranslationY(String translationY){
        this.translationY = translationY;
    }

    public String getTranslationY(){
        return this.translationY;
    }

    public Float getTranslationYValue() {
        if(translationY != null && !translationY.isEmpty()) {
            mTranslationYValue = Float.parseFloat(translationY.substring(0, translationY.length() - 2));
        }
        return mTranslationYValue;
    }

    public void setScaleX(Float scaleX) {
        this.scaleX = scaleX;
    }

    public Float getScaleX() {
        return this.scaleX;
    }

    public void setScaleY(Float scaleY){
        this.scaleY = scaleY;
    }

    public Float getScaleY(){
        return this.scaleY;
    }

    public void setRandomX(String randomX){
        this.randomX = randomX;
    }

    public String getRandomX(){
        return this.randomX;
    }

    public Float getRandomXValue() {
        if(randomX != null && !randomX.isEmpty()) {
            mRandomXValue = Float.parseFloat(randomX.substring(0, randomX.length() - 2));
        }
        return mRandomXValue;
    }


    public void setRandomY(String randomY){
        this.randomY = randomY;
    }

    public String getRandomY(){
        return this.randomY;
    }

    public Float getRandomYValue() {
        if(randomY != null && !randomY.isEmpty()) {
            mRandomYValue = Float.parseFloat(randomY.substring(0, randomY.length() - 2));
        }
        return mRandomYValue;
    }

    public void setSpeedX(String speedX){
        this.speedX = speedX;
    }

    public String getSpeedX(){
        return this.speedX;
    }

    public Float getSpeedXValue() {
        if(speedX != null && !speedX.isEmpty()) {
            mSpeedXValue = Float.parseFloat(speedX.substring(0, speedX.length() - 2));
        }
        return mSpeedXValue;
    }


    public void setSpeedY(String sppedY) {
        this.speedY = sppedY;
    }

    public String getSpeedY() {
        return this.speedY;
    }

    public Float getSpeedYValue() {
        if(speedY != null && !speedY.isEmpty()) {
            mSpeedYValue = Float.parseFloat(speedY.substring(0, speedY.length() - 2));
        }
        return mSpeedYValue;
    }

    public void setRandomSpeedX(String randomSpeedX){
        this.randomSpeedX = randomSpeedX;
    }

    public String getRandomSpeedX(){
        return this.randomSpeedX;
    }

    public Float getRandomSpeedXValue() {
        if(randomSpeedX != null && !randomSpeedX.isEmpty()) {
            mRandomSpeedXValue = Float.parseFloat(randomSpeedX.substring(0, randomSpeedX.length() - 2));
        }
        return mRandomSpeedXValue;
    }

    public void setRandomSpeedY(String randomSpeedY){
        this.randomSpeedY = randomSpeedY;
    }

    public String getRandomSpeedY(){
        return this.randomSpeedY;
    }

    public Float getmRandomSpeedYValue() {
        if(randomSpeedY != null && !randomSpeedY.isEmpty()) {
            mRandomSpeedYValue = Float.parseFloat(randomSpeedY.substring(0, randomSpeedY.length() - 2));
        }
        return mRandomSpeedYValue;
    }

    public void setTransmitCycle(Integer transmitCycle){
        this.transmitCycle = transmitCycle;
    }

    public Integer getTransmitCycle(){
        return this.transmitCycle;
    }

    public void setTransmitNum(Integer transmitNum) {
        this.transmitNum = transmitNum;
    }

    public Integer getTransmitNum() {
        return this.transmitNum;
    }

    public void setRegionRadius(String regionRadius){
        this.regionRadius = regionRadius;
    }

    public String getRegionRadius(){
        return this.regionRadius;
    }

    public Float getRandomSpeedYValue() {
        if(randomSpeedY != null && !randomSpeedY.isEmpty()) {
            mRandomSpeedYValue = Float.parseFloat(randomSpeedY.substring(0, randomSpeedY.length() - 2));
        }
        return mRandomSpeedYValue;
    }

    public void setParticleWidth(List<String> particleWidth){
        this.particleWidth = particleWidth;
    }

    public List<String> getParticleWidth() {
        return this.particleWidth;
    }

    public List getParticleWidthValue() {
        if (particleWidth != null && !particleWidth.isEmpty()) {
            int size = particleWidth.size();
            if (size > 0) {
                mParticleWidthValues = new ArrayList<>(size);
                for (int i = 0; i < size; i++) {
                    String valueTemp = particleWidth.get(i);
                    if (valueTemp != null && !valueTemp.isEmpty()) {
                        mParticleWidthValues.add(Float.parseFloat(valueTemp.substring(0, valueTemp.length() - 2)));
                    }
                }
            }
        }
        return mParticleWidthValues;
    }

    public void setParticleHeight(List<String> particleHeight){
        this.particleHeight = particleHeight;
    }

    public List<String> getParticleHeight(){
        return this.particleHeight;
    }

    public List getParticleHeightValue() {
        if (particleHeight != null && !particleHeight.isEmpty()) {
            int size = particleHeight.size();
            if (size > 0) {
                mParticleHeightValues = new ArrayList<>(size);
                for (int i = 0; i < size; i++) {
                    String valueTemp = particleHeight.get(i);
                    if (valueTemp != null && !valueTemp.isEmpty()) {
                        mParticleHeightValues.add(Float.parseFloat(valueTemp.substring(0, valueTemp.length() - 2)));
                    }
                }
            }
        }
        return mParticleHeightValues;
    }

    public void setColorList(int[] colorList){
        this.colorList = colorList;
    }

    public int[] getColorList() {
        return this.colorList;
    }

    public void setBitmapPath(String bitmapPath){
        this.bitmapPath = bitmapPath;
    }

    public String getBitmapPath(){
        return this.bitmapPath;
    }

}