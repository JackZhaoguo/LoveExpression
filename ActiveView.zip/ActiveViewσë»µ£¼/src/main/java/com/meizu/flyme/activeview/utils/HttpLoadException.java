package com.meizu.flyme.activeview.utils;

/**
 * Created by fengsh on 15-3-13.
 */
public class HttpLoadException extends Exception {
    private int mResponseCode;
    private boolean mHasResponseCode = false;

    public HttpLoadException(int responseCode, String msg) {
        super(msg);
        mResponseCode = responseCode;
        mHasResponseCode = true;
    }

    public HttpLoadException(String msg) {
        super(msg);
    }

    public int getResponseCode() {
        return mResponseCode;
    }

    public boolean hasHttpResponseCode() {
        return mHasResponseCode;
    }
}
