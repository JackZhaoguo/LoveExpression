package com.meizu.flyme.activeview.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;

/**
 * Created by fengsh on 14-12-6.
 */
public class Md5Helper {
    private final static char[] hexDigits = {'0', '1', '2', '3', '4', '5',
            '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

    // 求文件内容的HASH值
    public static String md5sum(String filename) {
        InputStream is = null;
        try {
            is = new FileInputStream(filename);
            return md5sum(is);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                }
            }
        }
        return null;
    }

    // 求文件内容的HASH值
    public static String md5sum(InputStream is) {
        try {
            int numRead = 0;
            byte[] buffer = new byte[1024];
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            while ((numRead = is.read(buffer)) > 0) {
                md5.update(buffer, 0, numRead);
            }
            String str = encodeHex(md5.digest());
            return str;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String encodeHex(final byte[] data) {
        final int l = data.length;
        final char[] out = new char[l << 1];
        // two characters form the hex value.
        for (int i = 0, j = 0; i < l; i++) {
            out[j++] = hexDigits[(0xF0 & data[i]) >>> 4];
            out[j++] = hexDigits[0x0F & data[i]];
        }
        return new String(out);
    }

    public static String md5sumHeadTail(String filename, final int blockSize) {
        InputStream is = null;
        try {
            File tempFile = new File(filename);
            final long fileLength = tempFile.length();

            if (fileLength < blockSize * 2) {
                LogUtil.e("md5sumHeadTail file length is: " + fileLength);
                return null;
            }

            is = new FileInputStream(filename);

            int numRead = 0;
            int totalRead = 0;
            byte[] buffer = new byte[1024];
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            while ((totalRead < blockSize) && (numRead = is.read(buffer, 0, (blockSize - totalRead > buffer.length ? buffer.length : blockSize - totalRead))) > 0) {
                md5.update(buffer, 0, numRead);
                totalRead += numRead;
            }

            is.close();

            is = new FileInputStream(filename);

            long skipSize = fileLength - blockSize;
            while (skipSize > 0) {
                long numSkip = is.skip(skipSize);
                if (numSkip > 0) {
                    skipSize -= numSkip;
                } else {
                    LogUtil.e("skip file return: " + numSkip);
                }
            }

            // read until file end
            while ((numRead = is.read(buffer)) > 0) {
                md5.update(buffer, 0, numRead);
            }

            String str = encodeHex(md5.digest());
            return str;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                }
            }
        }
        return null;
    }
}
