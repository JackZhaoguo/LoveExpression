package com.meizu.flyme.activeview.json;

/**
 * Created by meizu on 16/11/8.
 */
import android.content.Context;

import com.meizu.flyme.activeview.utils.DisplayUnitUtil;

import java.util.List;

public class Particle2DAttr {
    private static final int ARRAY_LENGTH_2  = 2;

    private String type;

    private String id;

    private String[] position;
    private Float[] mPositionValue = new Float[ARRAY_LENGTH_2];

    private Float[] scale;

    private String[] translation;
    private Float[] mTranslationValue = new Float[ARRAY_LENGTH_2];

    private String[] speed;
    private Float[] mSpeedValue = new Float[ARRAY_LENGTH_2];

    private String[] randomSpeed;
    private Float[] mRandomSpeedValue = new Float[ARRAY_LENGTH_2];

    private String[] offset;
    private Float[] mOffsetValue = new Float[ARRAY_LENGTH_2];

    private Integer transmitCycle;
    private Integer transmitNum;

    private String regionRadius;
    private Float mRegionRadiusValue;

    private List<String> widths;
    private float[] mWidthValues;

    private List<String> heights;
    private float[] mHeightValues;

    private int[] colors;

    private String bitmapPath;

    public Particle2DAttr() {}

    public String[] getPosition() {
        return position;
    }

    public void setPosition(String[] position) {
        if (position.length != ARRAY_LENGTH_2) {
            return;
        }
        this.position = position;
    }

    public Float[] getPositionValue(Context context) {
        if (position != null && position.length == ARRAY_LENGTH_2) {
            for (int i = 0; i < ARRAY_LENGTH_2; i++) {
                if (position[i] != null) {
                    mPositionValue[i] = (float)DisplayUnitUtil.getPixelValue(context, position[i]);   // Float.parseFloat(position[i].substring(0, position[i].length() - 2));
                }
            }
        }
        return mPositionValue;
    }

    public String[] getTranslation() {
        return translation;
    }

    public void setTranslation(String[] translation) {
        if (translation.length != ARRAY_LENGTH_2) {
            return;
        }
        this.translation = translation;
    }

    public Float[] getTranslationValue() {
        if (translation != null && translation.length == ARRAY_LENGTH_2) {
            for (int i = 0; i < ARRAY_LENGTH_2; i++) {
                if (translation[i] != null) {
                    mTranslationValue[i] = Float.parseFloat(translation[i].substring(0, translation[i].length() - 2));
                }
            }
        }
        return mTranslationValue;
    }

    public String[] getSpeed() {
        return speed;
    }

    public void setSpeed(String[] speed) {
        if (speed.length != ARRAY_LENGTH_2) {
            return;
        }
        this.speed = speed;
    }

    public Float[] getSpeedValue(Context context) {
        if (speed != null && speed.length == ARRAY_LENGTH_2) {
            for (int i = 0; i < ARRAY_LENGTH_2; i++) {
                if (speed[i] != null) {
                    mSpeedValue[i] = (float)DisplayUnitUtil.getPixelValue(context, speed[i]);
                }
            }
        }
        return mSpeedValue;
    }

    public String[] getRandomSpeed() {
        return randomSpeed;
    }

    public void setRandomSpeed(String[] randomSpeed) {
        if (randomSpeed.length != ARRAY_LENGTH_2) {
            return;
        }
        this.randomSpeed = randomSpeed;
    }

    public Float[] getRandomSpeedValue(Context context) {
        if (randomSpeed != null && randomSpeed.length == ARRAY_LENGTH_2) {
            for (int i = 0; i < ARRAY_LENGTH_2; i++) {
                if (randomSpeed[i] != null) {
                    mRandomSpeedValue[i] = (float)DisplayUnitUtil.getPixelValue(context, randomSpeed[i]);
                }
            }
        }
        return mRandomSpeedValue;
    }

    public String[] getOffset() {
        return offset;
    }

    public void setOffset(String[] offset) {
        if (offset.length != ARRAY_LENGTH_2) {
            return;
        }
        this.offset = offset;
    }

    public Float[] getOffsetValue(Context context) {
        if (offset != null && offset.length == ARRAY_LENGTH_2) {
            for (int i = 0; i < ARRAY_LENGTH_2; i++) {
                if (offset[i] != null) {
                    mOffsetValue[i] = (float)DisplayUnitUtil.getPixelValue(context, offset[i]);
                }
            }
        }
        return mOffsetValue;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return this.type;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return this.id;
    }

    public void setScale(Float[] scale){
        this.scale = scale;
    }

    public Float[] getScale(){
        return this.scale;
    }

    public void setTransmitCycle(Integer transmitCycle){
        this.transmitCycle = transmitCycle;
    }

    public Integer getTransmitCycle(){
        return this.transmitCycle;
    }

    public void setTransmitNum(Integer transmitNum) {
        this.transmitNum = transmitNum;
    }

    public Integer getTransmitNum() {
        return this.transmitNum;
    }

    public void setRegionRadius(String regionRadius){
        this.regionRadius = regionRadius;
    }

    public String getRegionRadius(){
        return this.regionRadius;
    }

    public Float getRegionRadiusValue(Context context) {
        if(regionRadius != null && !regionRadius.isEmpty()) {
            mRegionRadiusValue = (float)DisplayUnitUtil.getPixelValue(context, regionRadius);
        }
        return mRegionRadiusValue;
    }

    public void setWidths(List<String> widths){
        this.widths = widths;
    }

    public List<String> getWidths() {
        return this.widths;
    }

    public float[] getWidthValues(Context context) {
        if (widths != null && !widths.isEmpty()) {
            int size = widths.size();
            if (size > 0) {
                mWidthValues = new float[size];
                for (int i = 0; i < size; i++) {
                    String valueTemp = widths.get(i);
                    if (valueTemp != null && !valueTemp.isEmpty()) {
                        mWidthValues[i] = (float)DisplayUnitUtil.getPixelValue(context, valueTemp);
                    }
                }
            }
        }
        return mWidthValues;
    }

    public void setHeights(List<String> heights){
        this.heights = heights;
    }

    public List<String> getHeights(){
        return this.heights;
    }

    public float[] getHeightValues(Context context) {
        if (heights != null && !heights.isEmpty()) {
            int size = heights.size();
            if (size > 0) {
                mHeightValues = new float[size];
                for (int i = 0; i < size; i++) {
                    String valueTemp = heights.get(i);
                    if (valueTemp != null && !valueTemp.isEmpty()) {
                        mHeightValues[i] = (float)DisplayUnitUtil.getPixelValue(context, valueTemp);
                    }
                }
            }
        }
        return mHeightValues;
    }

    public void setColors(int[]  colors){
        this.colors = colors;
    }

    public int[]  getColors() {
        return this.colors;
    }

    public void setBitmapPath(String bitmapPath){
        this.bitmapPath = bitmapPath;
    }

    public String getBitmapPath(){
        return this.bitmapPath;
    }

}