package com.meizu.flyme.activeview.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

//import com.meizu.common.renderer.drawable.GLBlurDrawable;
//import com.meizu.common.renderer.effect.GLRenderManager;
//import com.meizu.common.renderer.effect.parameters.BlurParameters;

import static com.meizu.flyme.activeview.views.ActiveViewImpl.ELEMENT_IMAGE;
import static com.meizu.flyme.activeview.views.ActiveViewImpl.ELEMENT_TEXT;

/**
 * Created by suyouxiong on 16-12-2.
 * 毛玻璃覆盖，以实现文本模糊
 */
public class BaseActiveItemView extends FrameLayout {
    private View mContentView;
    private String mType;

//    private GLBlurDrawable mGLBlurDrawable;
    private float mBlurLevel = 0f;

    public BaseActiveItemView(Context context) {
        this(context, ELEMENT_IMAGE);
    }

    public BaseActiveItemView(Context context, String type) {
        super(context);
        mType = type;
        if (type.equals(ELEMENT_IMAGE)) {
            mContentView = new ImageView(context);
            ((ImageView)mContentView).setScaleType(ImageView.ScaleType.FIT_CENTER);
        } else if (type.equals(ELEMENT_TEXT)) {
            mContentView = new TextView(context);
        }
        if (mContentView != null) {
            addView(mContentView);
        }

//        GLRenderManager.getInstance().initialize(context);
        initGLBlurDrawable();
        setWillNotDraw(false);
    }


    private void initGLBlurDrawable() {
//        if (mGLBlurDrawable != null) {
//            return;
//        }
//
//        mGLBlurDrawable = new GLBlurDrawable(true);
//        mGLBlurDrawable.setScale(1.0f);
//
//        mGLBlurDrawable.setRenderMode(BlurParameters.RENDERMODE_CONTINUOUS);
    }

    //不叠加背景，否则透明背景情况会有黑色色快
    public boolean hasOverlappingRendering() {
        return false;
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);

//        if (mGLBlurDrawable != null && mBlurLevel > 0) {
//            mGLBlurDrawable.draw(canvas);
//        }
    }


    public void setBlurLevel(float blurLevel) {;
//        if (blurLevel > 1) {
//            blurLevel = 1.0f;
//        }
//        if (mBlurLevel != blurLevel && mGLBlurDrawable != null) {
//            mBlurLevel = blurLevel;
//            mGLBlurDrawable.setBlurLevel(blurLevel);
//            postInvalidate();
//        }
    }

    public float getBlurLevel() {
        return mBlurLevel;
    }

    public void setText(String text) {
        if (mType.equals(ELEMENT_TEXT)) {
            ((TextView)mContentView).setText(text);
        }
    }

    public void setImage(Drawable image) {
        if (mType.equals(ELEMENT_IMAGE)) {
            ((ImageView)mContentView).setImageDrawable(image);
        }
    }

    @Override
    public void setBackgroundColor(int color) {
        mContentView.setBackgroundColor(color);
    }

    @Override
    public void setBackground(Drawable background) {
        mContentView.setBackground(background);
    }

    @Override
    public void setBackgroundResource(int resid) {
        mContentView.setBackgroundResource(resid);
    }

    @Override
    public void setBackgroundDrawable(Drawable background) {
        mContentView.setBackgroundDrawable(background);
    }

    @Override
    public void setLayoutParams(ViewGroup.LayoutParams params) {
        super.setLayoutParams(params);
        mContentView.setLayoutParams(generateLayoutParams(params));
    }

    /**
     *
     * @return
     */
    public View getContentView() {
        return mContentView;
    }

    public void setContentView(View contentView) {
        if (mContentView != null) {
            removeView(mContentView);
        }
        mContentView = contentView;
        if (contentView != null) {
            addView(contentView);
        }
    }
}
