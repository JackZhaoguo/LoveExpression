package com.meizu.flyme.activeview.utils;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.widget.ImageView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class UpdaterUtils {
    private Context mContext;
    private RequestQueue mQueue;
    private ImageLoader mImageLoader;


    private volatile static UpdaterUtils updaterUtilsInstance;

    public static UpdaterUtils getInstance(Context ctx) {
        if (updaterUtilsInstance == null) {
            synchronized (UpdaterUtils.class) {
                if (updaterUtilsInstance == null) {
                    updaterUtilsInstance = new UpdaterUtils(ctx);
                }
            }
        }
        return updaterUtilsInstance;
    }

    private UpdaterUtils(Context context) {
        mContext = context;
        mQueue = Volley.newRequestQueue(mContext);
        mImageLoader = new ImageLoader(mQueue, new BitmapCache());
    }

    public void loadImage(final ImageView imageView, String imageUrl, final int defaultImageResId, final int errorImageResId) {
        loadImage(imageView, imageUrl, defaultImageResId, errorImageResId, null);
    }

    public void loadImage(final ImageView imageView, String imageUrl, final int defaultImageResId, final int errorImageResId, OnLoadListener listener) {
        ImageLoader.ImageListener imageListener = getImageListener(imageView, defaultImageResId, errorImageResId, listener);
        mImageLoader.get(imageUrl, imageListener);
    }

    public void getJsonByUrl(String url, Response.Listener<JSONObject> listener, Response.ErrorListener errorListener) {
        if (url.isEmpty()) {
            return;
        }
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(url, null, listener, errorListener);
        mQueue.add(jsonObjectRequest);
    }

    public void getJsonPost(String url, JSONObject params, Response.Listener listener, Response.ErrorListener errorListener) {
        if (url.isEmpty()) {
            return;
        }
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, url, params,listener, errorListener) {

            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("Accept", "application/json");
                headers.put("Content-Type", "application/json; charset=UTF-8");
                return headers;
            }
        };
        mQueue.add(jsonObjectRequest);
    }

    public ImageLoader.ImageListener getImageListener(final ImageView view, final int defaultImageResId, final int errorImageResId, final OnLoadListener listener) {
        return new ImageLoader.ImageListener() {

            BitmapDrawable bitmapDrawable = null;
            Resources res = mContext.getResources();
            @Override
            public void onErrorResponse(VolleyError error) {
                LogUtil.i("onErrorResponse error=" + error.toString());
                if (errorImageResId != 0) {
                    Bitmap bitmap = BitmapFactory.decodeResource(res, errorImageResId);
                    if (bitmap != null) {
                        bitmapDrawable = new BitmapDrawable(res, bitmap);
                    }
                    if (bitmapDrawable != null) {
                        view.setImageDrawable(bitmapDrawable);
                    }

                    if (listener != null) {
                        listener.onLoadError(OnLoadListener.LOADIMAGE_FAIL, error.toString());
                    }
                }
            }

            @Override
            public void onResponse(ImageLoader.ImageContainer response, boolean isImmediate) {
                if (response.getBitmap() != null) {
                    Bitmap bitmap = response.getBitmap();
                    if (bitmap != null) {
                        bitmapDrawable = new BitmapDrawable(res, bitmap);
                    }
                    if (bitmapDrawable != null) {
                        view.setImageDrawable(bitmapDrawable);
                    }
                    if (listener != null) {
                        listener.onLoadFinished(OnLoadListener.LOADIMAGE_SUCESS, bitmap);
                    }
                } else if (defaultImageResId != 0) {
                    Bitmap bitmap = BitmapFactory.decodeResource(res, defaultImageResId);
                    if (bitmap != null) {
                        bitmapDrawable = new BitmapDrawable(res, bitmap);
                    }
                    if (bitmapDrawable != null) {
                        view.setImageDrawable(bitmapDrawable);
                    }
                    if (listener != null) {
                        listener.onLoadError(OnLoadListener.LOADIMAGE_FAIL, "Use Default image defaultImageResId=" + defaultImageResId);
                    }
                }
            }
        };
    }

    public class BitmapCache implements ImageLoader.ImageCache {
        @Override
        public Bitmap getBitmap(String url) {
            return ImageCacheUtils.getInstance().getBitmapFromImageCache(url);
        }

        @Override
        public void putBitmap(String url, Bitmap bitmap) {
            ImageCacheUtils.getInstance().putBitmapToImageCache(url, bitmap);
        }
    }

    public interface OnLoadListener {
        int LOADIMAGE_FAIL = 0x0;
        int LOADIMAGE_SUCESS = 0x1;
        void onLoadFinished(int state, Bitmap result);
        void onLoadError(int state, String errStr);
    }
}
