package com.meizu.flyme.activeview.adapter;

import android.view.View;

public interface ViewAdapter {
    View getView(String viewType);      // 根据viewType返回view实例
}