package com.meizu.flyme.activeview.graphicsanim.renderable;

/**
 * 粒子类
 */
public class Particle {

    public float startX;
    public float startY;
    public float x;
    public float y;
    public float randomSpeedX;
    public float randomSpeedY;
    public long lastRandomSizeChange;
    public float moveDistance;
    public float width;
    public float height;

    public Particle(float x, float y, float randomSpeedX, float randomSpeedY) {
        this.x = x;
        this.y = y;
        this.startX = x;
        this.startY = y;
        this.randomSpeedX = randomSpeedX;
        this.randomSpeedY = randomSpeedY;
        lastRandomSizeChange = System.currentTimeMillis();
    }

    public void setRandomSpeed(float randomSpeedX, float randomSpeedY) {
        this.randomSpeedX = randomSpeedX;
        this.randomSpeedY = randomSpeedY;

    }

    public String toString() {
        return String.format("Particle(%s): startX = %s, startY = %s, x =%s, y = %s, randomSpeedX = %s, randomSpeedY = %s, width = %s, height = %s;",
                this.hashCode(), this.startX, this.startY, this.x, this.y,this.randomSpeedX,this.randomSpeedY, this.width, this.height);
    }
}
