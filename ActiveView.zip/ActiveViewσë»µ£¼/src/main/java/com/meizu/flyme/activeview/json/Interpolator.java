package com.meizu.flyme.activeview.json;

/**
 * Created by meizu on 16/7/22.
 */
public class Interpolator {
    private String name;

    private Args args;

    public Interpolator() {}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Args  getArgs() {
        return args;
    }

    public void setArgs(Args args) {
        this.args = args;
    }
}
