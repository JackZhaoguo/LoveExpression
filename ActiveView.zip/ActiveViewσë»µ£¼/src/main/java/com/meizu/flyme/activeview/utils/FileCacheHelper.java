package com.meizu.flyme.activeview.utils;

import android.content.Context;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;

import java.io.File;

public class FileCacheHelper {

    private static final String TAG = "FileCacheManager";

    private static final String FILE_HEAD = "update_cache_";
    private static final String FILE_TAIL_TEMP = ".temp";
    private static final String FILE_TAIL_JAR = ".jar";

    /**
     * clear cache file, call it while no update exist
     **/
    public static void clearCache(Context context) {
        clearCache(context, null);
    }

    /**
     * clear cache exclude target version
     **/
    public static void clearCache(Context context, String excludeVersion) {
        String cachePath = getCachePath(context.getPackageName());

        String excludeTemp = null;
        String excludeApk = null;
        // excludeTemp excludeApk is null while no target version
        if (!TextUtils.isEmpty(excludeVersion)) {
            excludeTemp = getCacheFileName(excludeVersion);
            excludeApk = getApkFileName(excludeVersion);
        }

        File file = new File(cachePath);
        if (file.exists()) {
            if (!file.isDirectory()) {
                file.delete();
            } else {
                File[] files = file.listFiles();
                if (files != null && files.length > 0) {
                    for (File f : files) {
                        if (f.isFile()
                                && (excludeTemp == null || !f.getName().equals(excludeTemp))
                                && (excludeApk == null || !f.getName().equals(excludeApk))) {
                            log("delete cache file : " + f.getName());
                            f.delete();
                        }
                    }
                }
            }
        }
    }

    /**
     * 清除当前版本的apk缓存
     */
    public static void clearCurrentCacheApp(Context context) {
        String packageName = context.getPackageName();
        String cachePath = getCachePath(packageName);
        String currentVersion = Utility.getAppVersionString(context, packageName);
        String targetFile = getApkFileName(currentVersion);
        File file = new File(cachePath + targetFile);
        if (file.exists()) {
            log("delete cur cache : " + file.getName());
            file.delete();
        }
    }

    public static final String getCacheFilePath(Context context, String versionName) {
        String tempFileName = getCacheFileName(versionName);
        String cachePath = getCachePath(context.getPackageName());
        return cachePath + tempFileName;

    }

    public static final String getApkFilePath(Context context, String versionName) {
        String tempFileName = getApkFileName(versionName);
        String cachePath = getCachePath(context.getPackageName());
        return cachePath + tempFileName;
    }

    private static final String getCacheFileName(String versionName) {
        return FILE_HEAD + versionName + FILE_TAIL_TEMP;
    }

    private static final String getApkFileName(String versionName) {
        return FILE_HEAD + versionName + FILE_TAIL_JAR;
    }

    private static final String getCachePath(String packageName) {
        return Environment.getExternalStorageDirectory().getAbsolutePath() + "/Android/data/" + packageName + "/InstallCache/";
    }

    /**
     * 重命名一个文件
     */
    public static final boolean renameFile(String srcPath, String destPath) {
        try {
            File srcFile = new File(srcPath);
            File destFile = new File(destPath);
            return srcFile.renameTo(destFile);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private static void log(String msg) {
        Log.d(TAG, msg);
    }
}
