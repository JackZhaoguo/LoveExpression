package com.meizu.flyme.activeview.handler;

import android.view.View;

import com.meizu.flyme.activeview.json.Event;
import com.meizu.flyme.activeview.listener.OnEventListener;
import com.meizu.flyme.activeview.views.ActiveView;
import com.meizu.flyme.activeview.views.IActiveView;

/**
 * Created by suyouxiong on 2016/10/20.
 */
public abstract class EventHandler{

    protected Event mEvent;
    protected View mView;
    protected String mId;
    protected OnEventListener mOnEventListener;

    public static EventHandler registerEventHandler(View view, String id, Event event) {
        switch (event.getType()) {
            case Event.TYPE_CLICK:
                return new ClickHandler(view, id, event);
        }
        return null;
    }

    protected EventHandler(View view, String id, Event event) {
        mView = view;
        mEvent = event;
        mId = id;
    }

    public void setOnEventListener(OnEventListener onEventListener) {
        mOnEventListener = onEventListener;
    }
}
