package com.meizu.flyme.activeview.listener;

import android.view.View;

/**
 * Created by meizu on 16/10/22.
 */
public interface OnParallaxListener {

    void onUpdateParallaxData(View view,Float[] range);
}
