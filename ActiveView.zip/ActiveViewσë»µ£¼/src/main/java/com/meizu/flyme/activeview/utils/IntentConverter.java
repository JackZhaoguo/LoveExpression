package com.meizu.flyme.activeview.utils;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import java.net.URISyntaxException;

/**
 * Created by Mason on 2016/5/27.
 *
 * copy from git@gitlab.meizu.com:media.droid/libs.git
 */
public class IntentConverter {

    /**
     * 拓展的intent转String; 产生的String能够兼容Intent.parseUri
     * @param intent
     * @return
     */
    public static String intent2String(Intent intent) {
        if (intent == null) {
            return null;
        }
        Bundle bundle = intent.getExtras();
        String intentString = intent.toUri(0);
        //原有string保持不变，这里为了保证对原生Intent.parseUri的支持
        String bundleString = bundle2String(bundle, true);
        if (bundleString != null) {
            intentString += ";b_start;" + bundleString + "b_end";
        }
        return intentString;
    }

    private static String bundle2String(Bundle bundle, boolean justBundleType) {
        if (bundle == null) {
            return null;
        }
        StringBuilder uri = null;
        for (String key : bundle.keySet()) {
            final Object value = bundle.get(key);
            char entryType = '\0';
            if (value instanceof String) {
                entryType = 'S';
            } else if (value instanceof Boolean) {
                entryType = 'B';
            } else if (value instanceof Byte) {
                entryType = 'b';
            } else if (value instanceof Character) {
                entryType = 'c';
            } else if (value instanceof Double) {
                entryType = 'd';
            } else if (value instanceof Float) {
                entryType = 'f';
            } else if (value instanceof Integer) {
                entryType = 'i';
            } else if (value instanceof Long) {
                entryType = 'l';
            } else if (value instanceof Short) {
                entryType = 's';
            } else if (value instanceof Bundle) {
                entryType = 'D';
            }

            if (entryType != '\0') {
                if (justBundleType && entryType != 'D') {
                    continue;
                }
                if (uri == null) {
                    uri = new StringBuilder();
                }
                uri.append(entryType);
                uri.append('.');
                uri.append(Uri.encode(key));
                uri.append('=');
                if (entryType == 'D') {
                    uri.append(Uri.encode(bundle2String((Bundle) value, false)));
                } else {
                    uri.append(Uri.encode(value.toString()));
                }
                uri.append(';');
            }
        }
        return uri == null ? null : uri.toString();
    }

    /**
     * 拓展的String转Intent; 能够兼容原生的Intent.toUri
     * @param uri
     * @return
     * @throws URISyntaxException
     */
    public static Intent parseUri(String uri) throws URISyntaxException {
        Intent intent = Intent.parseUri(uri, 0);
        int start = uri.indexOf(";b_start");
        int end = uri.indexOf(";b_end");

        if (start > 0 && end > 0 && start + 8 < end) {
            String bundleString = uri.substring(start + 9, end + 1);
            Bundle bundle = string2Bundle(bundleString);
            if (bundle != null) {
                intent.putExtras(bundle);
            }
        }
        return intent;
    }

    /**
     * string转bundle
     * @param bundleString
     * @return
     */
    private static Bundle string2Bundle(String bundleString) {
        if (bundleString == null) {
            return null;
        }
        Bundle b = new Bundle();
        int i = 0;
        while (i >= 0 && i < bundleString.length()) {
            int eq = bundleString.indexOf('=', i);
            int semi = bundleString.indexOf(';', i);
            if (eq < 0 || semi < 0) {
                return null;
            }
            if (eq > semi || eq < i+1) {
                i = semi + 1;
                continue;
            }

            String value = Uri.decode(bundleString.substring(eq + 1, semi));
            String key = Uri.decode(bundleString.substring(i + 2, eq));
            // create Bundle if it doesn't already exist
            if      (bundleString.startsWith("S.", i)) b.putString(key, value);
            else if (bundleString.startsWith("B.", i)) b.putBoolean(key, Boolean.parseBoolean(value));
            else if (bundleString.startsWith("b.", i)) b.putByte(key, Byte.parseByte(value));
            else if (bundleString.startsWith("c.", i)) b.putChar(key, value.charAt(0));
            else if (bundleString.startsWith("d.", i)) b.putDouble(key, Double.parseDouble(value));
            else if (bundleString.startsWith("f.", i)) b.putFloat(key, Float.parseFloat(value));
            else if (bundleString.startsWith("i.", i)) b.putInt(key, Integer.parseInt(value));
            else if (bundleString.startsWith("l.", i)) b.putLong(key, Long.parseLong(value));
            else if (bundleString.startsWith("s.", i)) b.putShort(key, Short.parseShort(value));
            else if (bundleString.startsWith("D.", i)) b.putBundle(key, string2Bundle(value));
            // move to the next item
            i = semi + 1;
        }
        return b;
    }

}
