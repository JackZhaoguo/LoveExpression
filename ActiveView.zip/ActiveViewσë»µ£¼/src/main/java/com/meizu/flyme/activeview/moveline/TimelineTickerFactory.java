package com.meizu.flyme.activeview.moveline;

import android.os.SystemClock;
import android.util.Log;
import android.view.Choreographer;

/**
 * Created by suyouxiong on 16-6-22.
 */
public class TimelineTickerFactory {

    public static TimelineTicker create() {
        return ChoreographerTimelineTicker.create();
    }

    private static class ChoreographerTimelineTicker extends TimelineTicker {
        private final Choreographer mChoreographer;
        private final Choreographer.FrameCallback mFrameCallback;
        private boolean mActive;
        private long mLastTime;
        private long mStartTime;
        private long mTime;
        private int mFrame;

        public ChoreographerTimelineTicker(Choreographer instance) {
            super();
            mChoreographer = instance;
            mFrameCallback = new Choreographer.FrameCallback() {
                @Override
                public void doFrame(long frameTimeNanos) {
                    if (!mActive) {
                        return;
                    }
                    long currentTime = SystemClock.uptimeMillis();
                    long elapsed = currentTime - mLastTime;
                    mLastTime = currentTime;
                    mTime = (int) (mLastTime - mStartTime);
                    mFrame++;
                    dispatchUpdate();
                    //mChoreographer.postFrameCallback(mFrameCallback);
                    mChoreographer.postFrameCallbackDelayed(mFrameCallback, sFrameDelay);
                }
            };
            mStartTime = SystemClock.uptimeMillis();
            mFrameCallback.doFrame(0);
        }

        private void dispatchUpdate() {
            if (Config.LOCAL_LOG) {
                Log.v(Config.MOVELINE_LOG_TAG, "dispatchUpdate: mTime = " + mTime);
            }
            if (mListeners == null || mListeners.size() == 0) return;
            for (TimelineTickerListener listener : mListeners) {
                listener.onUpdate(mTime);
            }
        }

        public static ChoreographerTimelineTicker create() {
            return new ChoreographerTimelineTicker(Choreographer.getInstance());
        }

        @Override
        public void start() {
            if (mActive) {
                return;
            }
            mActive = true;
            mChoreographer.removeFrameCallback(mFrameCallback);
            mFrameCallback.doFrame(0);
        }

        @Override
        public void stop() {
            mActive = false;
            mChoreographer.removeFrameCallback(mFrameCallback);
        }

        @Override
        public long getTime() {
            return mTime;
        }

        @Override
        public boolean isActive() {
            return mActive;
        }

        @Override
        public void wake() {
            start();
        }

        @Override
        public int getFrame() {
            return mFrame;
        }
    }
}
