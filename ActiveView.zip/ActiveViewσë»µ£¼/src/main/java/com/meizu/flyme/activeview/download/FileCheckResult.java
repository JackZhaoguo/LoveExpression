package com.meizu.flyme.activeview.download;

/**
 * Created by fengsh on 15-1-21.
 */
public class FileCheckResult {
    private final boolean mIsMatch;
    private final String mErrorMsg;

    private FileCheckResult(boolean isMatch, String errorMsg) {
        mIsMatch = isMatch;
        mErrorMsg = errorMsg;
    }

    protected static FileCheckResult instanceSuccessResult() {
        return new FileCheckResult(true, null);
    }

    protected static FileCheckResult instanceErrorResult(String msg) {
        return new FileCheckResult(false, msg);
    }

    public boolean isMatch() {
        return mIsMatch;
    }

    public String getErrorMsg() {
        return mErrorMsg;
    }
}
