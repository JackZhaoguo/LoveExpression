package com.meizu.flyme.activeview.moveline;

/**
 * Created by suyouxiong on 16-7-15.
 */
public class AnimationListenerAdapter implements AnimationListener {
    @Override
    public void onAnimationEnd(Animation animation) {

    }

    @Override
    public void onAnimationStopped(Animation animation) {

    }

    @Override
    public void onAnimationStart(Animation animation) {

    }
}
