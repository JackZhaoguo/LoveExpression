package com.meizu.flyme.activeview.moveline;

/**
 * Created by suyouxiong on 16-7-12.
 */
public class Config {
    public static final boolean LOCAL_LOG = false;

    public static final String MOVELINE_LOG_TAG = "moveline";
}
