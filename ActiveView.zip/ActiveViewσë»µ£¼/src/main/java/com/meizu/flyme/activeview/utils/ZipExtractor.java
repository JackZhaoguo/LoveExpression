package com.meizu.flyme.activeview.utils;


import android.os.AsyncTask;

import com.meizu.flyme.activeview.listener.OnZipExtractListener;
import com.meizu.flyme.activeview.task.ZipExtractTask;

public class ZipExtractor {
    /**
     * Extract zip file with a decrypt password.
    * @param inFile  The zip file to be extracted. ex.
    * @param outputDir The output dir for cache the extracted files.
    * @param password  The decrypt password.
    * @param listener  The extract state listener.
    */
    public static AsyncTask extractFileAsync(String inFile, String outputDir, String password, OnZipExtractListener listener) {
        ZipExtractTask task = new ZipExtractTask(inFile, outputDir, password, listener);
        task.execute();
        return task;
    }

    /**
     * Extract a un-encrypt zip file.
     **/
    public static AsyncTask extractFileAsync(String inFile, String outputDir, OnZipExtractListener listener) {
        ZipExtractTask task = new ZipExtractTask(inFile, outputDir, null, listener);
        task.execute();
        return task;
    }

    public static String extractFile(String inFile, String outputDir, String password) {
        ZipExtractTask task = new ZipExtractTask(inFile, outputDir, password);
        return task.doUnzipSync();
    }

    public static String extractFile(String inFile, String outputDir) {
        return extractFile(inFile, outputDir, null);
    }
}
