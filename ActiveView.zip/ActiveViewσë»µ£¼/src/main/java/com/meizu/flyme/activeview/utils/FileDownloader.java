package com.meizu.flyme.activeview.utils;


import android.os.AsyncTask;

import com.meizu.flyme.activeview.listener.OnDownloadListener;
import com.meizu.flyme.activeview.task.DownloadTask;

public class FileDownloader {
    public static AsyncTask downloadFileAsync(String url, String outputDir, OnDownloadListener listener) {
        DownloadTask task = new DownloadTask(url, outputDir, listener);
        task.execute();
        return task;
    }

    public static String downloadFile(String inFile, String outputDir) {
        DownloadTask task = new DownloadTask(inFile, outputDir);
        return task.doDownloadSync();
    }
}
