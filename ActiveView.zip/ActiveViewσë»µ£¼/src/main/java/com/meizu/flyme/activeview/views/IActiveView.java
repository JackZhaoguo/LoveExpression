package com.meizu.flyme.activeview.views;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.FrameLayout;

import com.meizu.flyme.activeview.listener.OnActiveViewUpgradeListener;
import com.meizu.flyme.activeview.listener.OnEventListener;
import com.meizu.flyme.activeview.listener.OnLoadImageListener;
import com.meizu.flyme.activeview.listener.OnParallaxListener;
import com.meizu.flyme.activeview.listener.OnUpdateListener;
import com.meizu.flyme.activeview.listener.OnVersionListener;
import com.meizu.flyme.activeview.utils.ImageCache;

/**
 * Created by meizu on 16/11/5.
 */

public abstract class IActiveView extends FrameLayout {

    /**
     * Normal constructor.
     *
     * @param context The context.
     */
    public IActiveView(Context context) {
        this(context, false);
    }

    /**
     * Constructor indicate if use assets resources or not.
     *
     * @param context            The context.
     * @param useAssetsResources Indicate use default resources in assets or not.
     */
    public IActiveView(Context context, boolean useAssetsResources) {
        super(context);
    }

    /**
     * Constructor with default image.
     *
     * @param context       The context.
     * @param defaultWidth  The default image width, it means the activeview is initial size.
     * @param defaultHeight The default image height.
     * @param defaultResId  The default image resource id.
     */
    public IActiveView(Context context, int defaultWidth, int defaultHeight, int defaultResId) {
        this(context, false);
    }

    public IActiveView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    /**
     * Get the pssward for extracting zip file.
     */
    public abstract String getPassword();

    /**
     * Set the pssward for extracting zip file.
     */
    public abstract void setPassword(String pwd);

    /**
     * Indicate use default resources in assets or not.
     *
     * @param useAssetsResources If want to use asset resources after creating ActiveView, set it to be true.
     */
    public abstract void setUseAssetsResources(boolean useAssetsResources);

    /**
     * Set the default image of activeview.
     *
     * @param defaultWidth  The image width.
     * @param defaultHeight The image height.
     * @param defaultResId  The image resource id.
     */
    public abstract void setDefaultImage(int defaultWidth, int defaultHeight, int defaultResId);

    /**
     * Set the default image of activeview without width and height value.
     *
     * @param defaultResId The image resource id.
     */
    public abstract void setDefaultImage(int defaultResId);

    /**
     * Set the default image of activeview.
     *
     * @param defaultWidth  The image width.
     * @param defaultHeight The image height.
     * @param bitmap        The image bitmap.
     */
    public abstract void setDefaultImage(int defaultWidth, int defaultHeight, Bitmap bitmap);

    /**
     * Set the default image of activeview without width and height value.
     *
     * @param bitmap    The image bitmap.
     */
    public void setDefaultImage(Bitmap bitmap) {
        setDefaultImage(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, bitmap);
    }

    /**
     * Set the default image of activeview without width and height value.
     *
     * @param drawable    The image drawable.
     */
    public abstract void setDefaultImage(Drawable drawable);

    /**
     * Set the default image of activeview.
     *
     * @param defaultWidth  The image width.
     * @param defaultHeight The image height.
     * @param drawable        The image drawable.
     */
    public abstract void setDefaultImage(int defaultWidth, int defaultHeight, Drawable drawable);

    /**
     * Return the theme color.
     */
    public abstract int getColorPrimary();

    /**
     * Update resources for the given url.
     *
     * @param url The resources file url to get data.
     */
    public abstract void updateResource(String url);

    public abstract void setOnUpdateListener(OnUpdateListener listener);

    public abstract void setParallaxListener(OnParallaxListener listener);

    public abstract void setParallaxListener(Boolean useParallax);

    /**
     * Download image for the given url.
     *
     * @param url The image url.
     */
    public abstract void downloadImage(String url);

    /**
     * Download image for the given url with listener.
     *
     * @param url      The image url.
     * @param listener The listener for loading image result.
     */
    public abstract void downloadImage(String url, OnLoadImageListener listener);

    /**
     * Set the listener for loading image.
     *
     * @param listener The listener for loading image result.
     */
    public abstract void setOnLoadImageListener(OnLoadImageListener listener);

    /**
     * Play video for the given url.
     *
     * @param url The video url.
     */
    public abstract void downloadVideo(String url, int width, int height);

    /**
     * Download files for the given url.
     *
     * @param url The zip file url to get the resourc data.
     */
    public abstract void downloadPackage(String url);

    /**
     * Download files for the given url.
     *
     * @param url        The zip file url to get the resourc data.
     * @param listener   The listener for loading package. If it's not null, when load package resources finished, it will be called.
     */
    public abstract void downloadPackage(String url, OnLoadImageListener listener);


    /**
     * Get the Url this ActiveView using.
     */
    public abstract String getUrl();

    /**
     * Load ActiveView resource by given a act file.
     * @param actFile   The act filepath.
     */
    public abstract void loadResourceFile(String actFile);

    /**
     * Cancel all loading image tasks.
     */
    public abstract void cancelLoadImage();

    /**
     * Load ActiveView data by given path of extracted directory.
     * It has data.jason and images under the directory.
     *
     * @param zipExtractedPath The directory of saved the files.
     */
    public abstract void loadData(String zipExtractedPath);

    /**
     * Set ActiveData data to this ActiveView, it will be called after data.json is parsed.
     *
     * @param activeData The active data.
     */
//    public abstract void setData(ActiveData activeData);


    /**
     * Get this ActiveView's version.
     */
    public abstract String getVersion();

    /**
     * Display the package from web.
     * @param webUrl     The web request url.
     */
    public void loadFromWeb(String webUrl) {
        loadFromWeb(webUrl, 0, 0);
    }

    public abstract void loadFromWeb(String webUrl, int width, int height);

    /**
     * Set the flag to control if auto run the animation when loading resources finished.
     * @param autoRunAnimation  The flag to set.
     */
    public abstract void setAutoRunAnimation(boolean autoRunAnimation);

    public abstract void setAutoGradientDisplay(boolean autoGradientDisplay);

    public abstract Bitmap getActiveViewBitmap();

    public abstract void gotoAnimEnd();

    public abstract void gotoAnimStart();

    /**
     * Set ImageCache for the ActiveView. If set by app, it must be called before updateResource()
     *
     * @param imageCache  The cache used to cache image, it can be set by app.
     */
    public abstract void setImageCache(ImageCache imageCache);

    public abstract void clearImageCache();


    /**
     * Set OnEventListener.
     *
     * @param listener The listener set to the view as callback when event happened.
     */
    public abstract void setOnEventListener(OnEventListener listener);

    /**
     * Set OnVersionListener.
     *
     * @param listener The listener set to the ActiveView as callback when version changed.
     */
    public abstract void setOnVersionListener(OnVersionListener listener);

    /**
     * Returns the visibility of this ActiveView.
     */
    public boolean isShowing() {
        return this.isShown();
    }

    /**
     * Start all timeline animation in this ActiveView.
     */
    public abstract void startAnimation();

    /**
     * Stop all timeline animation in this ActiveView.
     */
    public abstract void stopAnimation();

    /**
     * Pause all timeline animation in this ActiveView.
     */
    public abstract void pauseAnimation();

    /**
     * Resume all timeline animation in this ActiveView.
     */
    public abstract void resumeAnimation();

    /**
     * Cancel all running task.
     */
    public abstract void cancelAllRunningTasks();

    /**
     * Cancel download task.
     */
    public abstract void cancelDownload();

    /**
     * Cancel extract task.
     */
    public abstract void cancelExtract();

    /**
     * Pause video.
     */
    public abstract void pauseVideo();

    /**
     * Start playing video.
     */
    public abstract void startVideo();

    /**
     * Stop video playing.
     */
    public abstract void stopVideo();

     /**
     * Set text content.
     *
     * @param id   The id which textview.
     * @param content  The content.
     */
    public abstract void setTextContent(String id, String content);

    /**
     * for the proxy view
     * @param onActiveViewUpgradeListener
     */
    protected void setOnActiveViewUpgradeListener(OnActiveViewUpgradeListener onActiveViewUpgradeListener) {}

    /**
     * The amount of time, in milliseconds, between each frame of the animation
     * @param time
     */
    public abstract void setFrameDelay(long time);
}

