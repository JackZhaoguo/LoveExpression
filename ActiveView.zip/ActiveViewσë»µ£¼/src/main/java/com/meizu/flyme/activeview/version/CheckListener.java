package com.meizu.flyme.activeview.version;


import com.meizu.flyme.activeview.json.UpgradeActiveBean;

public interface CheckListener {

    public static final int CODE_SUCCESS = 0;
    public static final int CODE_CANCEL = 1;
    public static final int CODE_FAIL = 2;

    /**
     * 检查结束之后，会在这里回调通知结果
     *
     * @param code 状态码
     * @param info 如果检测成功，这里返回更新信息
     */
    public void onCheckEnd(int code, UpgradeActiveBean info);
}
