package com.meizu.flyme.activeview.version;

import android.content.Context;

import com.meizu.flyme.activeview.json.UpgradeActiveBean;
import com.meizu.flyme.activeview.utils.Constants;
import com.meizu.flyme.activeview.utils.LogUtil;
import com.meizu.flyme.activeview.utils.Utility;

public class BaseChecker {

    private Context mContext;
    private CheckListener mListener;

    protected BaseChecker(Context context, CheckListener listener) {
        if (context == null || listener == null) {
            throw new IllegalArgumentException("listener and context cant be null");
        }
        mListener = listener;
        mContext = context;
    }

    protected UpgradeActiveBean invoke() {

        boolean hasNetwork = Utility.isNetworkAvailable(mContext);

        if (!hasNetwork) {
            LogUtil.w("request check no network : " + mContext.getPackageName());
            return null;
        }
        UpgradeActiveBean info = VersionManager.checkUpdate(mContext);
        if (info != null) {
            LogUtil.i(VersionManager.TAG, "-----upgrade info : " + info.toString());
            if (!info.isExistsUpdate()) {
                return null;
            }
            if (Version.VERSION.compareTo(info.getLatestVersion()) >= 0) {//当前版本比升级信息版本大
                return null;
            }

            if (!Constants.ACTIVE_PACKAGE_NAME.equals(info.getServiceName())) {
                return null;
            }
            if (Constants.ACTIVE_PLUGIN_TYPE != info.getPluginType()) {
                return null;
            }
        } else {
            LogUtil.w(VersionManager.TAG, "check update return null");
        }
        return info;
    }

    protected void endCancel() {
        mListener.onCheckEnd(CheckListener.CODE_CANCEL, null);
    }

    protected void endError() {
        mListener.onCheckEnd(CheckListener.CODE_FAIL, null);
    }

    protected void endSuccess(final UpgradeActiveBean info) {
        mListener.onCheckEnd(CheckListener.CODE_SUCCESS, info);
    }
}
