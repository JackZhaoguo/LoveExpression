package com.meizu.flyme.activeview.graphicsanim.renderable;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;

/**
 * Renderable 为每一个图元对象
 */
public class Renderable {

    public static String CLASS_NAME = Renderable.class.getSimpleName();

    public static final String ATTR_CLASS_NAME = "className";
    public static final String ATTR_ID = "id";

    //粒子起点坐标
    public static final String ATTR_X = "x";
    public static final String ATTR_Y = "y";


    public static final String ATTR_TRANSLATION_X = "translationX";
    public static final String ATTR_TRANSLATION_Y = "translationY";

    public static final String ATTR_SCALE_X = "scaleX";
    public static final String ATTR_SCALE_Y = "scaleY";

    protected String mID;
    protected float mX;
    protected float mY;

    protected float mTranslationY;
    protected float mTranslationX;
    protected Bitmap mBitmap;

    protected float mScaleX = 1f;
    protected float mScaleY = 1f;

    public Renderable(Bundle bundle){
        init();
        updateAttributes(bundle);
    }

    public Renderable(Bitmap bitmap, float x, float y){}

    protected void init(){
        mX = 0;
        mY = 0;
    }


    /**
     * 更新属性,获取不到属性值的情况下，仍用原值
     *
     * @param bundle
     */
    public void updateAttributes(Bundle bundle) {
        if(bundle != null){
            mID = bundle.getString(ATTR_ID, mID);
            mX = bundle.getFloat(ATTR_X, mX);
            mY = bundle.getFloat(ATTR_Y, mY);
        }
    }

    public void draw(Canvas canvas) {
    }

    public void setTranslationY(Float translationY) {
        this.mTranslationY = translationY;
    }

    public float getTranslationY() {
        return mTranslationY;
    }

    public void setTranslationY(float translationY) {
        this.mTranslationY = translationY;
    }

    public float getTranslationX() {
        return mTranslationX;
    }

    public void setTranslationX(float translationX) {
        this.mTranslationX = translationX;
    }

    public void setX(float y) {
        this.mX = y;
    }

    public void setY(float y) {
        this.mY = y;
    }

    public void setScale(float scaleX, float scaleY) {
        this.mScaleX = scaleX;
        this.mScaleY = scaleY;
    }


    public void setID(String id) {
        this.mID = id;
    }

    public String getID() {
        return mID;
    }

    /**
     * @deprecated
     * @param deltaTime
     * @param wind
     */
    public void update(float deltaTime, float wind) {

    }

    public void update(float deltaTime) {

    }

    public void destroy() {
        if (mBitmap != null && !mBitmap.isRecycled()) {
            mBitmap.recycle();
            mBitmap = null;
        }
    }

    public void pause() {

    }

    public void resume() {

    }

    public String printArray(String name, float[] object) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            sb.append(object[i]);
            sb.append(", ");
        }
        return sb.toString();
    }
}

