package com.meizu.flyme.activeview.download;

import android.content.Context;

import com.meizu.flyme.activeview.json.UpgradeActiveBean;
import com.meizu.flyme.activeview.listener.OnDownloadListener;
import com.meizu.flyme.activeview.task.DownloadTask;
import com.meizu.flyme.activeview.utils.Constants;
import com.meizu.flyme.activeview.utils.LogUtil;

import java.io.File;

/**
 * Created by suyouxiong on 16-11-9.
 */
public class UpgradeDownloader implements OnDownloadListener {

    public interface Callback {
        void onSuccess(String filePath);

        void onFail(int code, String filePath);
    }

    private UpgradeActiveBean mUpdateInfo;
    private String mFileDir;
    private Callback mCallback;
    private DownloadTask mDownloadTask;
    private boolean mDownloadRetry;
    private IFileChecker mFileChecker;

    public UpgradeDownloader(Context context, UpgradeActiveBean updateInfo, String outputDir) {
        mUpdateInfo = updateInfo;
        mFileDir = outputDir;
        mDownloadTask = new DownloadTask(updateInfo.getUpdateUrl(), outputDir, Constants.UPGRADE_ACTIVE_JAR_TEMP_FILE_NAME, this);
        mFileChecker = new DownloadFileChecker(context, updateInfo.getVerifyMode(),
                Constants.ACTIVE_PACKAGE_NAME, updateInfo.getSize(), updateInfo.getDigest(), 0);
        mDownloadTask.setFileChecker(mFileChecker);
    }

    public void startDownload(Callback callback) {
        mCallback = callback;
        mDownloadTask.execute();
    }

    private void deleteFile(String filePath) {
        File file = new File(filePath);
        if (file.exists()) {
            file.delete();
        }
    }

    @Override
    public void onDownloadStart(String url) {
    }

    @Override
    public void onDownloadError(int responseCode) {
        File downFile = mDownloadTask.getFile();
        switch (responseCode) {
            case OnDownloadListener.DOWNLOAD_FILE_DATA_ERROR:
            case OnDownloadListener.DOWNLOAD_FILE_LENGTH_ERROR:

                if (downFile != null) {
                    deleteFile(downFile.getAbsolutePath());
                }
                if (!mDownloadRetry) {
                    if (!retryDownload()) {
                        if (mCallback != null) {
                            mCallback.onFail(responseCode, downFile.getAbsolutePath());
                        }
                    }
                    break;
                }
            default:
                mDownloadTask = null;
                if (mCallback != null) {
                    mCallback.onFail(responseCode, downFile.getAbsolutePath());
                }

        }
    }

    @Override
    public void onDownloadFinished(int result, String file) {
        LogUtil.e("updateCheckInfo result= " + result + ", +Download file:" + file);
        if (result == OnDownloadListener.DOWNLOAD_FAIL) {
            if (mDownloadRetry) {
                if (mCallback != null) {
                    mCallback.onFail(OnDownloadListener.DOWNLOAD_FAIL, file);
                }
            } else {
                if (!retryDownload()) {
                    if (mCallback != null) {
                        mCallback.onFail(OnDownloadListener.DOWNLOAD_FAIL, file);
                    }
                }
            }
        } else if (result == OnDownloadListener.DOWNLOAD_SUCESS) {
            if (mCallback != null) {
                mCallback.onSuccess(file);
            }
        }
    }

    private boolean retryDownload() {
        mDownloadRetry = true;
        if (mUpdateInfo.getUpdateUrl2() != null) {
            mDownloadTask = new DownloadTask(mUpdateInfo.getUpdateUrl2(), mFileDir, this);
            mDownloadTask.setFileChecker(mFileChecker);
            mDownloadTask.execute();
            return true;
        }
        return false;
    }
}
