package com.meizu.flyme.activeview.utils;

import android.content.Context;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import dalvik.system.BaseDexClassLoader;

/**
 * Created by suyouxiong on 16-11-8.
 * 用于动态加载新版本jar包
 */
public class ActiveClassLoader extends BaseDexClassLoader{
    /**
     * 因为需要强转为宿主的IActiveView类型，所以需要从宿主的classloader加载IActiveView
     * 而下面的类又是被IActiveView引用的，所以也需要从宿主的classloader加载
     */
    private static final String[] USE_HOST_CLASS_LIST = {
            "com.meizu.flyme.activeview.views.IActiveView",
            "com.meizu.flyme.activeview.listener.OnEventListener",
            "com.meizu.flyme.activeview.listener.OnLoadDataListener",
            "com.meizu.flyme.activeview.listener.OnLoadImageListener",
            "com.meizu.flyme.activeview.listener.OnParallaxListener",
            "com.meizu.flyme.activeview.listener.OnUpdateListener",
            "com.meizu.flyme.activeview.listener.OnVersionListener",
            "com.meizu.flyme.activeview.utils.ImageCache",
            "com.meizu.flyme.activeview.listener.OnActiveViewUpgradeListener"
    };

    public ActiveClassLoader(String dexPath, String optimizedDirectory, String libraryPath, ClassLoader parent) {
        super(dexPath, new File(optimizedDirectory), libraryPath, parent);
    }

    @Override
    protected Class<?> loadClass(String className, boolean resolve) throws ClassNotFoundException {

        Class<?> clazz = null;
        boolean useHost = false;
        for (String c : USE_HOST_CLASS_LIST) {
            if (c.equals(className)) useHost = true;
        }
        if (!useHost) {
            try {
                clazz = findClass(className);
            } catch (ClassNotFoundException e) {

            }
        }

        if (clazz == null) {
            clazz = super.loadClass(className, resolve);
        }
        return clazz;
    }

    private static Map<String, ActiveClassLoader> sJarClassLoaderCaches = new HashMap<>();
    public static ActiveClassLoader createNewActiveLoader(Context context, String jarFilePath) {
        synchronized (sJarClassLoaderCaches) {
            if (sJarClassLoaderCaches.containsKey(jarFilePath)) {
                return sJarClassLoaderCaches.get(jarFilePath);
            }

            try {
                File dexOutPutFile = context.getDir("dex", 0);
                ActiveClassLoader dexClassLoader = new ActiveClassLoader(jarFilePath, dexOutPutFile.getAbsolutePath(),
                        null, context.getClassLoader());

                sJarClassLoaderCaches.put(jarFilePath, dexClassLoader);
                return dexClassLoader;
            } catch (Exception e) {
                return null;
            }
        }
    }

    public static void deleteNewActiveLoader(String jarFilePath) {
        synchronized (sJarClassLoaderCaches) {
            if (sJarClassLoaderCaches.containsKey(jarFilePath)) {
                sJarClassLoaderCaches.remove(jarFilePath);
            }
        }
    }
}
