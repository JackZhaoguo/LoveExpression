package com.meizu.flyme.activeview.version;

import com.meizu.flyme.activeview.json.UpgradeCheckInfo;

/**
 * Created by suyouxiong on 16-12-6.
 */
public class UpgradeCheckResponse {
    private UpgradeCheckInfo reply;

    public UpgradeCheckInfo getReply() {
        return reply;
    }

    public void setReply(UpgradeCheckInfo reply) {
        this.reply = reply;
    }
}
