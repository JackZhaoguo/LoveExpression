package com.meizu.flyme.activeview.utils;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.support.v4.content.LocalBroadcastManager;

import com.meizu.flyme.activeview.json.Event;

import java.util.List;

/**
 * Created by suyouxiong on 2016/10/20.
 *
 * copy from git@gitlab.meizu.com:media.droid/libs.git
 */
public class IntentUtils {
    private static final String TAG = "IntentUtils";

    /**
     * 获取uri对应的可用Activity的intent
     * <p/>注:　这个方法获得的Intent并不可靠．有可能在startActivity时遇到权限问题．请特别注意try-catch．
     * @param context
     * @param uri
     * @return
     */
    public static Intent getAvailableActivityIntent(Context context, String uri) {
        try {
            Intent intent = IntentConverter.parseUri(uri);
            ComponentName component = intent.resolveActivity(context.getPackageManager());
            if (component == null) {
                intent = context.getPackageManager().getLaunchIntentForPackage(uri);
                if (intent != null && Intent.ACTION_MAIN.equals(intent.getAction())) {
                    intent.setAction(null);
                }
            }

            return intent;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 通过intentUri启动Activity页面
     * @param intentUri
     * @return
     */
    public static boolean startActivity(Context context, String intentUri) {
        try {
            Intent intent = IntentUtils.getAvailableActivityIntent(context, intentUri);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 通过intentUri启动服务
     * @param context
     * @param intentUri
     * @return
     */
    public static boolean startService(Context context, String intentUri) {
        try {
            Intent intent = IntentConverter.parseUri(intentUri);
            context.startService(intent);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 通过intentUri发送广播..注意只能检测静态注册的广播
     * @param context
     * @param intentUri
     * @return
     */
    public static boolean sendBroadcast(Context context, String intentUri) {
        try {
            Intent intent = IntentConverter.parseUri(intentUri);
            List<ResolveInfo> list = context.getPackageManager().queryBroadcastReceivers(intent, 0);
            if (list.size() > 0) {
                context.sendBroadcast(intent);
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    /**
     * 通过intentUri发送本地广播
     * @param context
     * @param intentUri
     * @return
     */
    public static boolean sendLocalBroadcast(Context context, String intentUri) {
        try {
            Intent intent = IntentConverter.parseUri(intentUri);
            return LocalBroadcastManager.getInstance(context).sendBroadcast(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 根据type与url处理跳转
     * @param context
     * @param action
     * @param uri
     * @return
     */
    public static boolean handleActionUri(Context context, String action, String uri) {
        boolean actionResult = false;

        switch (action) {
            case Event.ACTION_TYPE_NATIVE:
                actionResult = startActivity(context, uri);
                break;
            case Event.ACTION_TYPE_SERVICE:
                actionResult = startService(context, uri);
                break;
            case Event.ACTION_TYPE_BROADCAST:
                actionResult = sendBroadcast(context, uri);
                break;
            case Event.ACTION_TYPE_LOCAL_BROADCAST:
                actionResult = sendLocalBroadcast(context, uri);
        }
        return actionResult;
    }
}
