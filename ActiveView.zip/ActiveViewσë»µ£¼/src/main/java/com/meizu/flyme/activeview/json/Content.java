package com.meizu.flyme.activeview.json;

import java.util.List;

public class Content {

    private List<Page> pages;

    public Content() {}

    public List<Page> getPages() {
        return pages;
    }

    public void setPages(List<Page> pages) {
        this.pages = pages;
    }
}
