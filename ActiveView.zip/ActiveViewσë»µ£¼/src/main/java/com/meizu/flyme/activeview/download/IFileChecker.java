package com.meizu.flyme.activeview.download;

/**
 * Created by fengsh on 14-12-10.
 */
public interface IFileChecker {

    /**
     * @deprecated 请使用checkHttpContentLength替换该方法
     */
    public boolean isFileLengthMatch(long fileLength);

    /**
     * @deprecated 请使用checkFileDataInfo替换该方法
     */
    public boolean isFileDataMatch(String filePath);

    /**
     * 是否开启文件检验，如果关闭，将不会检查文件信息是否匹配
     *
     * @param enable 是否开启
     */
    public void enableCheck(boolean enable);

    /**
     * 判断文件流长度是否匹配，当contentLength为0时不做比较
     *
     * @param httpRange     http请求的range值
     * @param contentLength http访问的数据流长度
     */
    public FileCheckResult checkHttpContentLength(long httpRange, long contentLength);

    /**
     * 判断文件内容是否匹配服务端信息，可根据场景判断md5/包名等信息
     * 注意：当checkHttpContentLength方法不生效(http流长度为0)时，这里会对文件的长度做一次判断
     *
     * @param filePath 已经下载好的临时文件路径
     */
    public FileCheckResult checkFileDataInfo(String filePath);

    /**
     * @return 用来数据采集的version信息，可为null
     */
    public String getLogVersion();

    String getCheckMd5();

    String getCheckPartialMd5();

    long getCheckFileSize();
}
