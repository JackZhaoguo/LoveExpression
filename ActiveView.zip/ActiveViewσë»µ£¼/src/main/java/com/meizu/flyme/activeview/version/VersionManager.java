package com.meizu.flyme.activeview.version;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.util.Pair;

import com.meizu.flyme.activeview.download.UpgradeDownloader;
import com.meizu.flyme.activeview.json.ActiveData;
import com.meizu.flyme.activeview.json.UpgradeActiveBean;
import com.meizu.flyme.activeview.json.UpgradeCheckInfo;
import com.meizu.flyme.activeview.utils.ActiveClassLoader;
import com.meizu.flyme.activeview.utils.ActiveUsageStatsUtils;
import com.meizu.flyme.activeview.utils.Constants;
import com.meizu.flyme.activeview.utils.FileCacheHelper;
import com.meizu.flyme.activeview.utils.FileUtil;
import com.meizu.flyme.activeview.utils.HttpLoadException;
import com.meizu.flyme.activeview.utils.JsonParser;
import com.meizu.flyme.activeview.utils.LogUtil;
import com.meizu.flyme.activeview.utils.ReflectHelper;
import com.meizu.flyme.activeview.utils.UrlRequest;
import com.meizu.flyme.activeview.utils.Utility;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by suyouxiong on 2016/11/11.
 */
public class VersionManager implements CheckListener {
    public static final int CUR_VERSION_LOWER_MIN = 1;
    public static final int CUR_VERSION_LOWER = 2;
    public static final int CUR_VERSION_AVAILABLE = 3;
    public static final String TAG = "VersionManager";
    private static VersionManager sVersionManager;
    private final Handler mUiHandler;
    private Context mContext;
    private ArrayList<OnVersionChangedListener> mOnVersionChangedListeners;
    private String mDataVersion;
    private UnblockUiChecker mUpgradeChecker;
    private boolean mIsChecking;

    public interface OnVersionChangedListener {

        void onVersionChanged(String curVersion, String jarFilePath);
    }

    private VersionManager(Context context) {
        mContext = context.getApplicationContext();
        mUiHandler = new Handler(Looper.getMainLooper());
    }

    public static VersionManager getVersionManager(Context context) {
        if (sVersionManager == null) {
            sVersionManager = new VersionManager(context);
        }
        return sVersionManager;
    }

    public int checkVersion(ActiveData activeData) {
        final String dataVersion = activeData.getVersion();
        final String dataMinVersion = activeData.getMiniCompatibleVersion();
        if (dataMinVersion == null || dataMinVersion == null) return CUR_VERSION_AVAILABLE;
        final String curVersion = Version.VERSION;
        LogUtil.i(TAG, "checkVersion act data version = " + dataVersion + ", act data min version = " + dataMinVersion + ",  current version = " + curVersion);

        if (curVersion.compareTo(dataMinVersion) < 0) {
            return CUR_VERSION_LOWER_MIN;
        } else if (curVersion.compareTo(dataVersion) < 0){
            return CUR_VERSION_LOWER;
        }
        return CUR_VERSION_AVAILABLE;
    }

    public void checkUpgradeVersion(ActiveData activeData) {
        mDataVersion = activeData.getVersion();
        if (mUpgradeChecker == null) {
            mUpgradeChecker = new UnblockUiChecker(mContext, this);
        }
        if (!mIsChecking) {
            mUpgradeChecker.startCheck();
            mIsChecking = true;
        }
    }

    @Override
    public void onCheckEnd(int code, UpgradeActiveBean info) {
        if (info != null) {
            final String mCacheDir = FileUtil.getActiveViewCachesDir(mContext);
            UpgradeDownloader upgradeDownloader = new UpgradeDownloader(mContext, info, mCacheDir);
            upgradeDownloader.startDownload(new UpgradeDownloader.Callback() {
                @Override
                public void onSuccess(final String filePath) {

                    CheckJarVersionTask checkJarVersionTask = new CheckJarVersionTask(mContext);
                    checkJarVersionTask.setOnCheckJarVersionListener(new OnCheckJarVersionListener() {
                        @Override
                        public void onChecked(String result) {
                            LogUtil.i(TAG, "onChecked jar version = " + result + ", current version = " + Version.VERSION);
                            if (result == null || result.compareTo(mDataVersion) < 0) {//下载的新jar包版本比act的版本还低，放弃此jar包
                                LogUtil.e(TAG, "the version of the upgrade jar is error , the version is " + result + ", but the current version is " + Version.VERSION + " already");
                                FileUtil.deleteFile(filePath);
                                notifyOnVersionChangedListener(Version.VERSION, filePath);
                            } else {
                                FileCacheHelper.renameFile(filePath, FileUtil.getDefaultNewActiveJarPath(mContext));//重命名为默认jar包路径，提供下次应用启动加载
                                notifyOnVersionChangedListener(result, FileUtil.getDefaultNewActiveJarPath(mContext));
                            }

                            Map<String, String> map = new HashMap<>();
                            map.put(ActiveUsageStatsUtils.APP_PACKAGE_NAME, Utility.getAppPackageName(mContext));
                            map.put(ActiveUsageStatsUtils.APP_PACKAGE_VERSION_NAME, Utility.getAppVersionName(mContext));
                            map.put(ActiveUsageStatsUtils.UPGRADE_PROPERTY_LOCAL_VERSION, Version.VERSION);
                            map.put(ActiveUsageStatsUtils.UPGRADE_PROPERTY_ACT_VERSION, mDataVersion);
                            map.put(ActiveUsageStatsUtils.UPGRADE_PROPERTY_JAR_VERSION, result);
                            ActiveUsageStatsUtils.recordEvent(mContext, ActiveUsageStatsUtils.EVENT_UPGRADE, "", map);

                        }
                    });
                    checkJarVersionTask.execute(filePath);

                }

                @Override
                public void onFail(int code, final String filePath) {
                    LogUtil.i(TAG, "download jar file fail: code  = " + code);
                    FileUtil.deleteFile(filePath);
                    mUiHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            notifyOnVersionChangedListener(Version.VERSION, filePath);
                        }
                    });
                }
            });
        } else {
            LogUtil.i(TAG, "upgrade check info is null");
            mUiHandler.post(new Runnable() {
                @Override
                public void run() {
                    notifyOnVersionChangedListener(Version.VERSION, null);
                }
            });
        }
    }

    private void notifyOnVersionChangedListener(String curVersion, String jarFilePath) {
        if (mOnVersionChangedListeners != null) {
            ArrayList<OnVersionChangedListener> listenersCopy =
                    (ArrayList<OnVersionChangedListener>) mOnVersionChangedListeners.clone();
            int numListeners = listenersCopy.size();
            for (int i = 0; i < numListeners; ++i) {
                listenersCopy.get(i).onVersionChanged(curVersion, jarFilePath);
            }
        }
        mIsChecking = false;
    }

    public void addOnVersionChangedListener(OnVersionChangedListener onVersionChangedListener) {
        if (mOnVersionChangedListeners == null) {
            mOnVersionChangedListeners = new ArrayList<>();
        }
        mOnVersionChangedListeners.add(onVersionChangedListener);
    }

    public void removeOnVersionChangedListener(OnVersionChangedListener onVersionChangedListener) {
        if (mOnVersionChangedListeners != null) {
            mOnVersionChangedListeners.remove(onVersionChangedListener);
        }
    }

    private static class CheckJarVersionTask extends AsyncTask<String, Integer, String> {
        private OnCheckJarVersionListener mOnCheckJarVersionListener;

        private WeakReference<Context> mContextWeakReference;
        public CheckJarVersionTask(Context context) {
            mContextWeakReference = new WeakReference<Context>(context);
        }

        @Override
        protected String doInBackground(String... params) {
            if (params.length > 0 && mContextWeakReference.get() != null) {
                String filePath = params[0];
                Context context = mContextWeakReference.get();
                ActiveClassLoader newJarClassLoader = ActiveClassLoader.createNewActiveLoader(context, filePath);
                String jarVersion = getJarVersion(newJarClassLoader);
                ActiveClassLoader.deleteNewActiveLoader(filePath);
                return jarVersion;
            }
            return null;
        }

        @Override
        protected void onPostExecute(String version) {
            if (mOnCheckJarVersionListener != null) {
                mOnCheckJarVersionListener.onChecked(version);
            }
        }

        public void setOnCheckJarVersionListener(OnCheckJarVersionListener onCheckJarVersionListener) {
            mOnCheckJarVersionListener = onCheckJarVersionListener;
        }
    }

    private interface OnCheckJarVersionListener {

        void onChecked(String version);
    }

    public static String getJarVersion(ActiveClassLoader classLoader) {
        try {
            Class versionClazz = classLoader.loadClass(Constants.ACTIVE_VIEW_VERSION_CLASS);
            String version = (String) ReflectHelper.getField(versionClazz, versionClazz, Constants.ACTIVE_VIEW_VERSION_FILD);
            return version;
        } catch (Exception e) {
            LogUtil.e(TAG, "get the version in jar file error : " + e.getMessage());
        }
        return null;
    }

    static UpgradeActiveBean checkUpdate(Context context) {
        try {

            String deviceId = Utility.getDeviceId(context);
            String model = Utility.getDeviceModel(context);
            String sn = Utility.getSN(context);
            String androidVersion = Utility.getAndroidVersion(context);
            String sysVer = Utility.getSystemVersion(context);
            int unitType = Utility.getUnitType(context);

            JSONObject serviceObj = new JSONObject();
            serviceObj.put(Constants.JSON_KEY_VERSION, Version.VERSION);
            serviceObj.put(Constants.JSON_KEY_SERVICE_NAME, Constants.ACTIVE_PACKAGE_NAME);
            serviceObj.put(Constants.JSON_KEY_TARGET_APP_NAME, context.getPackageName());
            JSONArray serviceArray = new JSONArray();
            serviceArray.put(serviceObj);

            JSONObject appJsonObject = new JSONObject();
            appJsonObject.put(Constants.JSON_KEY_DEVICE_TYPE, model);
            appJsonObject.put(Constants.JSON_KEY_FW, androidVersion);
            appJsonObject.put(Constants.JSON_KEY_SYSTEM_V, sysVer);
            appJsonObject.put(Constants.JSON_KEY_DEVICE_ID, deviceId);
            appJsonObject.put(Constants.JSON_KEY_SN, sn);
            appJsonObject.put(Constants.JSON_KEY_SERVICE, serviceArray);

            StringBuffer signString = new StringBuffer();
            signString.append(appJsonObject.toString()).append(Constants.MD5_SIGN_KEY_STRING);
            String sign = Utility.md5sum(signString.toString());

            JSONObject postJson = new JSONObject();
            postJson.put(Constants.PARAM_UNIT_TYPE, unitType);

            try {
                String res = invokeCheckUpdate(appJsonObject.toString(), sign, unitType);
                UpgradeCheckResponse upgradeCheckResponse = JsonParser.parseJson(res, UpgradeCheckResponse.class);

                UpgradeCheckInfo updateCheckInfo = upgradeCheckResponse.getReply();
                List<UpgradeActiveBean> updateInfoList = updateCheckInfo.getValue();

                UpgradeActiveBean updateInfo = checkUpgradeInfo(updateInfoList);
                return updateInfo;

            } catch (HttpLoadException e) {
                LogUtil.i(TAG, "get upgrade check info is fail : message=" + e.getMessage());
            }

        } catch (Exception e) {
            LogUtil.e(TAG, "check the upgrade info error : " + e.getMessage());
            return null;
        }
        return null;
    }

    private static UpgradeActiveBean checkUpgradeInfo(List<UpgradeActiveBean> updateInfoList) {
        if (updateInfoList == null || updateInfoList.size() == 0) {
            return null;
        }
        UpgradeActiveBean updateInfo = updateInfoList.get(0);
        for (UpgradeActiveBean info : updateInfoList) {
            if (info.isExistsUpdate()) {
                if (updateInfo.getLatestVersion().compareTo(info.getLatestVersion()) < 0) {
                    updateInfo = info;
                }
            }
        }

        return updateInfo;
    }

    private static String invokeCheckUpdate(String json, String sign, int unitType) throws HttpLoadException {
        List<Pair<String, String>> params = new ArrayList<Pair<String, String>>();
        params.add(new Pair<String, String>(Constants.PARAM_APPS, json));
        params.add(new Pair<String, String>(Constants.PARAM_SIGN, sign));
        params.add(new Pair<String, String>(Constants.PARAM_UNIT_TYPE, String.valueOf(unitType)));
        //捕获requestBase方法产生的异常 bug_fix #393995
        try {
            LogUtil.i(TAG, "----post the check upgrade request : apps = " + json + ", sign = " + sign);
            return UrlRequest.requestBase(Constants.CHECK_ACTIVE_VIEW_UPDATE_URL, params);
        } catch (HttpLoadException e) {
            throw e;
        }
    }
}
