package com.meizu.flyme.activeview.listener;

/**
 * Created by meizu on 16/9/21.
 */
public interface OnZipExtractListener {
    int EXTRACT_FAIL = 0x0;
    int EXTRACT_SUCESS = 0x1;

    void onExtractStart(String file);
    void onExtractError(String errStr);
    void onExtractFinished(int result, String extractedDir);
}
