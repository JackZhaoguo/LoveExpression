package com.meizu.flyme.activeview.views;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ViewGroup;

import com.meizu.flyme.activeview.listener.OnActiveViewUpgradeListener;
import com.meizu.flyme.activeview.listener.OnEventListener;
import com.meizu.flyme.activeview.listener.OnLoadImageListener;
import com.meizu.flyme.activeview.listener.OnParallaxListener;
import com.meizu.flyme.activeview.listener.OnUpdateListener;
import com.meizu.flyme.activeview.listener.OnVersionListener;
import com.meizu.flyme.activeview.utils.ActiveClassLoader;
import com.meizu.flyme.activeview.utils.Constants;
import com.meizu.flyme.activeview.utils.FileUtil;
import com.meizu.flyme.activeview.utils.ImageCache;
import com.meizu.flyme.activeview.utils.LogUtil;
import com.meizu.flyme.activeview.utils.ActiveUsageStatsUtils;
import com.meizu.flyme.activeview.utils.Utility;
import com.meizu.flyme.activeview.version.Version;
import com.meizu.flyme.activeview.version.VersionManager;

import java.io.File;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by meizu on 16/11/5.
 */
public class ActiveView extends IActiveView implements OnActiveViewUpgradeListener {
    IActiveView mActiveViewImpl = null;

    private String mNewVersionJarFilePath;
    private Object[] mConstructorParams;
    //reflect cache
    private static Class<?> sNativeActiveViewImplClazz;

    private Context mContext;

    public ActiveView(final Context context) {
        super(context);
        mActiveViewImpl = getActiveViewInstance(context, context, Context.class);
        mContext = context.getApplicationContext();
        init();
    }

    public ActiveView(Context context, boolean useAssetsResources) {
        super(context, useAssetsResources);
        mActiveViewImpl = getActiveViewInstance(context, context, useAssetsResources, Context.class, boolean.class);
        mContext = context.getApplicationContext();
        init();
    }

    public ActiveView(Context context, int defaultWidth, int defaultHeight, int defaultResId) {
        super(context, defaultWidth, defaultHeight, defaultResId);
        mActiveViewImpl = getActiveViewInstance(context, context, defaultHeight, defaultHeight, defaultResId, Context.class, int.class, int.class, int.class);
        mContext = context.getApplicationContext();
        init();
    }

    public ActiveView(Context context, AttributeSet attrs) {
        super(context, attrs);  //对壳设置xml中的属性，真实的ActiveView相对于壳设置match_parent.
        mActiveViewImpl = getActiveViewInstance(context, context, Context.class);
        mContext = context.getApplicationContext();
        init();
    }

    private void init() {
        if (mActiveViewImpl == null) return;
        addView(mActiveViewImpl, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        mActiveViewImpl.setOnActiveViewUpgradeListener(this);

        Map<String, String> map = new HashMap<>();
        map.put(ActiveUsageStatsUtils.APP_PACKAGE_NAME, Utility.getAppPackageName(mContext));
        map.put(ActiveUsageStatsUtils.APP_PACKAGE_VERSION_NAME, Utility.getAppVersionName(mContext));
        ActiveUsageStatsUtils.recordEvent(mContext, ActiveUsageStatsUtils.EVENT_APP_PACKAGE_INFO, "", map);
    }

    private IActiveView getActiveViewInstance(Context context, Object... params) {
        if (mNewVersionJarFilePath == null) {
            mNewVersionJarFilePath = FileUtil.getDefaultNewActiveJarPath(context);
        }
        mConstructorParams = params;
        IActiveView activeViewInstance = null;
        File jarFile = new File(mNewVersionJarFilePath);
        Class activeViewImplClazz = null;
        String curUsedVersion = null;
        if (jarFile.exists()) {
            LogUtil.i("jar文件存在");

            try {
                String curVersion = Version.VERSION;
                ActiveClassLoader dexClassLoader = ActiveClassLoader.createNewActiveLoader(context, jarFile.getAbsolutePath());
                String jarVersion = VersionManager.getJarVersion(dexClassLoader);
                LogUtil.i(VersionManager.TAG, "getActiveViewInstance jar version = " + jarVersion + ", current version = " + curVersion);
                if (jarFile == null || jarVersion.compareTo(curVersion) <= 0) {
                    FileUtil.deleteFile(mNewVersionJarFilePath);
                    ActiveClassLoader.deleteNewActiveLoader(jarFile.getAbsolutePath());
                } else {
                    activeViewImplClazz = dexClassLoader.loadClass(Constants.ACTIVE_VIEW_IMPLEMENT_CLASS);
                }

                curUsedVersion = jarVersion;

            } catch (Throwable e) {
                LogUtil.e("load ActiveViewImpl class error:" + e.getMessage());
            }
        }

        if (activeViewImplClazz == null) {
            LogUtil.e("jar文件不存在");
            try {
                if (sNativeActiveViewImplClazz == null) {
                    sNativeActiveViewImplClazz = Class.forName(Constants.ACTIVE_VIEW_IMPLEMENT_CLASS);
                }
                activeViewImplClazz = sNativeActiveViewImplClazz;

                curUsedVersion = Version.VERSION;

            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
        if (activeViewImplClazz != null) {

            // record current used version
            Map<String, String> map = new HashMap<>();
            map.put(ActiveUsageStatsUtils.VERSION_NUMBER, curUsedVersion);
            ActiveUsageStatsUtils.recordEvent(mContext, ActiveUsageStatsUtils.EVENT_VERSION_FREQUENCY, "", map);

            try {

                final int objLength = params.length / 2;
                Object[] objects = new Object[objLength];
                Class[] parameterTypes = new Class[objLength];
                for (int i = 0; i < objLength; i++) {
                    objects[i] = params[i];
                }
                for (int i = objLength; i < params.length; i++) {
                    parameterTypes[i - objLength] = (Class) params[i];
                }
                Constructor constructor = activeViewImplClazz.getConstructor(parameterTypes);

                activeViewInstance = (IActiveView) constructor.newInstance(objects);
            } catch (Exception e) {
                LogUtil.e("new ActiveViewImpl instance error:" + e.getMessage());
            }
        }

        return activeViewInstance;
    }


    public void setOnUpdateListener(OnUpdateListener listener) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setOnUpdateListener(listener);
        }
    }

    @Override
    public String getPassword() {
        if (mActiveViewImpl != null) {
            return mActiveViewImpl.getPassword();
        }
        return null;
    }

    @Override
    public void setPassword(String pwd) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setPassword(pwd);
        }
    }

    @Override
    public void setUseAssetsResources(boolean useAssetsResources) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setUseAssetsResources(useAssetsResources);
        }
    }

    @Override
    public void setDefaultImage(int defaultWidth, int defaultHeight, int defaultResId) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setDefaultImage(defaultWidth, defaultHeight, defaultResId);
        }
    }

    @Override
    public void setDefaultImage(int defaultResId) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setDefaultImage(defaultResId);
        }
    }

    @Override
    public void setDefaultImage(int defaultWidth, int defaultHeight, Bitmap bitmap) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setDefaultImage(defaultWidth, defaultHeight, bitmap);
        }
    }

    @Override
    public void setDefaultImage(Drawable drawable) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setDefaultImage(drawable);
        }
    }

    @Override
    public void setDefaultImage(int defaultWidth, int defaultHeight, Drawable drawable) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setDefaultImage(defaultWidth, defaultHeight, drawable);
        }
    }

    @Override
    public int getColorPrimary() {
        if (mActiveViewImpl != null) {
            return mActiveViewImpl.getColorPrimary();
        }
        return 0;
    }


    @Override
    public void updateResource(String url) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.updateResource(url);
        }
    }


    @Override
    public void setParallaxListener(OnParallaxListener listener) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setParallaxListener(listener);
        }
    }

    @Override
    public void setParallaxListener(Boolean useParallax) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setParallaxListener(useParallax);
        }
    }

    @Override
    public void downloadImage(String url) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.downloadImage(url);
        }
    }

    @Override
    public void downloadImage(String url, OnLoadImageListener listener) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.downloadImage(url, listener);
        }
    }

    @Override
    public void setOnLoadImageListener(OnLoadImageListener listener) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setOnLoadImageListener(listener);
        }
    }

    @Override
    public void downloadVideo(String url, int width, int height) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.downloadVideo(url, width, height);
        }
    }

    @Override
    public void downloadPackage(String url) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.downloadPackage(url);
        }
    }

    @Override
    public void downloadPackage(String url, OnLoadImageListener listener) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.downloadPackage(url, listener);
        }
    }

    @Override
    public String getUrl() {
        if (mActiveViewImpl != null) {
            return mActiveViewImpl.getUrl();
        }
        return null;
    }

    @Override
    public void loadResourceFile(String actFile) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.loadResourceFile(actFile);
        }
    }

    @Override
    public void cancelLoadImage() {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.cancelLoadImage();
        }
    }

    @Override
    public void loadData(String zipExtractedPath) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.loadData(zipExtractedPath);
        }
    }

    @Override
    public String getVersion() {
        if (mActiveViewImpl != null) {
            return mActiveViewImpl.getVersion();
        }
        return null;
    }

    @Override
    public void loadFromWeb(String webUrl, int width, int height) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.loadFromWeb(webUrl, width, height);
        }
    }

    @Override
    public void setAutoRunAnimation(boolean autoRunAnimation) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setAutoRunAnimation(autoRunAnimation);
        }
    }

    @Override
    public void setAutoGradientDisplay(boolean autoGradientDisplay) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setAutoGradientDisplay(autoGradientDisplay);
        }
    }

    @Override
    public Bitmap getActiveViewBitmap() {
        if (mActiveViewImpl != null) {
            return mActiveViewImpl.getActiveViewBitmap();
        }
        return null;
    }

    @Override
    public void gotoAnimEnd() {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.gotoAnimEnd();
        }
    }

    @Override
    public void gotoAnimStart() {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.gotoAnimStart();
        }
    }

    @Override
    public void setImageCache(ImageCache imageCache) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setImageCache(imageCache);
        }
    }

    @Override
    public void clearImageCache() {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.clearImageCache();
        }
    }

    @Override
    public void setOnEventListener(OnEventListener listener) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setOnEventListener(listener);
        }
    }

    @Override
    public void setOnVersionListener(OnVersionListener listener) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setOnVersionListener(listener);
        }
    }

    @Override
    public void startAnimation() {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.startAnimation();
        }
    }

    @Override
    public void stopAnimation() {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.stopAnimation();
        }
    }

    @Override
    public void pauseAnimation() {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.pauseAnimation();
        }
    }

    @Override
    public void resumeAnimation() {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.resumeAnimation();
        }
    }

    @Override
    public void cancelAllRunningTasks() {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.cancelAllRunningTasks();
        }
    }

    @Override
    public void cancelDownload() {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.cancelDownload();
        }
    }

    @Override
    public void cancelExtract() {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.cancelExtract();
        }
    }

    @Override
    public void pauseVideo() {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.pauseVideo();
        }
    }

    @Override
    public void startVideo() {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.startVideo();
        }
    }

    @Override
    public void stopVideo() {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.stopVideo();
        }
    }

    @Override
    public void setTextContent(String id, String content) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setTextContent(id, content);
        }
    }

    @Override
    protected void setOnActiveViewUpgradeListener(OnActiveViewUpgradeListener onActiveViewUpgradeListener) {
        //is invalid for app
    }

    @Override
    public void setFrameDelay(long time) {
        if (mActiveViewImpl != null) {
            mActiveViewImpl.setFrameDelay(time);
        }
    }

    @Override
    public void onUpgradeFinished(int type, int state, String result) {
        if (state == UPGRADE_STATE_SUCCESS && type == UPGRADE_JAR_FILE_DOWNLOAD) {
            mNewVersionJarFilePath = result;
            String actFileUrl = getUrl();
            if (mActiveViewImpl != null && mActiveViewImpl.getParent() == this) {
                removeView(mActiveViewImpl);
            }
            ActiveClassLoader.deleteNewActiveLoader(FileUtil.getDefaultNewActiveJarPath(getContext()));//清除上一个jar包的classloader缓存
            mActiveViewImpl = getActiveViewInstance(getContext(), mConstructorParams);
            //mActiveViewImpl.setOnActiveViewUpgradeListener(this);
            mActiveViewImpl.updateResource(actFileUrl);
            addView(mActiveViewImpl, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
    }
}
