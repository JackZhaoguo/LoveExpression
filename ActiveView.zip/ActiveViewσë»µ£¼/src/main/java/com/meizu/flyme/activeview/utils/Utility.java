package com.meizu.flyme.activeview.utils;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.MessageDigest;
import java.util.Scanner;

public class Utility {
    public static String getSubmitAppVersionString(Context context) {
        return getSubmitAppVersionString(context, context.getPackageName());
    }

    public static String getSubmitAppVersionString(Context context, String packageName) {
        String versionName = getAppVersionString(context, packageName);
        //取消添加国际版后缀，只判断versionName
        return versionName;
    }

    public static String getAppVersionString(Context context, String packageName) {
        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo info = pm.getPackageInfo(packageName, 0);
            return info.versionName;
        } catch (NameNotFoundException e) {
            return "";
        }
    }

    public static int getAppVersionCode(Context context, String packageName) {
        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo info = pm.getPackageInfo(packageName, 0);
            return info.versionCode;
        } catch (NameNotFoundException e) {
            return -1;
        }
    }

    public static String getAppVersionName(Context context) {
        if (context == null) {
            return "";
        }

        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo info = pm.getPackageInfo(context.getPackageName(), 0);
            return info.versionName;
        } catch (NameNotFoundException e) {
            return "";
        }
    }

    public static String getAppPackageName(Context context) {
        if (context != null) {
            return context.getPackageName();
        }
        return "";
    }

    public static final String getSystemVersion(Context context) {
/*      if(isSystemIndependent(context)){
          return Constants.REQUEST_SYSTEM_VERSION;
      }else{*/
        String version = null;
        try {
            version = getSystemProperties("ro.build.mask.id", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (TextUtils.isEmpty(version)) {
            version = Build.DISPLAY;
        }
        return version;
//      }
    }

    public static final String getAndroidVersion(Context context) {
/*      if(isSystemIndependent(context)){
          return Constants.REQUEST_SYSTEM_VERSION;
      }else{*/
        return Build.VERSION.RELEASE;
//      }
    }

    public static final String getDeviceModel(Context context) {
        if (isSystemIndependent(context)) {
            return Constants.REQUEST_MODEL_NAME;
        } else {
            return getDeviceModel();
        }
    }

    private static String sModel;

    /**
     * 获取设备Model
     *
     * @return
     */
    public static String getDeviceModel() {
        if (sModel == null) {
            if (!isFlymeRom()) {
                try {
                    sModel = (String) ReflectHelper.getStaticField("android.os.BuildExt", "MZ_MODEL");
                } catch (Exception e) {
                }
            }
        }
        if (TextUtils.isEmpty(sModel)) {
            sModel = Build.MODEL;
        }
        return sModel;
    }

    private static Boolean sIsFlymeRom = null;

    /**
     * Returns if Flyme is running on a third party device.
     *
     * @return true if the rom is Flyme for a third party device, false if the rom is Flyme proudly running on Meizu Phone.
     */
    public static boolean isFlymeRom() {
        if (sIsFlymeRom != null) {
            return sIsFlymeRom.booleanValue();
        }
        sIsFlymeRom = false;
        try {
            sIsFlymeRom = (Boolean) ReflectHelper.invokeStatic("android.os.BuildExt", "isFlymeRom", null);
        } catch (Exception e) {
        }
        return sIsFlymeRom;
    }

    public static final String getIMEI(Context context) {
        return getDefaultImei(context);
    }

    private static String sPhoneSn;

    public static final String getSN(Context context) {
        if (sPhoneSn == null) {
            sPhoneSn = getSystemProperties("ro.serialno", null);
        }
        return sPhoneSn;
    }

    private static String sImei;

    public static String getDefaultImei(Context context) {
        if (TextUtils.isEmpty(sImei)) {

            // android L
            try {
                final String MZ_T_M = "android.telephony.MzTelephonyManager";
                final String METHOD_GET_DEVICE_ID = "getDeviceId";
                sImei = (String) ReflectHelper.invokeStatic(MZ_T_M, METHOD_GET_DEVICE_ID, null, null);
            } catch (Exception ignore) {
                ignore.printStackTrace();
            }

            if (TextUtils.isEmpty(sImei)) {
                // Flyme 4.0
                try {
                    final String MZ_T_M = "com.meizu.telephony.MzTelephonymanager";
                    final String METHOD_GET_DEVICE_ID = "getDeviceId";
                    sImei = (String) ReflectHelper.invokeStatic(MZ_T_M, METHOD_GET_DEVICE_ID, new Class<?>[]{Context.class, int.class}, new Object[]{context, 0});
                } catch (Exception ignore) {
                }
            }

            // 这个处理是非必须的，因为METHOD_GET_DEVICE_ID本身做了这个处理；为了运行在其它手机平台，这里兼容处理
            if (TextUtils.isEmpty(sImei)) {
                TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
                sImei = tm.getDeviceId();
            }
        }
        return sImei;
    }

    public static final boolean isPackageValue(Context context, String path) {
        try {
            File file = new File(path);
            if (file.isFile() && file.exists()) {
                PackageManager pm = context.getPackageManager();
                PackageInfo info = pm.getPackageArchiveInfo(path, 0);
                return info != null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static final PackageInfo getFilePackageInfo(Context context, String path) {
        try {
            File file = new File(path);
            if (file.isFile() && file.exists()) {
                PackageManager pm = context.getPackageManager();
                return pm.getPackageArchiveInfo(path, 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static final String getFilePackageName(Context context, String path) {
        PackageInfo info = getFilePackageInfo(context, path);
        if (info != null) {
            return info.packageName;
        }
        return null;
    }

    public static final long getFileLength(String path) {
        try {
            File file = new File(path);
            if (file.exists() && file.isFile()) {
                return file.length();
            }
        } catch (Exception e) {
        }
        return 0;
    }

    public static final String getApplicationName(Context context) {
        PackageManager pm = context.getPackageManager();
        return context.getApplicationInfo().loadLabel(pm).toString();
    }

    private final static char[] hexDigits = {'0', '1', '2', '3', '4', '5',
            '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

    public static String encodeHex(final byte[] data) {
        final int l = data.length;
        final char[] out = new char[l << 1];
        // two characters form the hex value.
        for (int i = 0, j = 0; i < l; i++) {
            out[j++] = hexDigits[(0xF0 & data[i]) >>> 4];
            out[j++] = hexDigits[0x0F & data[i]];
        }
        return new String(out);
    }

    public static String md5sum(String original) {
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(original.getBytes("utf-8"));
            String str = encodeHex(md5.digest());
            return str;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static Boolean sIsInternational = null;

    /**
     * 是否为国际版
     *
     * @return
     */
    public static boolean isInternational() {
        if (sIsInternational != null) {
            return sIsInternational.booleanValue();
        }
        sIsInternational = false;
        try {
            Method method = Class.forName("android.os.BuildExt").getMethod("isProductInternational");
            sIsInternational = (Boolean) method.invoke(null);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return sIsInternational;
    }

    private static String getSystemProperties(String key, String defaultValue) {
        try {
            return (String) ReflectHelper.invokeStatic("android.os.SystemProperties", "get", new Object[]{key});
        } catch (Exception e) {
            e.printStackTrace();
        }
        return defaultValue;
    }

    public static boolean isSystemApp(Context context, String packageName) {
        PackageManager pm = context.getPackageManager();
        try {
            ApplicationInfo ai = pm.getApplicationInfo(packageName, 0);
            if (ai != null) {
                return (((ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0) || ((ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0));
            }
        } catch (NameNotFoundException e) {
        }
        return false;
    }

    public static final Bitmap getAppIcon(String packageName, Context context) {
        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo info = pm.getPackageInfo(packageName, 0);
            Drawable iconDrawable = info.applicationInfo.loadIcon(pm);
            if (iconDrawable != null) {
                return drawableToBitmap(iconDrawable);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static final int getAppIconRes(String packageName, Context context) {
        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo info = pm.getPackageInfo(packageName, 0);
            return info.applicationInfo.icon;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    private static Bitmap drawableToBitmap(Drawable drawable) {
        int w = drawable.getIntrinsicWidth();
        int h = drawable.getIntrinsicHeight();

        Bitmap.Config config = drawable.getOpacity() != PixelFormat.OPAQUE ? Bitmap.Config.ARGB_8888
                : Bitmap.Config.RGB_565;
        Bitmap bitmap = Bitmap.createBitmap(w, h, config);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, w, h);
        drawable.draw(canvas);
        return bitmap;
    }

    public static boolean isNetworkAvailable(Context context) {
        //bug_fix#284069,Android M上的ConnectivityManager持有Context的引用
        ConnectivityManager connectivity = (ConnectivityManager) context.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity == null) {
            return false;
        } else {
            NetworkInfo info = connectivity.getActiveNetworkInfo();
            if (info != null && info.isConnected()) {
                return true;
            }
        }
        return false;
    }

    public static boolean isWifiActive(Context context) {
        //bug_fix#284069,Android M上的ConnectivityManager持有Context的引用
        ConnectivityManager cm = (ConnectivityManager) context.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkInfo info = cm.getActiveNetworkInfo();
            if (info != null && info.isAvailable()) {
                if (info.getType() == ConnectivityManager.TYPE_WIFI) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        return false;
    }


    public static String FormatFileSizeEx(double fFileSize) {
        String csRet;
        int nSize = 0;
        if (fFileSize < 1024.0) {
            nSize = 0;
            if (fFileSize > 0) {
                nSize = (int) fFileSize;
            }
            csRet = String.format("%dB", nSize);
        } else if (fFileSize >= 1024.0 && fFileSize < 1024.0 * 10) {
            csRet = String.format("%dKB", (int) (fFileSize / 1024.0));
        } else if (fFileSize >= 1024 * 10 && fFileSize < 1024.0 * 100) {
            csRet = String.format("%dKB", (int) (fFileSize / 1024.0));
        } else if (fFileSize >= 1024 * 100 && fFileSize < 1024.0 * 1024.0) {
            nSize = (int) (fFileSize / 1024.0);
            csRet = String.format("%dKB", nSize);
        } else if (fFileSize >= 1024.0 * 1024.0
                && fFileSize < 1024.0 * 1024 * 100) {
            csRet = String.format("%.2fMB", fFileSize / (1024.0 * 1024.0));
        } else if (fFileSize >= 1024.0 * 1024 * 100
                && fFileSize < 1024.0 * 1024 * 1024) {
            csRet = String.format("%.1fMB", fFileSize / (1024.0 * 1024.0));
        } else if (fFileSize >= (1024.0 * 1024.0 * 1024.0)
                && fFileSize < (1024.0 * 1024.0 * 1024.0) * 10) {
            csRet = String.format("%.2fGB", fFileSize / ((1024.0 * 1024.0 * 1024.0)));
        } else if (fFileSize >= (1024.0 * 1024.0 * 1024.0) * 10
                && fFileSize < (1024.0 * 1024.0 * 1024.0 * 100)) {
            csRet = String.format("%.1fGB", fFileSize / ((1024.0 * 1024.0 * 1024.0)));
        } else {
            nSize = (int) (fFileSize / (1024.0 * 1024.0 * 1024.0));
            csRet = String.format("%dGB", nSize);
        }
        return csRet;
    }

    private static Boolean sSystemIndependent = null;

    private static boolean isSystemIndependent(Context context) {
        if (sSystemIndependent == null) {
            try {
                ApplicationInfo info = context.getPackageManager().getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);
                if (info.metaData != null) {
                    sSystemIndependent = info.metaData.getBoolean("system_independent", false);
                    Log.d("MzUpdateComponent", "sSystemIndependent : " + sSystemIndependent);
                }
            } catch (Exception ignore) {
                ignore.printStackTrace();
            }
            // 没有设置，或者异常了
            if (sSystemIndependent == null) {
                sSystemIndependent = false;
            }
        }
        return sSystemIndependent;
    }

    private static Boolean sIsShopDemo = null;

    /**
     * 判断是否为Demo版
     *
     * @return
     */
    public static boolean isShopDemo() {
        if (sIsShopDemo != null) {
            return sIsShopDemo.booleanValue();
        }
        sIsShopDemo = false;
        try {
            sIsShopDemo = (Boolean) ReflectHelper.getStaticField("android.os.BuildExt", "IS_SHOPDEMO");
        } catch (Exception e) {
        }
        return sIsShopDemo;
    }

    public static String getSimOpCode(Context context) {
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        int simState = tm.getSimState();
        if (simState == TelephonyManager.SIM_STATE_READY) {
            return tm.getSimOperator();
        }
        return "";
    }

    /**
     * 获取电量百分比
     *
     * @param context
     * @return
     */
    public static int getBatteryCapacity(Context context) {
        IntentFilter batteryFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        batteryFilter.addAction(Intent.ACTION_POWER_CONNECTED);
        Intent batteryStatus = context.registerReceiver(null, batteryFilter);
        if (batteryStatus != null) {
            int level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            return level * 100 / scale;
        }
        return 0;
    }

    /**
     * 获取Application的Bundle
     *
     * @param context
     * @return
     */
    public static Bundle getAppMetaDataBundle(Context context) {
        Bundle bundle = null;
        try {
            ApplicationInfo ai = context.getPackageManager().getApplicationInfo(context.getPackageName(),
                    PackageManager.GET_META_DATA);
            bundle = ai.metaData;
        } catch (NameNotFoundException e) {
            LogUtil.e(e.getMessage());
        }
        return bundle;
    }


    /**
     * 判断参数中的版本是否与是否比当前应用版本高
     * @param context
     * @param versionCode
     * @return
     */
    public static boolean isUpdateVersionValid(Context context, int versionCode) {
        //VersionCode不存在的情况下返回有效
        if (versionCode < 0) {
            return true;
        }
        int appVersion = getAppVersionCode(context);
        return appVersion < versionCode;
    }

    /**
     * 获取DeviceId，手机设备为imei，mac设备为mac地址
     * @param context
     * @return
     */
    public static String getDeviceId(Context context) {
        return isMacDevice(context) ? getMacAddress(context) : getIMEI(context);
    }

    private static String sMacAddr;

    /**
     * 获取MAC地址
     * @param context
     * @return
     */
    public static String getMacAddress(Context context) {
        if (!TextUtils.isEmpty(sMacAddr)) {
            return sMacAddr;
        }
        String address = null;
        if (Build.VERSION.SDK_INT >= 23) {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null || cm.getActiveNetworkInfo() == null) {
                address = getMacAddressWithIfName("wlan0");
                if (TextUtils.isEmpty(address)) {
                    address = getMacAddressWithIfName("eth0");
                }
            } else {
                NetworkInfo info = cm.getActiveNetworkInfo();
                if (info.getType() == ConnectivityManager.TYPE_WIFI) {
                    address = getMacAddressWithIfName("wlan0");
                } else if (info.getType() == ConnectivityManager.TYPE_ETHERNET) {
                    address = getMacAddressWithIfName("eth0");
                }
            }
        } else {
            WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
            if (wifiManager != null) {
                WifiInfo wifiInfo = wifiManager.getConnectionInfo();
                address = wifiInfo == null ? null : wifiInfo.getMacAddress();
            }
        }
        sMacAddr = address;
        return sMacAddr;
    }

    private static String getMacAddressWithIfName(String name) {
        String address = null;
        try {
            InputStream in = new FileInputStream("/sys/class/net/" + name + "/address");
            Scanner reader = new Scanner(in);
            if (reader.hasNextLine()) {
                address = reader.nextLine().trim();
            }
            in.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        return address;
    }

    private static Boolean sIsMacDevice = null;

    /**
     * 判断是否为Mac设备
     * @return
     */
    public static boolean isMacDevice(Context context) {
        try {
            if (sIsMacDevice != null) {
                return sIsMacDevice.booleanValue();
            }
            String product = getSystemProperties("ro.target.product", null);
            boolean z = !TextUtils.isEmpty(product) && (Constants.DEVCIE_TABLET.equalsIgnoreCase(product) || Constants.DEVICE_TV.equalsIgnoreCase(product));
            Boolean valueOf = Boolean.valueOf(z);
            sIsMacDevice = valueOf;
            return valueOf.booleanValue();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private static Integer sUnitType = null;
    /**
     * 获取产品类型
     * @param context
     * @return
     */
    public static int getUnitType(Context context) {
        try {
            if (sUnitType != null) {
                return sUnitType.intValue();
            }
            String product = getSystemProperties("ro.target.product", null);
            int unitType = Constants.UNIT_TYPE_PHONE;
            if (!TextUtils.isEmpty(product)) {
                if (Constants.DEVCIE_TABLET.equalsIgnoreCase(product)) {
                    unitType = Constants.UNIT_TYPE_TABLET;
                } else if (Constants.DEVICE_TV.equalsIgnoreCase(product)) {
                    unitType = Constants.UNIT_TYPE_TV;
                }
            }
            Integer valueOf = Integer.valueOf(unitType);
            sUnitType = valueOf;
            return valueOf.intValue();
        } catch (Exception e) {
            e.printStackTrace();
            return Constants.UNIT_TYPE_PHONE;
        }
    }

    /**
     * 获取应用的VersionCode
     * @param context
     * @return
     */
    public static int getAppVersionCode(Context context) {
        try {
            String packageName = context.getPackageName();
            PackageManager pm = context.getPackageManager();
            PackageInfo info = pm.getPackageInfo(packageName, 0);
            return info.versionCode;
        } catch (NameNotFoundException e) {
            return Constants.INVALID_VERSION_CODE;
        }
    }
}
