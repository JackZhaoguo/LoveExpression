package com.meizu.flyme.activeview.json;

/**
 * Created by meizu on 16/11/8.
 * "videoAttr": {
           "loop": true,
           "autoPlay": true,
           "audio": false,
           "startTime": 10000,
           "intervalDelay": 1000,
           "src": "videos/demo.mp4"
 },
 */
public class VideoAttr {

    private Boolean loop;
    private Boolean autoPlay;
    private Boolean audio;

    private Long startTime;
    private Long intervalDelay;

    private String src;

    public VideoAttr() {}

    public void setLoop(Boolean loop) {
        this.loop = loop;
    }

    public Boolean getLoop() {
        return this.loop;
    }

    public void setAutoPlay(Boolean autoPlay) {
        this.autoPlay = autoPlay;
    }

    public Boolean getAutoPlay() {
        return this.autoPlay;
    }

    public void setAudio(Boolean audio) {
        this.audio = audio;
    }

    public Boolean getAudio() {
        return this.audio;
    }

    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }

    public Long getStartTime() {
        return this.startTime;
    }

    public void setIntervalDelay(Long intervalDelay) {
        this.intervalDelay = intervalDelay;
    }

    public Long getIntervalDelay() {
        return this.intervalDelay;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }
}
