package com.meizu.flyme.activeview.task;

import android.content.Context;
import android.os.AsyncTask;
import android.os.SystemClock;

import com.meizu.flyme.activeview.listener.OnLoadDataListener;
import com.meizu.flyme.activeview.utils.JsonParser;
import com.meizu.flyme.activeview.utils.LogUtil;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Load and parse the json file asynchronously.
 */

public class LoadDataTask<T> extends AsyncTask<Object, Integer, T> {
    private static final String LOG_TAG = "activeview.LoadDataTask";
    private String mFile;
    private OnLoadDataListener mListener;
    private boolean mbUseAssetsFile;
    private Context mContext;
    private Class<T> mClass;

    public LoadDataTask(Context context, String file, Class<T> tClass, OnLoadDataListener listener) {
        this(context, file, tClass, listener, false);
    }

    public LoadDataTask(Context context, String file, Class<T> tClass, OnLoadDataListener listener, boolean useAssetsFile) {
        mContext = context;
        mbUseAssetsFile = useAssetsFile;
        mFile = file;
        mListener = listener;
        mClass = tClass;
    }

    @Override
    protected T doInBackground(Object... params) {
        long startTime = SystemClock.currentThreadTimeMillis();
        try {
            InputStream instream = null;
            if (mbUseAssetsFile) {
                if (mContext != null && mContext.getAssets() != null) {
                    instream = mContext.getAssets().open(mFile);
                }
            } else {
                File file = new File(mFile);
                if (file.isDirectory() || !file.exists()) {
                    LogUtil.e(LOG_TAG, "file:" + file.toString() + "is a Directory!");
                    return null;
                }
                instream = new FileInputStream(file);
            }
            String jsonStr = "";
            if (instream != null) {
                try {
                    InputStreamReader inputreader = new InputStreamReader(instream);
                    BufferedReader buffreader = new BufferedReader(inputreader);
                    String line;
                    while ((line = buffreader.readLine()) != null) {
                        jsonStr += line + "\n";
                    }
                } catch (IOException e) {
                    LogUtil.d(LOG_TAG, e.getMessage());
                } finally {
                    instream.close();
                }
            }


            if (jsonStr.isEmpty()) {
                LogUtil.e(LOG_TAG, "Read file data.json is empty!");
                return null;
            }

            long endTime = SystemClock.currentThreadTimeMillis();
            LogUtil.i(LOG_TAG, "Load data.json file:" + mFile + ", UseTime =" + String.valueOf(endTime - startTime));

            return JsonParser.parseJson(jsonStr, mClass);

        } catch (Exception e) {
            LogUtil.e(LOG_TAG, e.toString());
            mListener.onLoadDataResult(OnLoadDataListener.LOAD_FAIL, null);
            return null;
        }
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    protected void onPostExecute(T result) {
        if (isCancelled()) {
            LogUtil.e(LOG_TAG, "onPostExecute() task isCancelled = ");
            mListener = null;
            return;
        }

        if (mListener != null) {
            mListener.onLoadDataResult(result != null ? OnLoadDataListener.LOAD_SUCESS : OnLoadDataListener.LOAD_FAIL, result);
            mListener = null;
        }
    }
}
