package com.meizu.flyme.activeview.json;

import android.content.Context;

import com.meizu.flyme.activeview.utils.DisplayUnitUtil;

import java.util.ArrayList;
import java.util.List;

public class Animation {

    private static final int ANIMATION_2D_ARRAY_LENGTH  = 2;
    private static final int ANIMATION_3D_ARRAY_LENGTH  = 3;

    private String id;
    private String type;
    private String name;
    private int startTime;
    private int duration;
    private Interpolator interpolator;

    private String[] transform2d;
    private Float[] transform2dValue = new Float[ANIMATION_2D_ARRAY_LENGTH];

    private Float[] rotate3d = new Float[ANIMATION_3D_ARRAY_LENGTH];
    private String[] rotateCenter = new String[ANIMATION_2D_ARRAY_LENGTH];
    private float[] rotateCenterValue = new float[ANIMATION_2D_ARRAY_LENGTH];


    private Float[] scale2d = new Float[ANIMATION_2D_ARRAY_LENGTH];
    private Integer opacity;

    private List<float[]> trackPath;
    private List<float[]> mTrackPathValue;
    private String trackPointUnit;

    private boolean repeat;
    private int repeatCount;
    private String repeatMode;

    private Float blur;

    public Animation() {}

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getStartTime() {
        return startTime;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public Interpolator getInterpolator() {
        return interpolator;
    }

    public void setInterpolator(Interpolator interpolator) {
        this.interpolator = interpolator;
    }

    public void setScale2d(Float[] scale2d) {
        this.scale2d = scale2d;
    }

    public Float[] getScale2d() {
        return scale2d;
    }

    public Float[] getRotate3d() {
        return rotate3d;
    }

    public void setRotate3d(Float[] rotate3d) {
        this.rotate3d = rotate3d;
    }

    public void setRotateCenter(String[] rotateCenter) {
        if (rotateCenter.length != ANIMATION_2D_ARRAY_LENGTH) {
            return;
        }
        this.rotateCenter = rotateCenter;
    }

    public float[] getRotateCenterValue(Context context) {
        if (rotateCenter != null && rotateCenter.length == ANIMATION_2D_ARRAY_LENGTH) {
            for (int i = 0; i < ANIMATION_2D_ARRAY_LENGTH; i++) {
                if (rotateCenter[i] != null) {
                    rotateCenterValue[i] = (float) DisplayUnitUtil.getPixelValue(context, rotateCenter[i]);
                }
            }
        }
        return rotateCenterValue;
    }

    public String[] getRotateCenter() {
        return rotateCenter;
    }

    public String[] getTransform2d() {
        return transform2d;
    }

    public void setTransform2d(String[] transform2d) {
        if (transform2d.length != ANIMATION_2D_ARRAY_LENGTH) {
            return;
        }
        this.transform2d = transform2d;
    }

    public Float[] getTransform2dValue(Context context) {
        if (transform2d != null && transform2d.length == ANIMATION_2D_ARRAY_LENGTH) {
            for (int i = 0; i < ANIMATION_2D_ARRAY_LENGTH; i++) {
                if (transform2d[i] != null) {
                    transform2dValue[i] = (float) DisplayUnitUtil.getPixelValue(context, transform2d[i]);
                }
            }
        }
        return transform2dValue;
    }

    public void setOpacity(Integer opacity) {
        this.opacity = opacity;
    }

    public Integer getOpacity() {
        return opacity;
    }

    public List<float[]> getTrackPath() {
        return trackPath;
    }

    public List<float[]> getTrackPathValue(Context context) {
        if (mTrackPathValue == null) {
            if (trackPath != null) {
                mTrackPathValue = new ArrayList<>();
                int size = trackPath.size();
                for (int i = 0; i < size; i++) {
                    float[] tempValue = new float[2];
                    tempValue[0] = trackPath.get(i)[0];
                    tempValue[1] = trackPath.get(i)[1];
                    if (trackPointUnit != null) {
                        tempValue[0] = (float) DisplayUnitUtil.getPixelValue(context, trackPointUnit, tempValue[0]);
                        tempValue[1] = (float) DisplayUnitUtil.getPixelValue(context, trackPointUnit, tempValue[1]);
                    }
                    mTrackPathValue.add(tempValue);
                }
            }
        }
        return mTrackPathValue;
    }

    public void setTrackPath(List<float[]> trackPath) {
        this.trackPath = trackPath;
    }

    public void setTrackPointUnit(String trackPointUnit) {
        this.trackPointUnit = trackPointUnit;
    }

    public String getTrackPointUnit() {
        return trackPointUnit;
    }

    public boolean isRepeat() {
        return repeat;
    }

    public void setRepeat(boolean repeat) {
        this.repeat = repeat;
    }

    public int getRepeatCount() {
        return repeatCount;
    }

    public void setRepeatCount(int repeatCount) {
        this.repeatCount = repeatCount;
    }

    public String getRepeatMode() {
        return repeatMode;
    }

    public void setRepeatMode(String repeatMode) {
        this.repeatMode = repeatMode;
    }

    public Float getBlur() {
        return blur;
    }

    public void setBlur(Float blur) {
        this.blur = blur;
    }
}
