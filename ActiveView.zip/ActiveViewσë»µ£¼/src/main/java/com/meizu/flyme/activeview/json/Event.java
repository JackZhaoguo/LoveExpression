package com.meizu.flyme.activeview.json;

public class Event {
    public static final String TYPE_CLICK = "click";
    public static final String TYPE_TOUCH = "touch";

    /**
     * 启动Activity
     */
    public static final String ACTION_TYPE_NATIVE = "startActivity";
    /** 启动服务 */
    public static final String ACTION_TYPE_SERVICE = "startService";
    /** 发送广播 */
    public static final String ACTION_TYPE_BROADCAST = "sendBroadcast";
    /** 发送本地广播 */
    public static final String ACTION_TYPE_LOCAL_BROADCAST = "sendLocalBroadcast";
    /** 显示Toast */
    public static final String ACTION_TYPE_TOAST = "showToast";


    private String type;
    private String action;
    private String args;

    public Event() {
    }

    public String getAction() {
        return action;
    }

    public String getArgs() {
        return args;
    }

    public String getType() {
        return type;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public void setArgs(String agrs) {
        this.args = agrs;
    }

    public void setType(String type) {
        this.type = type;
    }
}
