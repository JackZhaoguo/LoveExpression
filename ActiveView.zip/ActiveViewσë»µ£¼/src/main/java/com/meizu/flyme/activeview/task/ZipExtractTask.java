package com.meizu.flyme.activeview.task;

import android.os.AsyncTask;
import android.os.SystemClock;

import com.meizu.flyme.activeview.listener.OnZipExtractListener;
import com.meizu.flyme.activeview.utils.FileUtil;
import com.meizu.flyme.activeview.utils.LogUtil;

import net.lingala.zip4j.model.FileHeader;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

/**
 * Extract the zip file asynchronously.
 */
public class ZipExtractTask extends AsyncTask<Void, Integer, Long> {
    private static final String LOG_TAG = "ZipExtractTask";
    private final File mInput;
    private final File mOutput;
    private OnZipExtractListener mListener;
    private String mEextractedDir;
    private String mPassword;

    /**
     * This method can be use inner ActiveView, it can update ActiveView after extract finished.
     *
     * @param inFile The zip file to be extracted with absolute path. ex: /storage/emulated/0/Android/data/com.example.meizu.bannerviewtest/files/banner/output.zip
     * @param outputDir The output directory with absolute path. ex: /storage/emulated/0/Android/data/com.example.meizu.bannerviewtest/files/banner
     * @param listener The OnZipExtractListener.
     */
    public ZipExtractTask(String inFile, String outputDir, String password, OnZipExtractListener listener) {
        super();
        mListener = listener;
        mInput = new File(inFile);
        mOutput = new File(outputDir);
        mPassword = password;

        mEextractedDir =  mOutput.getAbsolutePath();
        LogUtil.i(LOG_TAG, "Extract mInput file = " + mInput.toString());
        LogUtil.i(LOG_TAG, "Extract mOutput file = " + mOutput.toString());

        if(!mOutput.exists()){
            if(!mOutput.mkdirs()){
                LogUtil.e(LOG_TAG, "Failed to make directories:" + mOutput.getAbsolutePath());
                if (mListener != null) {
                    mListener.onExtractError("Failed to make directories:" + mOutput.getAbsolutePath());
                }
            }
        }
    }

    public ZipExtractTask(String inFile, String outputDir, String password) {
        this(inFile, outputDir, password, null);
        LogUtil.i(LOG_TAG, "Extract Destination dir = " + mEextractedDir);
    }


    @Override
    protected Long doInBackground(Void... params) {
        if(isCancelled()) {
            mListener = null;
            return 0L;
        }
        // return unzip();
        return unzip2();
    }

    @Override
    protected void onPostExecute(Long result) {
        if(isCancelled()) {
            mListener = null;
            return;
        }

        if (mListener != null) {
            if (result != -1) {
                mListener.onExtractFinished(OnZipExtractListener.EXTRACT_SUCESS, mEextractedDir);
                deleteZipFile();
            } else {
                mListener.onExtractFinished(OnZipExtractListener.EXTRACT_FAIL, "Extract File ERROR. File=" + mInput.toString());
            }
            mListener = null;
        }
    }

    private void deleteZipFile() {
        // delete *.zip file after extracted.
        if (mInput != null && mInput.exists()) {
            if (mInput.delete()) {
                LogUtil.i(LOG_TAG, "Delete file:" +  mInput.toString() + " after extracted.");
            } else {
                LogUtil.i(LOG_TAG, "Can't delete file:" +  mInput.toString() + " after extracted.");
            }
        }
    }

    public String doUnzipSync() {
        long extractedSize = unzip();
        return extractedSize > 0 ? mEextractedDir : null;
    }

    /**
     * This method unzip an encrypt zip file with zip4j library.
     */
    private long unzip2() {
        if (mListener != null) {
            mListener.onExtractStart(mInput.getAbsolutePath());
        }

        long start = SystemClock.currentThreadTimeMillis();

        try {
            net.lingala.zip4j.core.ZipFile zFile= new net.lingala.zip4j.core.ZipFile(mInput);
            zFile.setFileNameCharset("UTF-8");
            if (!zFile.isValidZipFile()) {
                LogUtil.e(LOG_TAG, "Invalid ZipFile!");
                if (mListener != null) {
                    mListener.onExtractError("Invalid ZipFile!");
                }
                return -1;
            }
            if (zFile.isEncrypted()) {
                zFile.setPassword(mPassword);
            } else {
                LogUtil.i(LOG_TAG, "zFile is not Encrypted!");
            }



            String folderInZip = null;
            List list = zFile.getFileHeaders();
            for (int i = 0, size = list.size(); i < size; i++) {
                folderInZip = ((FileHeader)(zFile.getFileHeaders().get(i))).getFileName();
                if (folderInZip.startsWith("__") || folderInZip.startsWith(".")) {
                    continue;
                } else {
                    break;
                }
            }
            LogUtil.i(LOG_TAG, "zFile folderInZip=" + folderInZip);

            String tempUpZipDir = null;
            if (mEextractedDir == null) {
                mEextractedDir = mOutput.getAbsolutePath() + "/" + folderInZip;
            } else {
                tempUpZipDir = mOutput.getAbsolutePath() + "/" + folderInZip;
                LogUtil.i(LOG_TAG, "tempUpZipDir = " + tempUpZipDir.toString());
            }

            zFile.extractAll(mOutput.toString());
            if (tempUpZipDir != null) {
                if (!mEextractedDir.equals(tempUpZipDir)) {
                    FileUtil.copyFolder(tempUpZipDir, mEextractedDir);
                    FileUtil.deleteDirectory(tempUpZipDir);
                }
            }
        } catch (net.lingala.zip4j.exception.ZipException e) {
            LogUtil.e(LOG_TAG, "zFile ZipException=" + e.toString());
            if (mListener != null) {
                mListener.onExtractError("zFile Exception=" + e.toString());
            }
            return -1;
        }

        long end = SystemClock.currentThreadTimeMillis();

        LogUtil.i(LOG_TAG, "Extract file " + mInput + ", UseTime =" + String.valueOf(end - start));

        deleteZipFile();
        return 0;
    }

    /**
     * This method unzip an decrypt zip file with java.util.zip.
     */
    private long unzip() {
        if (mListener != null) {
            mListener.onExtractStart(mInput.getAbsolutePath());
        }

        long start = SystemClock.currentThreadTimeMillis();

        long extractedSize = 0L;
        boolean deleteTempDir = false;
        Enumeration<ZipEntry> entries;
        ZipFile zip = null;
        String zipDirName = null;
        try {
            zip = new ZipFile(mInput);
            entries = (Enumeration<ZipEntry>) zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                if (entry.isDirectory()) {
                    continue;
                }

                String fileName = entry.getName();
                if (zipDirName == null && fileName != null) {
                    zipDirName = fileName.split("/")[0];
                    LogUtil.i(LOG_TAG, "Extract temp directory=" + mOutput + "/" + zipDirName);
                }
                File destination = new File(mOutput, fileName);
                if (!destination.getParentFile().exists()) {
                    if (destination.getParentFile().mkdirs()) {
                        LogUtil.i(LOG_TAG, "Make Destination directory=" + destination.getParentFile().getAbsolutePath());
                    } else {
                        LogUtil.i(LOG_TAG, "Can't make destination directory=" + destination.getParentFile().getAbsolutePath());
                    }
                }

                FileOutputStream outStream = new FileOutputStream(destination);
                extractedSize += copy(zip.getInputStream(entry), outStream);
                outStream.close();
            }

            String tempDir = mOutput + "/" + zipDirName;
            if (!mEextractedDir.equals(tempDir)) {
                FileUtil.copyFolder(tempDir, mEextractedDir);
                deleteTempDir = true;
            }

        } catch (ZipException e) {
            LogUtil.e(LOG_TAG, "ZipException :" + e.toString());
            if (mListener != null) {
                mListener.onExtractError("ZipException :" + e.toString());
            }
        } catch (IOException e) {
            LogUtil.e(LOG_TAG, "Extracted IOException:" + e.toString());
            if (mListener != null) {
                mListener.onExtractError("Extracted IOException:" + e.toString());
            }
        } finally {
            try {
                if (zip != null) {
                    zip.close();
                }
            } catch (IOException e) {
                LogUtil.e(LOG_TAG, "Extracted IOException:" + e.toString());
                if (mListener != null) {
                    mListener.onExtractError("Extracted IOException:" + e.toString());
                }
            }
        }

        long end = SystemClock.currentThreadTimeMillis();

        LogUtil.i(LOG_TAG, "Extract file " + mInput + ", UseTime =" + String.valueOf(end - start));

        if (deleteTempDir) {
            FileUtil.deleteDirectory(mOutput + "/" + zipDirName);
        }

        deleteZipFile();
        return extractedSize;
    }

    private int copy(InputStream input, OutputStream output){
        byte[] buffer = new byte[1024 * 8];
        BufferedInputStream in = new BufferedInputStream(input, 1024 * 8);
        BufferedOutputStream out  = new BufferedOutputStream(output, 1024 * 8);
        int count =0;
        int n;
        try {
            while ((n = in.read(buffer, 0, 1024 * 8)) != -1) {
                out.write(buffer, 0, n);
                count += n;
            }
            out.flush();
        } catch (IOException e) {
            LogUtil.e(LOG_TAG, "Extracted IOException:" + e.toString());
        } finally {
            try {
                out.close();
            } catch (IOException e) {
                LogUtil.e(LOG_TAG, "out.close() IOException e=" + e.toString());
            }
            try {
                in.close();
            } catch (IOException e) {
                LogUtil.e(LOG_TAG, "in.close() IOException e=" + e.toString());
            }
        }
        return count;
    }
}
