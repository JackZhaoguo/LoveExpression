package com.meizu.flyme.activeview.moveline.item;

import java.util.List;
import java.util.Set;

/**
 * Created by suyouxiong on 16-6-21.
 */
public interface FrameStyle {

    /**
     * 属性值类型，在计算进度值时需要根据数值类型
     */
    enum PropertyValueType {

        /**
         * 整型
         */
        INT,

        /**
         * 浮点型
         */
        FLOAT,

        /**
         * 其它
         */
        OTHER
    }

    /**
     * 获取这一帧需要更新的属性集
     * @return
     */
    Set<String> getUpdateProperties();

    /**
     * 获取帧属性值
     * @param propertyName
     * @return
     */
    Object getPropertyValue(String propertyName);


    /**
     * 获取帧属性值的类型，用以计算进度值，如果是OTHER类型，将不计算
     * @param propertyName
     * @return
     */
    PropertyValueType getPropertyValueType(String propertyName);

    /**
     * 设置这一帧的某属性的值
     *
     * @param propertyName
     * @param value
     */
    void setPropertyValue(String propertyName, Object value);
}
