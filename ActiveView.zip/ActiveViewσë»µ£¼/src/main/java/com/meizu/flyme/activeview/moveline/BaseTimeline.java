package com.meizu.flyme.activeview.moveline;

/**
 * Created by suyouxiong on 16-6-20.
 */
public abstract class BaseTimeline extends Animation {
    private static final String TAG = BaseTimeline.class.getSimpleName();
    protected Animation first;
    protected Animation last;
    private boolean mStarted;


    private long time;

    public BaseTimeline() {
        super();
    }

    protected void add(Animation child) {
        if (child.timeline != null) {
            child.timeline.remove(child);
        }

        Animation prevAnim = this.last;
        if (null != prevAnim) {
            child.next = prevAnim.next;
            prevAnim.next = child;
        } else {
            child.next = this.first;
            this.first = child;
        }
        if (child.next != null) {
            child.next.prev = child;
        } else {
            this.last = child;
        }
        child.prev = prevAnim;
        child.timeline = this;
        this.dirty = true;
    }

    public void add(Animation child, int delay) {
        add(child, -1, delay);
    }

    public void add(Animation child, long position, int delay) {
        position = calcPosition(position, delay);
        child.startTime = position;
        add(child);
    }

    private long calcPosition(long position, int delay) {
        if (position >= 0) {
            return position + delay;
        } else {
            long duration = getDuration();

            return duration + delay;
        }
    }

    public BaseTimeline remove(Animation child) {
        if (child.timeline == this) {
            if (child.prev != null) {
                child.prev.next = child.next;
            } else if (this.first == child) {
                this.first = child.next;
            }
            if (child.next != null) {
                child.next.prev = child.prev;
            } else if (this.last == child) {
                this.last = child.prev;
            }

            child.next = child.prev = child.timeline = null;

        }
        return this;
    }

    @Override
    protected void setActive(boolean active) {
        super.setActive(active);
        Animation tween = this.first;
        while (tween != null) {
            tween.setActive(active);
            tween = tween.next;
        }
    }

    @Override
    protected void initAnimationValue() {

    }
}
