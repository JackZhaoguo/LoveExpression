package com.meizu.flyme.activeview.json;

public class ActiveData {

    private String version;
    private String miniCompatibleVersion;

    private Content content;

    public ActiveData() {}

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public void setMiniCompatibleVersion(String miniCompatibleVersion) {
        this.miniCompatibleVersion = miniCompatibleVersion;
    }

    public String getMiniCompatibleVersion() {
        return miniCompatibleVersion;
    }

    public Content getContent() {
        return content;
    }

    public void setContent(Content content) {
        this.content = content;
    }
}
