package com.meizu.flyme.activeview.moveline;

/**
 * Created by suyouxiong on 16-7-1.
 */
public interface AnimationListener {

    void onAnimationEnd(Animation animation);

    void onAnimationStopped(Animation animation);

    void onAnimationStart(Animation animation);
}
