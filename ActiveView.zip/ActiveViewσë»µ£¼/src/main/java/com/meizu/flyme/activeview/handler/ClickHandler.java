package com.meizu.flyme.activeview.handler;

import android.content.Context;
import android.view.View;
import android.widget.Toast;

import com.meizu.flyme.activeview.json.Event;
import com.meizu.flyme.activeview.utils.IntentUtils;


/**
 * Created by suyouxiong on 2016/10/20.
 */
public class ClickHandler extends EventHandler implements View.OnClickListener {

    protected ClickHandler(View view, String id, Event event) {
        super(view, id, event);
        view.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {

        //如果应用没有处理此点击事件，我们尝试处理
        if (mOnEventListener == null || !mOnEventListener.onClick(mId, mEvent.getAction(), mEvent.getArgs())) {
            performClick();
        }
    }

    private void performClick() {
        String action = mEvent.getAction();
        switch (action) {
            case Event.ACTION_TYPE_TOAST :
                Toast.makeText(mView.getContext(), mEvent.getArgs(), Toast.LENGTH_SHORT).show();
                break;

            default:
                handleIntentUriEvent(mView.getContext(), mEvent);
        }
    }


    /**
     * 处理URI跳转
     * @param context
     * @param event
     * @return
     */
    private static void handleIntentUriEvent(final Context context, final Event event) {
        if (event == null) {
            return;
        }

        String uri = event.getArgs();
        if (!IntentUtils.handleActionUri(context, event.getAction(), uri)) {
            // TODO: 2016/10/21 error handle
            /*
            final String errorMessage = event.getErrorMessage();
            final String errorUrl = event.getErrorUrl();
            final int errorType = event.getErrorType();

            if (TextUtils.isEmpty(errorMessage)) {
                //无错误提示
                if (!TextUtils.isEmpty(errorUrl)) {
                    handleActionUri(context, errorType, errorUrl, event);
                }
            } else {
                //有错误弹框
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setMessage(errorMessage);
                builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        handleActionUri(context, errorType, errorUrl, event);
                    }
                });
                if (!TextUtils.isEmpty(errorUrl)) {
                    builder.setNegativeButton(android.R.string.cancel, null);
                }
                try {
                    builder.show();
                } catch (Exception e){
                    e.printStackTrace();
                }
            }
            */
        }
    }

}
