package com.meizu.flyme.activeview.json;

import android.content.Context;
import android.graphics.Color;

import com.meizu.flyme.activeview.utils.DisplayUnitUtil;

import java.util.List;

public class Element {

    private static final String LOG_TAG = "Parse_Element";

    private static final int DOM_2D_ARRAY_LENGTH  = 2;
    private static final int DOM_RECT_ARRAY_LENGTH  = 4;
    private static final int DOM_3D_ARRAY_LENGTH  = 3;

    private String id;
    private String type;

    private String[] rect;
    private float[] mRectRegion = new float[DOM_RECT_ARRAY_LENGTH];

    private String radius;
    private float mRadiusValue;

    private String background;
    private Integer mBackgroundColorValue;

    private float[] scale2d = new float[DOM_2D_ARRAY_LENGTH];

    private float[] rotate3d = new float[DOM_3D_ARRAY_LENGTH];
    private String[] rotateCenter = new String[DOM_2D_ARRAY_LENGTH];
    private float[] rotateCenterValue = new float[DOM_2D_ARRAY_LENGTH];

    private Integer opacity;
    private String hover;

    List<Event> events;

    String url;

    List<Animation> animations;

    Parallax parallax;

    private TextAttrs textAttrs;
    private Particle2DAttr particle2DAttr;

    private Float blur;

    private VideoAttr videoAttr;

    public Element() {}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
         this.type = type;
    }

    public String[] getRect() {
        return rect;
    }

    public void setRect(String[] rect) {
        this.rect = rect;
    }

    public float[] getRectRegion(Context context) {
        if (rect != null && rect.length == DOM_RECT_ARRAY_LENGTH) {
            if (mRectRegion != null && mRectRegion.length == DOM_RECT_ARRAY_LENGTH) {
                for (int i = 0; i < DOM_RECT_ARRAY_LENGTH; i++) {
                    if (rect[i] != null) {
                        mRectRegion[i] = (float) DisplayUnitUtil.getPixelValue(context, rect[i]);
                    }
                }
            }
        }
        return mRectRegion;
    }

    public String getRadius() {
        return radius;
    }

    public void setRadius(String radius) {
        this.radius = radius;
    }

    public float getRadiusValue(Context context) {
        if (radius != null &&!radius.isEmpty()) {
            mRadiusValue = DisplayUnitUtil.getPixelValue(context, radius);
        }
        return mRadiusValue;
    }

    public void setBackground(String background) {
        this.background = background;
    }

    public String getBackground() {
        return background;
    }

    public Integer getBackgroundColorValue() {
        if (background != null && !background.isEmpty()) {
            mBackgroundColorValue = Color.parseColor(background);
        }
        return mBackgroundColorValue;
    }

    public float[] getScale2d() {
        return scale2d;
    }

    public void setScale2d(float[] scale2d) {
        if (scale2d.length != DOM_2D_ARRAY_LENGTH) {
            return;
        }
        this.scale2d = scale2d;
    }

    public float[] getRotate3d() {
        return rotate3d;
    }

    public void setRotate3d(float[] rotate3d) {
        if (rotate3d.length != DOM_3D_ARRAY_LENGTH) {
            return;
        }
        this.rotate3d = rotate3d;
    }

    public Integer getOpacity() {
        return opacity;
    }

    public void setOpacity(Integer opacity) {
        this.opacity = opacity;
    }

    public void setHover(String hover) {
        this.hover = hover;
    }

    public String getHover() {
        return hover;
    }

    public List<Event> getEvents() {
        return events;
    }

    public void setEvents(List<Event> events) {
        this.events = events;
    }

    public List<Animation> getAnimations() {
        return animations;
    }

    public void setAnimations(List<Animation> animations) {
        this.animations = animations;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void setRotateCenter(String[] rotateCenter) {
        if (rotateCenter.length != DOM_2D_ARRAY_LENGTH) {
            return;
        }
        this.rotateCenter = rotateCenter;
    }

    public float[] getRotateCenterValue() {
        if (rotateCenter != null && rotateCenter.length == DOM_2D_ARRAY_LENGTH) {
            for (int i = 0; i < DOM_2D_ARRAY_LENGTH; i++) {
                if (rotateCenter[i] != null) {
                    rotateCenterValue[i] = Float.parseFloat(rotateCenter[i].substring(0, rotateCenter[i].length() - 2));
                }
            }
        }
        return rotateCenterValue;
    }

    public String[] getRotateCenter() {
        return rotateCenter;
    }

    public void setParallax(Parallax parallax) {
        this.parallax = parallax;
    }

    public Parallax getParallax() {
        return this.parallax;
    }

    public void setTextAttrs(TextAttrs textAttrs){
        this.textAttrs = textAttrs;
    }
    public TextAttrs getTextAttrs(){
        return this.textAttrs;
    }

    public void setParticle2DAttr(Particle2DAttr graphicsAnimAttr){
        this.particle2DAttr = graphicsAnimAttr;
    }

    public Particle2DAttr getParticle2DAttr(){
        return this.particle2DAttr;
    }

    public Float getBlur() {
        return blur;
    }

    public void setBlur(Float blur) {
        this.blur = blur;
    }

    public void setVideoAttr(VideoAttr videoAttr) {
        this.videoAttr = videoAttr;
    }

    public VideoAttr getVideoAttr() {
        return this.videoAttr;
    }
}
