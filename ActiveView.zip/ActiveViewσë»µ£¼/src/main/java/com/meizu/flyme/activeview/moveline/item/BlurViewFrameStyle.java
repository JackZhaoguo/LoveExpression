package com.meizu.flyme.activeview.moveline.item;

import android.util.Log;

import com.meizu.flyme.activeview.moveline.Config;

import java.util.Set;

/**
 * Created by suyouxiong on 2016/11/5.
 */
public class BlurViewFrameStyle extends ViewFrameStyle {

    BlurViewFrameStyle() {
        super();
    }

    @Override
    public Set<String> getUpdateProperties() {
        return mToUpdateStyles;
    }

    @Override
    public Object getPropertyValue(String propertyName) {
        return mStyleValueMap.get(propertyName);
    }

    @Override
    public PropertyValueType getPropertyValueType(String propertyName) {

        if (propertyName.equals(BlurViewTweenItem.BLUR)) {
            return PropertyValueType.FLOAT;
        }

        return super.getPropertyValueType(propertyName);
    }

    @Override
    public void setPropertyValue(String propertyName, Object value) {
        try {
            if (propertyName.equals(BlurViewTweenItem.BLUR)) {
                setBlur((Float) value);
                mToUpdateStyles.add(propertyName);
            } else {
                super.setPropertyValue(propertyName, value);
            }
        } catch (ClassCastException e) {
            Log.e(Config.MOVELINE_LOG_TAG, "the value type of the property " + propertyName + " is illegal:" + e.getMessage());
        }
    }

    private void setBlur(float blurLevel) {
        mStyleValueMap.put(BlurViewTweenItem.BLUR, blurLevel);
    }
}
