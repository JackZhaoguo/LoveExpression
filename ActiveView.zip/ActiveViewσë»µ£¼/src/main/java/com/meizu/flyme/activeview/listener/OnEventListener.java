package com.meizu.flyme.activeview.listener;

/**
 * Called when a view has event.
 */
public interface OnEventListener {
    /**
     * @param elementId The elementId which .
     * @param event     The view event.
     * @deprecated
     */
//        void onEvent(String elementId, Event event);

    /**
     * Called when the item is clicked
     *
     * @param elementId  The elementId which clicked.
     * @param action     the type of this event, can be one of {@link com.meizu.flyme.activeview.json.Event#ACTION_TYPE_NATIVE}, {@link com.meizu.flyme.activeview.json.Event#ACTION_TYPE_SERVICE}, {@link com.meizu.flyme.activeview.json.Event#ACTION_TYPE_BROADCAST},
     * @param args       The args needed.
     * @return true: do yourself;false: ActiveView try to do it
     */
    boolean onClick(String elementId, String action, String args);
}