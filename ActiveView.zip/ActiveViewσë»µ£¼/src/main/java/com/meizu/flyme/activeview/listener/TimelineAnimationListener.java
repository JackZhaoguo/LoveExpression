package com.meizu.flyme.activeview.listener;

import com.meizu.flyme.activeview.moveline.Animation;
import com.meizu.flyme.activeview.moveline.AnimationListener;
import com.meizu.flyme.activeview.moveline.Timeline;
import com.meizu.flyme.activeview.utils.LogUtil;
import com.meizu.flyme.activeview.views.ActiveView;

import java.lang.ref.WeakReference;

/**
 * Implements interface AnimationListener.
 */
public class TimelineAnimationListener implements AnimationListener {
    private final static String LOG_TAG = "TimelineAnimationListener";
    private Timeline mTimeline;
    private WeakReference<ActiveView> mActiveView;

    public TimelineAnimationListener(ActiveView bv, Timeline timeline) {
        mTimeline = timeline;
        mActiveView = new WeakReference<ActiveView>(bv);
    }

    @Override
    public void onAnimationEnd(com.meizu.flyme.activeview.moveline.Animation animation) {
        if (mTimeline != null && mActiveView != null && mActiveView.get() != null && mActiveView.get().isShowing()) {
            // timeline play mode is loop, call play again.
            // mTimeline.play();
            LogUtil.i(LOG_TAG, "Replay the animation.");
            mActiveView.get().startAnimation();
        }
    }

    @Override
    public void onAnimationStopped(com.meizu.flyme.activeview.moveline.Animation animation) {

    }

    @Override
    public void onAnimationStart(Animation animation) {

    }
}