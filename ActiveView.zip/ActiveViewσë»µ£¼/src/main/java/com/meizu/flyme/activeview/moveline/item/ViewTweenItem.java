package com.meizu.flyme.activeview.moveline.item;

import android.graphics.PathMeasure;
import android.util.Log;
import android.view.View;

import com.meizu.flyme.activeview.moveline.Config;

import java.lang.ref.WeakReference;

/**
 * Created by suyouxiong on 16-6-22.
 */
public class ViewTweenItem implements TweenItem {

    public static final String LEFT = "left";
    public static final String TOP = "top";
    public static final String SCALE_X = "scaleX";
    public static final String SCALE_Y = "scaleY";
    public static final String ROTATION = "rotation";
    public static final String ROTATION_X = "rotationX";
    public static final String ROTATION_Y = "rotationY";
    public static final String ALPHA = "alpha";
    public static final String TRACK_PATH = "trackPath";
    protected WeakReference<View> mTarget;

    public ViewTweenItem(View target) {
        mTarget = new WeakReference<>(target);
    }

    /**
     *
     * @param newTarget
     * @deprecated use {@link #setTarget(View)} instead
     */
    public void replaceTarget(View newTarget) {
        this.mTarget = new WeakReference<>(newTarget);
    }

    @Override
    public boolean isUpdatable() {
        return mTarget.get() != null;
    }

    @Override
    public void updateProperty(String propertyName, Object value, float fraction) {
        View targetView = mTarget.get();
        if (targetView == null) return;
        try {
            if (propertyName.equals(LEFT)) {
                targetView.setTranslationX((Float) value);

            } else if (propertyName.equals(TOP)) {
                targetView.setTranslationY((Float) value);

            } else if (propertyName.equals(SCALE_X)) {
                targetView.setScaleX((Float) value);

            } else if (propertyName.equals(SCALE_Y)) {
                targetView.setScaleY((Float) value);

            } else if (propertyName.equals(ROTATION_X)) {
                targetView.setRotationX((Float) value);

            } else if (propertyName.equals(ROTATION_Y)) {
                targetView.setRotationY((Float) value);

            } else if (propertyName.equals(ALPHA)) {
                targetView.setAlpha((Float) value);

            } else if (propertyName.equals(ROTATION)) {
                targetView.setRotation((Float) value);

            } else if (propertyName.equals(TRACK_PATH)) {//如果是轨迹动画，没有相对的开始位置，直接跟着轨迹走
                PathMeasure pathMeasure = (PathMeasure) value;
                float length = pathMeasure.getLength();
                float distance = length * fraction;
                float[] curPosition = new float[2];
                pathMeasure.getPosTan(distance, curPosition, null);
                int width = targetView.getMeasuredWidth();
                int height = targetView.getMeasuredHeight();
                float left = curPosition[0] - (width / 2);
                float top = curPosition[1] - (height / 2);
                targetView.setTranslationX(left);
                targetView.setTranslationY(top);
            }
        } catch (ClassCastException e) {
            Log.e(Config.MOVELINE_LOG_TAG, "the value type of the property " + propertyName + " is illegal:" + e.getMessage());
        }
    }

    @Override
    public Object getPropertyValue(String propertyName) {
        View targetView = mTarget.get();
        if (targetView == null) return null;
        if (propertyName.equals(LEFT)) {
            return targetView.getTranslationX();

        } else if (propertyName.equals(TOP)) {
            return targetView.getTranslationY();

        } else if (propertyName.equals(SCALE_X)) {
            return targetView.getScaleX();

        } else if (propertyName.equals(SCALE_Y)) {
            return targetView.getScaleY();

        } else if (propertyName.equals(ROTATION_X)) {
            return targetView.getRotationX();

        } else if (propertyName.equals(ROTATION_Y)) {
            return targetView.getRotationY();

        } else if (propertyName.equals(ALPHA)) {
            return targetView.getAlpha();

        } else if (propertyName.equals(ROTATION)) {
            return targetView.getRotation();

        } else if (propertyName.equals(TRACK_PATH)) {
        }
        return null;
    }

    @Override
    public FrameStyle buildFrameStyle() {
        return new ViewFrameStyle();
    }

    public void setTarget(View target) {
        mTarget = new WeakReference<>(target);
    }
}
