package com.meizu.flyme.activeview.views;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputFilter;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.CycleInterpolator;
import android.view.animation.PathInterpolator;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.meizu.flyme.activeview.adapter.ViewAdapter;
import com.meizu.flyme.activeview.graphicsanim.renderable.ParticleSystem;
import com.meizu.flyme.activeview.graphicsanim.widget.ParticleView;
import com.meizu.flyme.activeview.handler.EventHandler;
import com.meizu.flyme.activeview.json.ActiveData;
import com.meizu.flyme.activeview.json.Animation;
import com.meizu.flyme.activeview.json.Args;
import com.meizu.flyme.activeview.json.Element;
import com.meizu.flyme.activeview.json.Event;
import com.meizu.flyme.activeview.json.Interpolator;
import com.meizu.flyme.activeview.json.NewElementData;
import com.meizu.flyme.activeview.json.NewElementInfo;
import com.meizu.flyme.activeview.json.Page;
import com.meizu.flyme.activeview.json.Parallax;
import com.meizu.flyme.activeview.json.Parameter;
import com.meizu.flyme.activeview.json.Particle2DAttr;
import com.meizu.flyme.activeview.json.Style;
import com.meizu.flyme.activeview.json.TextAttrs;
import com.meizu.flyme.activeview.json.VideoAttr;
import com.meizu.flyme.activeview.listener.OnActiveViewUpgradeListener;
import com.meizu.flyme.activeview.listener.OnAsyncTaskListener;
import com.meizu.flyme.activeview.listener.OnDownloadListener;
import com.meizu.flyme.activeview.listener.OnEventListener;
import com.meizu.flyme.activeview.listener.OnJsonParserListener;
import com.meizu.flyme.activeview.listener.OnLoadDataListener;
import com.meizu.flyme.activeview.listener.OnLoadImageListener;
import com.meizu.flyme.activeview.listener.OnParallaxListener;
import com.meizu.flyme.activeview.listener.OnUpdateListener;
import com.meizu.flyme.activeview.listener.OnVersionListener;
import com.meizu.flyme.activeview.listener.OnZipExtractListener;
import com.meizu.flyme.activeview.moveline.Timeline;
import com.meizu.flyme.activeview.moveline.TimelineTicker;
import com.meizu.flyme.activeview.moveline.item.BlurViewTweenItem;
import com.meizu.flyme.activeview.moveline.item.FrameStyle;
import com.meizu.flyme.activeview.moveline.item.ViewTweenItem;
import com.meizu.flyme.activeview.task.LoadDataTask;
import com.meizu.flyme.activeview.task.LoadImageTask;
import com.meizu.flyme.activeview.utils.CacheUtils;
import com.meizu.flyme.activeview.utils.Constants;
import com.meizu.flyme.activeview.utils.FileDownloader;
import com.meizu.flyme.activeview.utils.FileUtil;
import com.meizu.flyme.activeview.utils.ImageCache;
import com.meizu.flyme.activeview.utils.ImageCacheUtils;
import com.meizu.flyme.activeview.utils.JsonParser;
import com.meizu.flyme.activeview.utils.LogUtil;
import com.meizu.flyme.activeview.utils.PasswordUtils;
import com.meizu.flyme.activeview.utils.UpdaterUtils;
import com.meizu.flyme.activeview.utils.ActiveUsageStatsUtils;
import com.meizu.flyme.activeview.utils.ZipExtractor;
import com.meizu.flyme.activeview.version.Version;
import com.meizu.flyme.activeview.version.VersionManager;

import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class ActiveViewImpl extends IActiveView implements VersionManager.OnVersionChangedListener{
    private static final String LOG_TAG = "activeview.ActiveView";

    // element type
    static final String ELEMENT_IMAGE = "image";
    static final String ELEMENT_BUTTON = "button";
    static final String ELEMENT_VIDEO = "video";
    static final String ELEMENT_TEXT = "text";
    static final String ELEMENT_GIF = "gif";

    static final String ELEMENT_PARTICLE = "particle";       // 粒子系统

    static final String ELEMENT_PARTICLE2D = "particle2D";       // 2D粒子系统

    // view type
    private static final String VIEW_IMAGEVIEW = "imageview";
    private static final String VIEW_TEXTVIEW = "textview";

    // interpolator type
    private static final String INTERPOLATOR_TYPE_SHAKE = "shake";
    private static final String INTERPOLATOR_TYPE_LINEAR = "linear";
    private static final String ACTIVE_TIMELINE_KEY = "active_view_timeline";

    private String mZipPassword;

    private Context mContext;
    private boolean mbUseAssetsResources;
    private ActiveData mActiveData;

    // save all timeline animation in the ActiveView, for control their resume,pause,start and stop.
    private HashMap<String, Timeline> mTimelineMap = new HashMap<>();

    private HashMap<String, ParticleView> mGraphicsAnimViewMap;

    private HashMap<String, GifMovieView> mGifMovieViewMap;

    private HashMap<String, TextureVideoView> mVideoViewMap;

    private Timeline mTimeline;

    // cache ViewTweenItem for update.
    private HashMap<View, ViewTweenItem> mTweenItemMap = new HashMap<>();

    private String mCacheDir;

    private String mUrl;
    private String mZipExtractedDir;

    private HashMap<AsyncTask, Boolean> mLoadImageTaskMap = new HashMap<>();

    // Cache the view element's info.
    private HashMap<String, ViewElementData> mViewElementCacheMap = new HashMap<>();

    private OnEventListener mOnEventListener;
    private OnVersionListener mOnVersionListener;
    private AsyncTaskListener mAsyncTaskListener;
    private OnLoadImageListener mOnLoadImageListener;
    private OnUpdateListener mOnUpdateListener;
    private OnParallaxListener mOnParallaxListener;
    private OnActiveViewUpgradeListener mOnActiveViewUpgradeListener;

    private float mScaleRate = 1.0f;
    private int mMeasuredWidth = 0;
    private boolean mMeasured = false;

    private AsyncTask mDownloadTask;
    private AsyncTask mZipExtractTask;

    private ImageView mImageView;
    private ImageView mDefaultImageView;

    private TextureVideoView mSimpleVideoView;

    private WebView mWebView;

    private int mColorPrimary;

    private boolean mAutoRunAnim = true;
    private boolean mAutoGradientDisplay = false;
    private AlphaAnimation mAutpAlphaAnimation;

    private boolean mUseParallax = true;
    private ArrayList<ParallaxData> mParallaxData;
    private LoadDataTask mLoadDataTask;

    private boolean mShowAfterImagesLoaded = false;
    private boolean mUpgradeChecked = false;

    private boolean mAutoDeleteFolder = true;
    private int mFolderHours = 168;          // 默认删除7天以上的缓存文件夹
    private VersionManager mVersionManager;

    private Handler mMsgHandler;
    /**
     * Normal constructor.
     *
     * @param context The context.
     */
    public ActiveViewImpl(Context context) {
        this(context, false);
    }

    /**
     * Constructor indicate if use assets resources or not.
     *
     * @param context            The context.
     * @param useAssetsResources Indicate use default resources in assets or not.
     */
    public ActiveViewImpl(Context context, boolean useAssetsResources) {
        super(context);
        mbUseAssetsResources = useAssetsResources;
        init(context);
        if (mbUseAssetsResources) {
            loadData(null, null);
        }
    }

    /**
     * Constructor with default image.
     *
     * @param context       The context.
     * @param defaultWidth  The default image width, it means the activeview is initial size.
     * @param defaultHeight The default image height.
     * @param defaultResId  The default image resource id.
     */
    public ActiveViewImpl(Context context, int defaultWidth, int defaultHeight, int defaultResId) {
        this(context, false);
        setDefaultImage(defaultWidth, defaultHeight, defaultResId);
    }

    public ActiveViewImpl(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    /**
     * Initiates some data, such as the resources saved path.
     *
     * @param context The context.
     */
    private void init(Context context) {
        mContext = context.getApplicationContext();
        if (mContext != null) {
            // default ActiveView resources saved path.
            mCacheDir = FileUtil.getActiveViewCachesDir(mContext);
            clearCacheFolder();
        }
    }

    /**
     * Get the pssward for extracting zip file.
     */
    public String getPassword() {
        if (mZipPassword == null) {
            mZipPassword = PasswordUtils.getZipPassward(mContext);
        }
        LogUtil.i(LOG_TAG, "mZipPassword=" + mZipPassword);
        return mZipPassword;
    }

    /**
     * Set the pssward for extracting zip file.
     */
    public void setPassword(String pwd) {
        mZipPassword = pwd;
    }

    /**
     * Indicate use default resources in assets or not.
     *
     * @param useAssetsResources If want to use asset resources after creating ActiveView, set it to be true.
     */
    public void setUseAssetsResources(boolean useAssetsResources) {
        mbUseAssetsResources = useAssetsResources;
    }

    /**
     * Set the default image of activeview.
     *
     * @param defaultWidth  The image width.
     * @param defaultHeight The image height.
     * @param defaultResId  The image resource id.
     */
    public void setDefaultImage(int defaultWidth, int defaultHeight, int defaultResId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            setDefaultImageDrawable(defaultWidth, defaultHeight, mContext.getDrawable(defaultResId));
        } else {
            Resources res = mContext.getResources();
            Bitmap bitmap = BitmapFactory.decodeResource(res, defaultResId);
            setDefaultImage(defaultWidth, defaultHeight, bitmap);
        }
    }

    /**
     * Set the default image of activeview without width and height value.
     *
     * @param defaultResId The image resource id.
     */
    public void setDefaultImage(int defaultResId) {
        setDefaultImage(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, defaultResId);
    }

    /**
     * Set the default image of activeview.
     *
     * @param defaultWidth  The image width.
     * @param defaultHeight The image height.
     * @param bitmap        The image bitmap.
     */
    public void setDefaultImage(int defaultWidth, int defaultHeight, Bitmap bitmap) {
        if (bitmap != null) {
            BitmapDrawable bitmapDrawable = new BitmapDrawable(mContext.getResources(), bitmap);
            setDefaultImageDrawable(defaultWidth, defaultHeight, bitmapDrawable);
        }
    }

    /**
     * Set the default image of activeview without width and height value.
     *
     * @param bitmap    The image bitmap.
     */
    public void setDefaultImage(Bitmap bitmap) {
        setDefaultImage(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, bitmap);
    }

    /**
     * Set the default image of activeview without width and height value.
     *
     * @param drawable    The image drawable.
     */
    public void setDefaultImage(Drawable drawable) {
        setDefaultImage(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, drawable);
    }

    /**
     * Set the default image of activeview.
     *
     * @param defaultWidth  The image width.
     * @param defaultHeight The image height.
     * @param drawable        The image drawable.
     */
    public void setDefaultImage(int defaultWidth, int defaultHeight, Drawable drawable) {
        setDefaultImageDrawable(defaultWidth, defaultHeight, drawable);
    }

    private void setDefaultImageDrawable(int defaultWidth, int defaultHeight, Drawable drawable) {
        if (mDefaultImageView == null) {
            mDefaultImageView = new ImageView(mContext);
        }

        mDefaultImageView.setBackground(drawable);

        if (mDefaultImageView.getParent() == null) {
            clearActiveView();
            LayoutParams layoutParams = new LayoutParams(defaultWidth, defaultHeight);
            this.setVisibility(VISIBLE);
            this.addView(mDefaultImageView, layoutParams);
        }
    }

    /**
     * Remove child views and reset data.
     */
    private void clearActiveView() {
        mActiveData = null;
        stopAnimation();
        mTimeline = null;
        mTimelineMap.clear();
        if (mParallaxData != null) {
            mParallaxData.clear();
            mParallaxData = null;
        }
        removeAllViews();
    }

    /**
     * Return the theme color.
     */
    public int getColorPrimary() {
        return mColorPrimary;
    }

    /**
     * Update resources for the given url.
     *
     * @param url The resources file url to get data.
     */
    public void updateResource(String url) {
        if (url == null) {
            return;
        }
        LogUtil.i(LOG_TAG, "updateResource url=" + url);
        if (url.endsWith(".act") || url.endsWith(".zip")) {
            downloadPackage(url);
        } else if (isVideoURL(url)) {
            downloadVideo(url, this.getMeasuredWidth(), this.getMeasuredHeight());
        } else {
            downloadImage(url);
        }
    }

    public void setOnUpdateListener(OnUpdateListener listener) {
        mOnUpdateListener = listener;
    }

    public void setParallaxListener(OnParallaxListener listener) {
        mOnParallaxListener = listener;
    }

    public void setParallaxListener(Boolean useParallax) {
        mUseParallax = useParallax;
    }

    /**
     * Check the resource type if image by url.
     *
     * @param url The url to be checked.
     */
    private boolean isImageURL(String url) {
        return url.endsWith(".png") || url.endsWith(".jpg");
    }

    /**
     * Check the resource type if video by url.
     *
     * @param url The url to be checked.
     */
    private boolean isVideoURL(String url) {
        return url.endsWith(".mp4") || url.endsWith(".3gp") || url.endsWith(".webm") || url.endsWith(".mkv") || url.endsWith(".mov");
    }

    /**
     * Download image for the given url.
     *
     * @param url The image url.
     */
    public void downloadImage(String url) {
        downloadImage(url, null);
    }

    /**
     * Download image for the given url with listener.
     *
     * @param url      The image url.
     * @param listener The listener for loading image result.
     */
    public void downloadImage(String url, OnLoadImageListener listener) {
        if (url == null || url.isEmpty() || (mUrl != null && mUrl.equals(url))) {
            LogUtil.e(LOG_TAG, "mUrl == url, don't update Image.");
            return;
        }

        mUrl = url;
        if (mImageView == null) {
            mImageView = new ImageView(mContext);
            mImageView.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
            mImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        }

        if (listener != null) {
            mOnLoadImageListener = listener;
        }

        if (mImageView.getParent() != null) {
            mImageView.setVisibility(INVISIBLE);
        }

        UpdaterUtils.getInstance(mContext).loadImage(mImageView, url, 0, 0, new UpdaterUtils.OnLoadListener() {
            @Override
            public void onLoadFinished(int state, Bitmap result) {
                if (state == UpdaterUtils.OnLoadListener.LOADIMAGE_SUCESS) {
                    if (mImageView.getParent() == null) {
                        clearActiveView();
                        addView(mImageView);
                    }

                    mImageView.setVisibility(VISIBLE);
                }
                if (mOnLoadImageListener != null) {
                    mOnLoadImageListener.onLoadFinished(state, result);
                }

                notifyListenerInMainThread(OnUpdateListener.UPDATE_FINISHED, OnUpdateListener.UPDATE_STATE_SUCCESS, "load image success, url=" + mUrl);
            }

            @Override
            public void onLoadError(int state, String errStr) {
                notifyListenerInMainThread(OnUpdateListener.UPDATE_FINISHED, OnUpdateListener.UPDATE_STATE_FAIL, errStr);
            }
        });

        ActiveUsageStatsUtils.recordEvent(mContext, ActiveUsageStatsUtils.EVENT_LOAD_IMAGE_FILE, "", "");
    }

    /**
     * Set the listener for loading image.
     *
     * @param listener The listener for loading image result.
     */
    public void setOnLoadImageListener(OnLoadImageListener listener) {
        mOnLoadImageListener = listener;
    }

    /**
     * Play video for the given url.
     *
     * @param url The video url.
     */
    public void downloadVideo(String url, int width, int height) {
        if (url == null || url.isEmpty() || (mUrl != null && mUrl.equals(url))) {
            LogUtil.e(LOG_TAG, "mUrl == url, don't update Video.");
            return;
        }

        mUrl = url;

        if (mSimpleVideoView == null) {
            mSimpleVideoView = new TextureVideoView(mContext);

            mSimpleVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    notifyListenerInMainThread(OnUpdateListener.UPDATE_VIDEO_STATE_COMPLETION, OnUpdateListener.UPDATE_STATE_SUCCESS, "Play video is completion, VideoFile=" + mUrl);
                }
            });

            mSimpleVideoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    notifyListenerInMainThread(OnUpdateListener.UPDATE_VIDEO_STATE_PREPARED, OnUpdateListener.UPDATE_STATE_SUCCESS, "Video is prepared, Url=" + mUrl + ", VideoFile=" + mUrl);
                }
            });

            mSimpleVideoView.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    notifyListenerInMainThread(OnUpdateListener.UPDATE_VIDEO_STATE_ONERROR, OnUpdateListener.UPDATE_STATE_SUCCESS, "MediaPlayer Error, what=" + what + ", extra=" + extra + ", VideoFile=" + mUrl);
                    return false;
                }
            });

            mSimpleVideoView.setOnInfoListener(new MediaPlayer.OnInfoListener() {
                @Override
                public boolean onInfo(MediaPlayer mp, int what, int extra) {
                    notifyListenerInMainThread(OnUpdateListener.UPDATE_VIDEO_STATE_ONINFO, OnUpdateListener.UPDATE_STATE_SUCCESS, "MediaPlayer Info, what=" + what + ", extra=" + extra + ", VideoFile=" + mUrl);
                    return false;
                }
            });

        } else {
            if (mSimpleVideoView.getParent() != null) {
                mSimpleVideoView.setVideoURI(Uri.parse(url));
                return;
            }
        }



        LayoutParams layoutParams;
        if (width != 0 && height != 0) {
            layoutParams = new LayoutParams(width, height);

        } else if (this.getMeasuredWidth() != 0 && this.getMeasuredHeight() != 0) {
            layoutParams = new LayoutParams(this.getMeasuredWidth(), this.getMeasuredHeight());
        } else {

            // layoutParams = new LayoutParams(Integer.parseInt(width1), Integer.parseInt(height1));
            layoutParams = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        }

        mSimpleVideoView.setLayoutParams(layoutParams);
        clearActiveView();
        addView(mSimpleVideoView);

        mSimpleVideoView.setVideoURI(Uri.parse(url));
    }

    /**
     * Download files for the given url.
     *
     * @param url The zip file url to get the resourc data.
     */
    public void downloadPackage(String url) {
        downloadPackage(url, null);
    }

    /**
     * Download files for the given url.
     *
     * @param url        The zip file url to get the resourc data.
     * @param listener   The listener for loading package. If it's not null, when load package resources finished, it will be called.
     */
    public void downloadPackage(String url, OnLoadImageListener listener) {
        if (url == null || url.isEmpty()) {
            // ignore the same url request.
            LogUtil.e(LOG_TAG, "mUrl == url, don't update Package.");
            return;
        }

        if (mUrl != null && mUrl.equals(url)) {

            notifyListenerInMainThread(OnUpdateListener.UPDATE_FINISHED, OnUpdateListener.UPDATE_STATE_SUCCESS, "Url Not Changed:" + mUrl);

            startAnimation();
            updateParallaxData();

            return;
        }

        cancelAllRunningTasks();

        // if need to update with new url, set now invisible.
        this.setVisibility(INVISIBLE);

        mUrl = url;

        if (listener != null) {
            mOnLoadImageListener = listener;
        }

        LogUtil.i(LOG_TAG, "mUrl =" + mUrl);
        String cachedDir = CacheUtils.getInstance(mContext).getSharePreferenceValue(mUrl);
        LogUtil.i(LOG_TAG, "cachedDir =" + cachedDir);
        if (cachedDir != null && !cachedDir.isEmpty()) {
            File cache = new File(cachedDir);
            if (cache.exists()) {
                LogUtil.e(LOG_TAG, "Don't download the same file. Load data from cachedDir=" + cachedDir);
                loadData(cachedDir, null);
                return;
            }
        }

        // create and execute download task.
        mbUseAssetsResources = false;

        LogUtil.i(LOG_TAG, "Begin download :" + url);
        mDownloadTask = FileDownloader.downloadFileAsync(url, mCacheDir, new OnDownloadListener() {
            @Override
            public void onDownloadStart(String url) {
            }

            @Override
            public void onDownloadError(int responseCode) {
                notifyListenerInMainThread(OnUpdateListener.UPDATE_DOWNLOAD, OnUpdateListener.UPDATE_STATE_FAIL, "Download file error! Error code=" + String.valueOf(responseCode));
            }

            @Override
            public void onDownloadFinished(int result, String file) {
                if (result == OnDownloadListener.DOWNLOAD_SUCESS) {
                    notifyListenerInMainThread(OnUpdateListener.UPDATE_DOWNLOAD, OnUpdateListener.UPDATE_STATE_SUCCESS, "Downloaded file=" + file);
                    extractZipFile(file);

                } else {
                    notifyListenerInMainThread(OnUpdateListener.UPDATE_DOWNLOAD, OnUpdateListener.UPDATE_STATE_FAIL, "Download fail. err=" + file);
                }
            }
        });

        ActiveUsageStatsUtils.recordEvent(mContext, ActiveUsageStatsUtils.EVENT_DOWNLOAD, "", "");
    }

    private void updateParallaxData() {
        if (mUseParallax && mOnParallaxListener != null && mParallaxData != null) {
            for (int i = 0; i < mParallaxData.size(); i++) {
                ParallaxData data = mParallaxData.get(i);
                if (data.mRange == null) {
                    mOnParallaxListener.onUpdateParallaxData(data.mView, null);
                } else {
                    mOnParallaxListener.onUpdateParallaxData(data.mView, data.mRange);
                }
            }
        }
    }

    /**
     * Get the name of zip file.
     *
     * @param fileWithPath the zip file maybe with path.
     */
    private String getDirNameByFile(String fileWithPath) {
        if (fileWithPath == null) {
            return null;
        }

        String[] splitArray = fileWithPath.split("/");
        String zipFileNoPath = splitArray[splitArray.length - 1];
        LogUtil.i(LOG_TAG, "zipFileName zipFile=" + zipFileNoPath);

        return zipFileNoPath.substring(0, zipFileNoPath.length() - 4);
    }

    /**
     * Get the Url this ActiveView using.
     */
    public String getUrl() {
        return mUrl;
    }

    /**
     * Do the zip file extract job.
     *
     * @param zipFile The zip file to be extracted.
     */
    private void extractZipFile(String zipFile) {
        String upzipToPath = mCacheDir + "/" + getDirNameByFile(zipFile);

        mZipExtractTask = ZipExtractor.extractFileAsync(zipFile, upzipToPath, getPassword(), new OnZipExtractListener() {
            @Override
            public void onExtractStart(String file) {
            }

            @Override
            public void onExtractError(String errStr) {
                notifyListenerInMainThread(OnUpdateListener.UPDATE_EXTRACT, OnUpdateListener.UPDATE_STATE_FAIL, errStr);
            }

            @Override
            public void onExtractFinished(int result, String extractedDir) {
                if (result == OnZipExtractListener.EXTRACT_SUCESS) {
                    notifyListenerInMainThread(OnUpdateListener.UPDATE_EXTRACT, OnUpdateListener.UPDATE_STATE_SUCCESS, "extracted dir=" + extractedDir);

                    loadData(extractedDir, null);
                    CacheUtils.getInstance(mContext).saveToSharedPreferences(mUrl, extractedDir);
                } else {
                    notifyListenerInMainThread(OnUpdateListener.UPDATE_EXTRACT, OnUpdateListener.UPDATE_STATE_FAIL, extractedDir);
                }
            }
        });

    }

    private void clearCacheFolder() {
        if (mCacheDir != null && mContext != null && mAutoDeleteFolder) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    CacheUtils.getInstance(mContext).clearCacheFolder(mCacheDir, mFolderHours);
                }
            }).start();
        } else {
            LogUtil.e(LOG_TAG, "clearCacheFolder ==mCacheDir=" + mCacheDir +", mContext=" + mContext + ", mAutoDeleteFolder=" + mAutoDeleteFolder);
        }
    }

    /**
     * Set the flag to control if auto delete the cache folder or not.
     * Default it is true, and will delete the folders exist more than 7 days.
     * @param autoDeleteFolder  The flag to set.
     */
    public void setAutoDeleteFolder(boolean autoDeleteFolder) {
        mAutoDeleteFolder = autoDeleteFolder;
    }

    /**
     * The folders which exist more than moreThanHour to be deleted.
     * @param moreThanHours  The hours.
     */
    public void setDeleteFolderTime(int moreThanHours) {
        mFolderHours = moreThanHours;
    }

    /**
     * Load ActiveView resource by given a act file.
     * @param actFile   The act filepath.
     */
    public void loadResourceFile(String actFile) {
        extractZipFile(actFile);
    }

    /**
     * Load ActiveView data with a load listener.
     *
     * @param listener The OnLoadDataListener is callback from LoadDataTask.
     */
    public void loadData(String zipExtractedPath, OnLoadDataListener listener) {
        LogUtil.i(LOG_TAG, "loadData() mbUseAssetsResources = " + mbUseAssetsResources);
        mZipExtractedDir = zipExtractedPath;
        final String filePath;
        if (mbUseAssetsResources) {
            filePath = Constants.ACTIVE_DIRECTORY_IN_ASSETS + Constants.JSON_FILE;
        } else {
            LogUtil.i(LOG_TAG, "loadData() mZipExtractedDir = " + mZipExtractedDir);
            if (mZipExtractedDir == null) {
                LogUtil.e(LOG_TAG, "loadData mZipExtractedDir is NULL");
                return;
            }
            if (mZipExtractedDir.endsWith("/")) {
                filePath = mZipExtractedDir + Constants.JSON_FILE;
            } else {
                filePath = mZipExtractedDir + "/" + Constants.JSON_FILE;
            }
        }

        mLoadDataTask = new LoadDataTask(mContext.getApplicationContext(), filePath, ActiveData.class, listener != null ? listener : new OnLoadDataListener() {
            @Override
            public <T> void onLoadDataResult(int result, T t) {
                if (result == OnLoadDataListener.LOAD_SUCESS) {
                    notifyListenerInMainThread(OnUpdateListener.UPDATE_LOADJSON, OnUpdateListener.UPDATE_STATE_SUCCESS, "load and parse json file success, file=" + filePath);
                    setData((ActiveData) t);

                } else {
                    notifyListenerInMainThread(OnUpdateListener.UPDATE_LOADJSON, OnUpdateListener.UPDATE_STATE_FAIL, "load and parse json file FAIL, file=" + filePath);
                }
            }
        }, mbUseAssetsResources);

        mLoadDataTask.execute();
    }

    /**
     * Load ActiveView data by given path of extracted directory.
     * It has data.jason and images under the directory.
     *
     * @param zipExtractedPath The directory of saved the files.
     */
    public void loadData(String zipExtractedPath) {
        if (zipExtractedPath != null) {
            loadData(zipExtractedPath, null);
        } else {
            LogUtil.e(LOG_TAG, "loadData zipExtractedPath is NULL");
        }
    }

    /**
     * Set ActiveData data to this ActiveView, it will be called after data.json is parsed.
     *
     * @param activeData The active data.
     */
    public void setData(final ActiveData activeData) {
        if (activeData == null) {
            LogUtil.e(LOG_TAG, "setData activeData is NULL!");
            return;
        }
        mVersionManager = VersionManager.getVersionManager(mContext);
        int checkVersionResult = mVersionManager.checkVersion(activeData);
        if (checkVersionResult == VersionManager.CUR_VERSION_LOWER_MIN) {
            LogUtil.e(LOG_TAG, "ActiveView version not Compatible ! Please upgrade ActiveView !");
            //
            if (mOnVersionListener != null) {
                mOnVersionListener.onVersionNotCompatible(Version.VERSION, activeData.getMiniCompatibleVersion());
            }

            notifyListenerInMainThread(OnUpdateListener.UPDATE_VERSION_COMPATIBALE, OnUpdateListener.UPDATE_STATE_FAIL, "VERSION_NOT_COMPATIBALE !");

        } else if (checkVersionResult == VersionManager.CUR_VERSION_LOWER && !mUpgradeChecked) {
            mActiveData = activeData;
            mVersionManager.addOnVersionChangedListener(this);
            mVersionManager.checkUpgradeVersion(activeData);
        } else {
            mActiveData = activeData;
            createViewsFromActiveData();
        }
    }

    @Override
    public void onVersionChanged(String curVersion, String jarFilePath) {
        mUpgradeChecked = true;
        if (mOnActiveViewUpgradeListener != null && !curVersion.equals(Version.VERSION)) {
            mOnActiveViewUpgradeListener.onUpgradeFinished(OnActiveViewUpgradeListener.UPGRADE_JAR_FILE_DOWNLOAD,
                    OnActiveViewUpgradeListener.UPGRADE_STATE_SUCCESS, jarFilePath);

            if (mOnUpdateListener != null) {//通知应用
                mOnUpdateListener.onUpdateFinished(OnUpdateListener.UPDATE_VERSION_COMPATIBALE, OnUpdateListener.UPDATE_STATE_SUCCESS, "ActiveView has been upgraded successfully!");
            }
        } else {
            createViewsFromActiveData();
        }

        post(new Runnable() {
            @Override
            public void run() {
                mVersionManager.removeOnVersionChangedListener(ActiveViewImpl.this);//VersionManager是单例，移除监听，避免内存泄露
            }
        });
    }

    /**
     * Get this ActiveView's version.
     */
    public String getVersion() {
        return Version.VERSION;
    }


    /**
     * Display the package from web.
     * @param webUrl     The web request url.
     */
    public void loadFromWeb(String webUrl) {
        loadFromWeb(webUrl, 0, 0);
    }

    public void loadFromWeb(String webUrl, int width, int height) {
        if (webUrl == null || webUrl.isEmpty()) {
            LogUtil.e(LOG_TAG, "webUrl");
            return;
        }

        if (mWebView == null) {
            mWebView = new WebView(mContext);
            WebSettings webSettings = mWebView .getSettings();
            webSettings.setJavaScriptEnabled(true);
        } else {
            if (mWebView.getParent() != null) {
                mWebView.loadUrl(webUrl);
                return;
            }
        }

        LayoutParams layoutParams;
        if (width == 0 && height == 0) {
            layoutParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        } else {
            layoutParams = new LayoutParams(width, height);
        }
        mWebView.setLayoutParams(layoutParams);
        clearActiveView();
        addView(mWebView);
        LogUtil.i(LOG_TAG, "webUrl=" + webUrl);
        mWebView.loadUrl(webUrl);
    }

    /**
     * Create views for ActiveView according to active info.
     */
    private void createViewsFromActiveData() {
        if (mActiveData == null || mActiveData.getContent() == null) {
            LogUtil.e(LOG_TAG, "mActiveInfo = " + mActiveData + ", mActiveInfo.getContent()=" + ((mActiveData != null) ? mActiveData.getContent() : null));
            return;
        }

        List<Page> pageList = mActiveData.getContent().getPages();
        if (pageList == null) {
            LogUtil.e(LOG_TAG, "pageList is NULL!");
            return;
        }
        int pageSize = pageList.size();
        if (pageSize > 0) {
            cancelLoadImage();
            mScaleRate = 1.0f;
            removeAllViews();
            stopAnimation();
            mTimelineMap.clear();
            if (mVideoViewMap != null) {
                mVideoViewMap.clear();
            }
            mTimeline = null;
            if (mParallaxData != null) {
                mParallaxData.clear();
                mParallaxData = null;
            }
            mShowAfterImagesLoaded = false;
            this.setVisibility(INVISIBLE);
        }

        FrameLayout frameLayout = null;

        for (int pageIndex = 0; pageIndex < pageSize; pageIndex++) {
            Page page = pageList.get(pageIndex);
            if (page != null) {
                frameLayout = new FrameLayout(mContext);

                mScaleRate = calScaleRate(page.getStyle().getWidthValue(mContext));
                LogUtil.i(LOG_TAG, "mMeasured = " + mMeasured + ", mScaleRate = " + mScaleRate);

                // set style.
                setStyleProperties(frameLayout, page.getStyle());

                if (!mMeasured) {
                    this.removeAllViews();
                    this.addView(frameLayout);

                    notifyListenerInMainThread(OnUpdateListener.UPDATE_READY_NOT_ADDED, OnUpdateListener.UPDATE_STATE_SUCCESS, "ActiveView is ready, but not added to a View. Url=" + mUrl);

                    return;
                }
                // set page's event.
                setEvent(frameLayout, null, page.getEvents());

                // create element in page.
                List<Element> elementsList = page.getElements();
                if (elementsList == null) {
                    LogUtil.e(LOG_TAG, "elementsList is NULL!");
                    return;
                }

                int elementSize = elementsList.size();
                LogUtil.i(LOG_TAG, "elementSize = " + elementSize);
                for (int i = 0; i < elementSize; i++) {
                    Element element = elementsList.get(i);
                    if (element == null) {
                        LogUtil.e(LOG_TAG, "element == null");
                        continue;
                    }

                    String elementType = element.getType();
                    if (elementType == null) {
                        LogUtil.e(LOG_TAG, "elementType == null");
                        continue;
                    }

                    LogUtil.i(LOG_TAG, "elementType =" + elementType);

                    if (elementType.equals(ELEMENT_IMAGE)) {
                        LogUtil.i(LOG_TAG, "Element[" + i + "]: ImageView is Created ! Id=" + element.getId() + ", url=" + element.getUrl());

                        ImageView iv = new ImageView(mContext);

                        // set element properties.
                        setElementProperties(iv, element, true);
                        setElementAnimation(iv, element.getAnimations());

                        // add this element to this ActiveView.
                        frameLayout.addView(iv);

                        ViewElementData data = new ViewElementData();
                        data.mView = iv;
                        data.mViewType = VIEW_IMAGEVIEW;
                        data.mElementData = element;
                        mViewElementCacheMap.put(element.getId(), data);

                    } else if (elementType.equals(ELEMENT_GIF)) {
                        GifMovieView gifMovieView = new GifMovieView(mContext);

                        // set element properties.
                        setElementProperties(gifMovieView, element, true);
                        setElementAnimation(gifMovieView, element.getAnimations());

                        frameLayout.addView(gifMovieView);

                        if (mGifMovieViewMap == null) {
                            mGifMovieViewMap = new HashMap<>();
                        }
                        mGifMovieViewMap.put(element.getId(), gifMovieView);

                    } else if (elementType.equals(ELEMENT_BUTTON)) {
                        LogUtil.i(LOG_TAG, "Element[" + i + "]: Button is Created ! elementSize");

                    } else if (elementType.equals(ELEMENT_VIDEO)) {
                        TextureVideoView simpleVideoView = new TextureVideoView(mContext);

                        setVideoViewAttrs(simpleVideoView, element);

                        setElementProperties(simpleVideoView, element, true);
                        setElementAnimation(simpleVideoView, element.getAnimations());

                        frameLayout.addView(simpleVideoView);

                        if (mVideoViewMap == null) {
                            mVideoViewMap = new HashMap<>();
                        }

                        mVideoViewMap.put(element.getId(), simpleVideoView);

                    } else if (elementType.equals(ELEMENT_TEXT)) {
                        TextView tv = new TextView(mContext);

                        setTextAttrs(tv, element);

                        setElementProperties(tv, element, true);
                        setElementAnimation(tv, element.getAnimations());

                        frameLayout.addView(tv);

                        ViewElementData data = new ViewElementData();
                        data.mView = tv;
                        data.mViewType = VIEW_TEXTVIEW;
                        data.mElementData = element;
                        mViewElementCacheMap.put(element.getId(), data);

                    } else if (elementType.equals(ELEMENT_PARTICLE)) {

                    } else if (elementType.equals(ELEMENT_PARTICLE2D)) {
                        Particle2DAttr particle2DAttr = element.getParticle2DAttr();
                        if (particle2DAttr != null) {
                            final ParticleView particleView = create2DParticleView(particle2DAttr);
                            setElementProperties(particleView, element, true);

                            setElementAnimation(particleView, element.getAnimations());

                            frameLayout.addView(particleView);

                            if (mGraphicsAnimViewMap == null) {
                                mGraphicsAnimViewMap = new HashMap<>();
                            }
                            mGraphicsAnimViewMap.put(element.getId(), particleView);

                            LogUtil.i(LOG_TAG, "particle2DAttr mGraphicsAnimViewMap=" + mGraphicsAnimViewMap.size());

                        } else {
                            LogUtil.e(LOG_TAG, "particle2DAttr is NULL !");
                        }
                    }
                }
            }
        }

        if (frameLayout != null) {
            this.addView(frameLayout);

            if (!mShowAfterImagesLoaded) {
                 this.setVisibility(VISIBLE);
                 startFirstAnimation();
            }
        } else {
            LogUtil.e(LOG_TAG, "ActiveView has no content!");
        }

        ActiveUsageStatsUtils.recordEvent(mContext, ActiveUsageStatsUtils.EVENT_LOAD_ACT_FILE, "", "");
    }


    private ParticleView create2DParticleView(Particle2DAttr particle2DAttr) {
        if (particle2DAttr == null) {
            return null;
        }

        Bundle bundle = new Bundle();
        bundle.putString(ParticleSystem.ATTR_CLASS_NAME, ParticleSystem.CLASS_NAME);   //必要属性
        bundle.putString(ParticleSystem.ATTR_ID, particle2DAttr.getId());

        Float[] position = particle2DAttr.getPositionValue(mContext);
        if (position != null) {
            bundle.putFloat(ParticleSystem.ATTR_X, position[0] / mScaleRate);
            bundle.putFloat(ParticleSystem.ATTR_Y, position[1] / mScaleRate);
        }

        Float[] offset = particle2DAttr.getOffsetValue(mContext);
        if (offset != null) {
            bundle.putFloat(ParticleSystem.ATTR_RANDOM_POS_X, offset[0] / mScaleRate);
            bundle.putFloat(ParticleSystem.ATTR_RANDOM_POS_Y, offset[1] / mScaleRate);
        }

        Float[] speed = particle2DAttr.getSpeedValue(mContext);
        if (speed != null) {
            bundle.putFloat(ParticleSystem.ATTR_SPEED_X, speed[0] / mScaleRate);
            bundle.putFloat(ParticleSystem.ATTR_SPEED_Y, speed[1] / mScaleRate);
        }

        Float[] randomSpeed = particle2DAttr.getRandomSpeedValue(mContext);
        if (randomSpeed != null) {
            bundle.putFloat(ParticleSystem.ATTR_RANDOM_SPEED_X, randomSpeed[0] / mScaleRate);
            bundle.putFloat(ParticleSystem.ATTR_RANDOM_SPEED_Y, randomSpeed[1] / mScaleRate);
        }

        if (particle2DAttr.getTransmitCycle() != null) {
            bundle.putInt(ParticleSystem.ATTR_TRANSMIT_CYCLE, particle2DAttr.getTransmitCycle());
        }

        if (particle2DAttr.getTransmitNum() != null) {
            bundle.putInt(ParticleSystem.ATTR_TRANSMIT_NUM, particle2DAttr.getTransmitNum());
        }

        if (particle2DAttr.getRegionRadiusValue(mContext) != null) {
            bundle.putFloat(ParticleSystem.ATTR_REGION_RADIUS, particle2DAttr.getRegionRadiusValue(mContext)  / mScaleRate);
        }

        if (particle2DAttr.getColors() != null) {
              bundle.putIntArray(ParticleSystem.ATTR_COLOR_LIST, particle2DAttr.getColors());
              // bundle.putIntArray(ParticleSystem.ATTR_COLOR_LIST, new int[]{Color.argb(40, 245, 245, 245), Color.argb(15, 245, 245, 245), Color.argb(5, 245, 245, 245)});  // 汽车尾气颜色效果
        }

        if (particle2DAttr.getType().equals("circle")) {
            bundle.putString(ParticleSystem.ATTR_TYPE, ParticleSystem.TYPE_CIRCLE);
        } else if (particle2DAttr.getType().equals("image")) {
            bundle.putString(ParticleSystem.ATTR_TYPE, ParticleSystem.TYPE_BITMAP);
            String path = mZipExtractedDir + "/" + particle2DAttr.getBitmapPath();
            LogUtil.i(LOG_TAG, "paticle image path = "+ path);
            bundle.putString(ParticleSystem.ATTR_BITMAP_PATH,  path);

        } else if (particle2DAttr.getType().equals("rect")) {
            bundle.putString(ParticleSystem.ATTR_TYPE, ParticleSystem.TYPE_RECT);
        }

        if (particle2DAttr.getWidthValues(mContext) != null) {
            float[] tempValues = particle2DAttr.getWidthValues(mContext);
            int size = tempValues.length;
            for (int i = 0; i < size; i++) {
                tempValues[i] = tempValues[i] / mScaleRate;
            }
            bundle.putFloatArray(ParticleSystem.ATTR_PARTICLE_WIDTH, tempValues);
        }

        if (particle2DAttr.getHeightValues(mContext) != null) {
            float[] tempValues = particle2DAttr.getHeightValues(mContext);
            int size = tempValues.length;
            for (int i = 0; i < size; i++) {
                tempValues[i] = tempValues[i] / mScaleRate;
            }
            bundle.putFloatArray(ParticleSystem.ATTR_PARTICLE_HEIGHT, tempValues);
        }


      // 参考参数
//        Bundle bundle = new Bundle();
//        bundle.putString(ParticleSystem.ATTR_CLASS_NAME, "ParticleSystem");   //必要属性
//        bundle.putString(ParticleSystem.ATTR_ID, "ID-12");
//        bundle.putFloat(ParticleSystem.ATTR_X, 500);
//        bundle.putFloat(ParticleSystem.ATTR_Y, 300);
//        bundle.putFloat(ParticleSystem.ATTR_RANDOM_POS_X, 15);
//        bundle.putFloat(ParticleSystem.ATTR_RANDOM_POS_Y, 10);
//        bundle.putFloat(ParticleSystem.ATTR_SPEED_Y, -100);
//        bundle.putFloat(ParticleSystem.ATTR_SPEED_X, -100);
//        bundle.putFloat(ParticleSystem.ATTR_RANDOM_SPEED_X, 40);
//        bundle.putFloat(ParticleSystem.ATTR_RANDOM_SPEED_Y, 30);
//        bundle.putIntArray(ParticleSystem.ATTR_COLOR_LIST, new int[]{Color.argb(255, 0, 150, 250), Color.argb(100, 100, 40, 10), Color.argb(0, 40, 10, 100)});
//        bundle.putString(ParticleSystem.ATTR_TYPE, ParticleSystem.TYPE_CIRCLE);
//        bundle.putFloatArray(ParticleSystem.ATTR_PARTICLE_WIDTH, new float[]{10, 50});
//        bundle.putFloatArray(ParticleSystem.ATTR_PARTICLE_HEIGHT, new float[]{10, 80});

        List<Bundle> renders = new ArrayList<>();
        renders.add(bundle);
        ParticleView particleView = new ParticleView(this.getContext(), null, renders);

        return particleView;
    }

    /**
     * Set this ActiveView's style.
     *
     * @param view  Which view's style to be set.
     * @param style The style will be set to the view.
     */
    private void setStyleProperties(View view, Style style) {
        if (view == null || style == null) {
            LogUtil.e(LOG_TAG, "view or style is NULL!");
            return;
        }

        view.setLayoutParams(new LayoutParams((int) (style.getWidthValue(mContext) / mScaleRate), (int) (style.getHeightValue(mContext) / mScaleRate)));
        LogUtil.i(LOG_TAG, "mScaleRate =" + mScaleRate + ", Style width=" + style.getWidthValue(mContext) + ", Style height" + style.getHeightValue(mContext) + "; Real width=" + (int) (style.getWidthValue(mContext) / mScaleRate) + ", Real height=" + (int) (style.getHeightValue(mContext) / mScaleRate));

        float radius = style.getRadiusValue();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            // set round corner
            setRoundCorner(view, radius);

        }
        view.setBackgroundColor(style.getBackgroundColorValue());

        mColorPrimary = style.getColorPrimary();
    }

    /**
     * Calculate the rate for elements's Equal scaling.
     *
     * @param styleWidth The width value from the style info. It is use to compute the scale rate.
     */
    private float calScaleRate(float styleWidth) {
        WindowManager wm = (WindowManager) mContext.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics metric = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(metric);
        int width = metric.widthPixels;

        // scale rate, relative to ActiveView's width.
        if (mMeasuredWidth != 0 && styleWidth != 0.0f) {
            return styleWidth / mMeasuredWidth;
        }

        return styleWidth / width;         // relative to screen width.
    }

    /**
     * Override this method to get the measured width of this ActiveView, we use the value to calculate the elements' scale rate.
     */
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int w = this.getMeasuredWidth();
        LogUtil.i(LOG_TAG, "onMeasure  getMeasuredWidth =" + w + ", mMeasuredWidth =" + mMeasuredWidth);
        if (mMeasuredWidth != w) {
            mMeasured = true;
            mMeasuredWidth = w;
            post(new Runnable() {
                @Override
                public void run() {
                    setData(mActiveData);
                }
            });
        }
    }

    /**
     * Set the initial value of element's properties.
     *
     * @param view        Which view's properties to be set.
     * @param elementData Which has the properties data to be set.
     */
    private void setElementProperties(View view, Element elementData, boolean isUpdate) {
        if (view == null || elementData == null) {
            LogUtil.e(LOG_TAG, "view or element is NULL!");
            return;
        }

        String elementType = elementData.getType();
        // set size.
        float[] rect = elementData.getRectRegion(mContext);

        LayoutParams rcp;
        if (elementData.getType().equals(ELEMENT_TEXT)) {
            rcp = new LayoutParams((int)(rect[2] / mScaleRate), LayoutParams.WRAP_CONTENT);
        } else {
            rcp = new LayoutParams((int) (rect[2] / mScaleRate), (int) (rect[3] / mScaleRate));
        }
        view.setLayoutParams(rcp);

        // set location.
        view.setTranslationX(rect[0] / mScaleRate);
        view.setTranslationY(rect[1] / mScaleRate);

        Parallax parallax = elementData.getParallax();
        if (parallax != null) {
            setParallax(view, parallax);
        } else {
            LogUtil.i(LOG_TAG, elementData.getId() + " don't set parallax!");
        }

        float radius = elementData.getRadiusValue(mContext);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            // set round corner
            setRoundCorner(view, radius);

        }
        Integer backgroundColor = elementData.getBackgroundColorValue();
        if (backgroundColor != null) {
            view.setBackgroundColor(backgroundColor);
        }

        // set scale.
        view.setScaleX(elementData.getScale2d()[0]);
        view.setScaleY(elementData.getScale2d()[1]);

        // set rotation around X, Y, Z axis.
        view.setRotationX(elementData.getRotate3d()[0]);
        view.setRotationY(elementData.getRotate3d()[1]);
        view.setRotation(elementData.getRotate3d()[2]);

        // set alpha.
        view.setAlpha((float) elementData.getOpacity() / 255);

        // set element's background image.
        if (isUpdate) {
            // set element's event.
            setEvent(view, elementData.getId(), elementData.getEvents());

            if (elementType.equals(ELEMENT_IMAGE)) {
                mShowAfterImagesLoaded = true;
                setBackgroundImage((ImageView)view, elementData.getUrl(), rect[2] / mScaleRate, rect[3] / mScaleRate);
            } else if (elementType.equals(ELEMENT_GIF)) {
                GifMovieView gifMovieView = (GifMovieView) view;
                if (gifMovieView != null) {
                    gifMovieView.setMovieResource(mZipExtractedDir + "/" + elementData.getUrl());
                }
            }
        }
    }

    private void setTextAttrs(TextView tv, Element elementData) {
        if (tv == null || elementData == null || elementData.getTextAttrs() == null) {
            LogUtil.e(LOG_TAG, "Don't set TextAttrs.");
            return;
        }

        tv.setIncludeFontPadding(false);

        TextAttrs textAttrs = elementData.getTextAttrs();

        if (textAttrs.getTextSizeValue(mContext) != null) {
            tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, textAttrs.getTextSizeValue(mContext) / mScaleRate);
        }

        if (textAttrs.getTextColor() != null) {
            tv.setTextColor(textAttrs.getTextColor());
        }

        if (textAttrs.getBackground() != null) {
            tv.setBackgroundColor(textAttrs.getBackground());
        }

        if (textAttrs.getOpacity() != null) {
            tv.setAlpha(textAttrs.getOpacity() / 255);
        }

        if (textAttrs.getMaxLines() != null) {
            tv.setMaxLines(textAttrs.getMaxLines());
        }

        if (textAttrs.getMaxLength() != null) {
            tv.setFilters(new InputFilter[] { new InputFilter.LengthFilter(textAttrs.getMaxLength()) });
        }

        if (textAttrs.getSingleLine() != null && textAttrs.getSingleLine()) {
            tv.setSingleLine();
        }

        String gravity = textAttrs.getGravity();
        if (gravity != null) {
            if (gravity.equals("center_vertical")) {
                tv.setGravity(Gravity.CENTER_VERTICAL);
            } else if (gravity.equals("center_horizontal")) {
                tv.setGravity(Gravity.CENTER_HORIZONTAL);
            } else if (gravity.equals("center")) {
                tv.setGravity(Gravity.CENTER);
            } else if (gravity.equals("top")) {
                tv.setGravity(Gravity.TOP);
            } else if (gravity.equals("bottom")) {
                tv.setGravity(Gravity.BOTTOM);
            } else if (gravity.equals("left")) {
                tv.setGravity(Gravity.LEFT);
            } else if (gravity.equals("right")) {
                tv.setGravity(Gravity.RIGHT);
            }
        }

        String textStyle = textAttrs.getTextStyle();
        int typeFaceStyle = Typeface.NORMAL;
        if (textStyle != null) {
            if (textStyle.equals("bold")) {
                typeFaceStyle = Typeface.BOLD;
            } else if (textStyle.equals("italic")) {
                typeFaceStyle = Typeface.ITALIC;
            } else if (textStyle.equals("bold_italic")) {
                typeFaceStyle = Typeface.BOLD_ITALIC;
            }
        }

        Typeface font = null;
        String fontFamily = textAttrs.getFontFamily();
        if (fontFamily != null && fontFamily.equals("Flyme")) {           // Flyme字体
            String fontStyle = textAttrs.getFontStyle();
            if (fontStyle != null) {
                if (fontStyle.equals("Medium")) {
                    font = Typeface.create("sans-serif-medium", typeFaceStyle);

                } else if (fontStyle.equals("Light") || fontStyle.equals("ExtraLight")) {
                    font = Typeface.create("Flyme-Light", typeFaceStyle);

                } else if (fontStyle.equals("Bold")) {
                    try {
                        font = Typeface.createFromFile("/system/fonts/DINPro-Bold.otf");
                        if (typeFaceStyle == Typeface.ITALIC) {
                            typeFaceStyle = Typeface.BOLD_ITALIC;
                        } else if (typeFaceStyle == Typeface.NORMAL) {
                            typeFaceStyle = Typeface.BOLD;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                } else {          // fontStyle.equals("Normal")
                    try {
                        font = Typeface.createFromFile("/system/fonts/DINPro-Regular.otf");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            if (font != null) {
                tv.setTypeface(font, typeFaceStyle);
            } else {
                tv.setTypeface(Typeface.DEFAULT, typeFaceStyle);
            }

        } else {
            tv.setTypeface(Typeface.DEFAULT, typeFaceStyle);
        }

        String ellipsStr = textAttrs.getEllipsize();   // maxLength属性会使ellipsize="end"属性失效。添加了maxLength不再会显示"..."
        if (ellipsStr != null) {
            TextUtils.TruncateAt ellipsize = TextUtils.TruncateAt.MIDDLE;
            if (ellipsStr.equals("end")) {
                ellipsize = TextUtils.TruncateAt.END;
            } else if (ellipsStr.equals("start")) {
                ellipsize = TextUtils.TruncateAt.START;
            } else if (ellipsStr.equals("marquee")) {
                ellipsize = TextUtils.TruncateAt.MARQUEE;
            }

            tv.setEllipsize(ellipsize);
        }

        if (textAttrs.getLineSpacingExtraValue(mContext) != null) {
            tv.setLineSpacing(textAttrs.getLineSpacingExtraValue(mContext) / mScaleRate, 1.0f);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (textAttrs.getLetterSpacingValue(mContext) != null) {
                tv.setLetterSpacing(textAttrs.getLetterSpacingValue(mContext) / mScaleRate);
            }
        }

        tv.setText(textAttrs.getText());
    }

    public void setTextContent(String id, String content) {
        if (mViewElementCacheMap.containsKey(id)) {
            ViewElementData viewElementData = mViewElementCacheMap.get(id);
            if (viewElementData.mViewType.equals(VIEW_TEXTVIEW)) {
                TextView tv = (TextView)viewElementData.mView;
                tv.setText(content);
            }
        }
    }

    /**
     * Set element's Round Corner.
     *
     * @param view     Which view's parallax to be set.
     * @param radius    The round corner radius .
     */
    private void setRoundCorner(View view, final float radius) {
        if (view == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            ViewOutlineProvider viewOutlineProvider = new ViewOutlineProvider() {
                @Override
                public void getOutline(View view, Outline outline) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                    }
                }
            };
            view.setOutlineProvider(viewOutlineProvider);
            view.setClipToOutline(true);
        }
    }

    /**
     * Set element's parallax info.
     *
     * @param view     Which view's parallax to be set.
     * @param parallax The parallax info.
     */
    private void setParallax(View view, Parallax parallax) {
        if (mParallaxData == null) {
            mParallaxData = new ArrayList<>();
        }
        ParallaxData data = new ParallaxData();
        data.mView = view;
        Parameter parameter = parallax.getParameter();
        if (parameter != null) {
            data.mRange = parameter.getRangeValue(mContext);
        }
        mParallaxData.add(data);
    }

    private void setVideoViewAttrs(TextureVideoView simpleVideoView, Element elementData) {
        if (simpleVideoView == null || elementData == null || elementData.getVideoAttr() == null) {
            LogUtil.e(LOG_TAG, "Don't set VideoAttrs.");
            return;
        }

        VideoAttr videoAttr = elementData.getVideoAttr();

        String srcPath = videoAttr.getSrc();
        if (srcPath != null) {
            simpleVideoView.setVideoPath(mZipExtractedDir + "/" + srcPath);
        }

        if (videoAttr.getAudio() != null) {
            simpleVideoView.setPlayAudio(videoAttr.getAudio());
        }

        if (videoAttr.getAutoPlay() != null) {
            simpleVideoView.setAutoPlay(videoAttr.getAutoPlay());
        }

        if (videoAttr.getLoop() != null) {
            simpleVideoView.setLooping(videoAttr.getLoop());
        }

        if (videoAttr.getStartTime() != null) {
            simpleVideoView.setStartPlayTime(videoAttr.getStartTime());
        }

        if (videoAttr.getIntervalDelay() != null) {
            simpleVideoView.setIntervalDelay(videoAttr.getIntervalDelay());
        }

        final String fileUri = simpleVideoView.getUri();
        simpleVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                notifyListenerInMainThread(OnUpdateListener.UPDATE_VIDEO_STATE_COMPLETION, OnUpdateListener.UPDATE_STATE_SUCCESS, "Play video is completion, VideoFile=" + fileUri);

            }
        });

        simpleVideoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                notifyListenerInMainThread(OnUpdateListener.UPDATE_VIDEO_STATE_PREPARED, OnUpdateListener.UPDATE_STATE_SUCCESS, "Video is prepared, Url=" + mUrl + ", VideoFile=" + fileUri);
            }
        });

        simpleVideoView.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                LogUtil.i(LOG_TAG, "VideoAttrs onError what= "+ what + ", extra=" + extra);
                notifyListenerInMainThread(OnUpdateListener.UPDATE_VIDEO_STATE_ONERROR, OnUpdateListener.UPDATE_STATE_SUCCESS, "MediaPlayer Error, what=" + what + ", extra=" + extra + ", VideoFile=" + fileUri);
                return false;
            }
        });

        simpleVideoView.setOnInfoListener(new MediaPlayer.OnInfoListener() {
            @Override
            public boolean onInfo(MediaPlayer mp, int what, int extra) {
                notifyListenerInMainThread(OnUpdateListener.UPDATE_VIDEO_STATE_ONINFO, OnUpdateListener.UPDATE_STATE_SUCCESS, "MediaPlayer Info, what=" + what + ", extra=" + extra + ", VideoFile=" + fileUri);

                return false;
            }
        });
    }

    /**
     * Set the element's animation.
     *
     * @param view       Which view's animation to be set.
     * @param animations The animations to be set.
     */
    private void setElementAnimation(View view, List<Animation> animations) {
        if (animations == null) {
            return;
        }

        // create Timeline for this element, every element has a timeline.
        Timeline timeline = null;
        ViewTweenItem viewTweenItem = null;

        // set timeline frame info.
        int animationFrameNum = animations.size();

        if (animationFrameNum > 0) {
            if (mTimeline == null) {
                mTimeline = new Timeline();
                mTimelineMap.put(ACTIVE_TIMELINE_KEY, mTimeline);
            }
            viewTweenItem = new BlurViewTweenItem(view);
            mTweenItemMap.put(view, viewTweenItem);
        }

        for (int i = 0; i < animationFrameNum; i++) {
            FrameStyle itemStyle = viewTweenItem.buildFrameStyle();
            Animation animationsFrame = animations.get(i);

            //when the animation is circulated, use a single timeline to handle it,
            if (animationsFrame.isRepeat()) {
                timeline = new Timeline();
                mTimelineMap.put(animationsFrame.getId(), timeline);
                timeline.setRepeatCount(animationsFrame.getRepeatCount());
                timeline.setRepeatMode(animationsFrame.getRepeatMode());
                timeline.setDelayTime(animationsFrame.getStartTime());
            } else {
                timeline = mTimeline;
            }

            if (animationsFrame.getTransform2dValue(mContext)[0] != null) {
                itemStyle.setPropertyValue(ViewTweenItem.LEFT, animationsFrame.getTransform2dValue(mContext)[0] / mScaleRate);
            }
            if (animationsFrame.getTransform2dValue(mContext)[1] != null) {
                itemStyle.setPropertyValue(ViewTweenItem.TOP, animationsFrame.getTransform2dValue(mContext)[1] / mScaleRate);
            }

            if (animationsFrame.getScale2d()[0] != null) {
                itemStyle.setPropertyValue(ViewTweenItem.SCALE_X, animationsFrame.getScale2d()[0]);
            }
            if (animationsFrame.getScale2d()[1] != null) {
                itemStyle.setPropertyValue(ViewTweenItem.SCALE_Y, animationsFrame.getScale2d()[0]);
            }

            if (animationsFrame.getRotate3d()[0] != null) {
                itemStyle.setPropertyValue(ViewTweenItem.ROTATION_X, animationsFrame.getRotate3d()[0]);
            }
            if (animationsFrame.getRotate3d()[1] != null) {
                itemStyle.setPropertyValue(ViewTweenItem.ROTATION_Y, animationsFrame.getRotate3d()[1]);
            }
            if (animationsFrame.getRotate3d()[2] != null) {
                itemStyle.setPropertyValue(ViewTweenItem.ROTATION, animationsFrame.getRotate3d()[2]);
            }

            if (animationsFrame.getOpacity() != null) {
                itemStyle.setPropertyValue(ViewTweenItem.ALPHA, (float) animationsFrame.getOpacity() / 255);
            }

            if (animationsFrame.getTrackPathValue(mContext) != null) {
                List<float[]> tempValues = animationsFrame.getTrackPathValue(mContext);
                int size = tempValues.size();
                for (int k = 0; k < size; k++) {
                    tempValues.get(k)[0] = tempValues.get(k)[0] / mScaleRate;
                    tempValues.get(k)[1] = tempValues.get(k)[1] / mScaleRate;
                }

                itemStyle.setPropertyValue(ViewTweenItem.TRACK_PATH, tempValues);
            }

            Interpolator interpolator = animationsFrame.getInterpolator();
            if (interpolator != null) {
                if (interpolator.getName().equals(INTERPOLATOR_TYPE_SHAKE)) {
                    Args args = interpolator.getArgs();
                    if (args != null) {
                        LogUtil.i(LOG_TAG, "Use Shake Frequency =" + args.getFrequency());
                        // use interpolator for shake animation.
                        if (animationsFrame.isRepeat()) {
                            timeline.to(viewTweenItem, animationsFrame.getDuration(), itemStyle, new CycleInterpolator(args.getFrequency()), 0, 0);
                        } else {
                            timeline.to(viewTweenItem, animationsFrame.getDuration(), itemStyle, new CycleInterpolator(args.getFrequency()), animationsFrame.getStartTime(), 0);
                        }
                    }
                } else if (interpolator.getName().equals(INTERPOLATOR_TYPE_LINEAR)) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        Args args = interpolator.getArgs();
                        PathInterpolator pathInterpolator;
                        if (args != null && args.getPath().length == 4) {
                            float[] path = args.getPath();
                            LogUtil.i(LOG_TAG, "Use PathInterpolator path =" + path[0] + ", " + path[1] + ", " + path[2] + ", " + path[3]);
                            pathInterpolator = new PathInterpolator(path[0], path[1], path[2], path[3]);
                        } else {
                            pathInterpolator = new PathInterpolator(0, 0, 1, 1);         // default: linear
                        }
                        if (animationsFrame.isRepeat()) {
                            timeline.to(viewTweenItem, animationsFrame.getDuration(), itemStyle, pathInterpolator, 0, 0);
                        } else {
                            timeline.to(viewTweenItem, animationsFrame.getDuration(), itemStyle, pathInterpolator, animationsFrame.getStartTime(), 0);
                        }
                    }
                }
            } else {
                LogUtil.i(LOG_TAG, "Use no Interpolator.");
                timeline.to(viewTweenItem, animationsFrame.getDuration(), itemStyle, animationsFrame.getStartTime(), 0);
            }
        }
    }

    /**
     * Set element background for given filePath asynchronously.
     *
     * @param view      Which view's background to be set.
     * @param filePath  The image file to be set to the view.
     * @param reqWidth  The real width of the view, it will be used to decide the image width when decoding the image file.
     * @param reqHeight The real height of the view, it will be used to decide the image height when decoding the image file.
     */
    private void setBackgroundImage(ImageView view, String filePath, float reqWidth, float reqHeight) {
        String imgPath;
        if (mbUseAssetsResources) {
            // set element's background image with image file in assests.
            imgPath = Constants.ACTIVE_DIRECTORY_IN_ASSETS + filePath;
        } else {
            // set element's background image with image file extracted from zip.
            imgPath = mZipExtractedDir + "/" + filePath;
        }

        if (mAsyncTaskListener == null) {
            mAsyncTaskListener = new AsyncTaskListener(this);
        }
        LoadImageTask loadImageTask = new LoadImageTask(mContext.getApplicationContext(), view, imgPath, mbUseAssetsResources, mAsyncTaskListener, reqWidth, reqHeight);
        loadImageTask.execute();
        mLoadImageTaskMap.put(loadImageTask, false);
    }

    /**
     * Record the load image task has finished. The ActiveView become visible and start animation only when all loading image is finished.
     *
     * @param asyncTask The task to be recorded.
     */
    private void setLoadImageFinished(AsyncTask asyncTask) {
        if (asyncTask.isCancelled()) {
            LogUtil.e(LOG_TAG, "LoadImageTask is cancelled.image=" + ((LoadImageTask)asyncTask).getImagePath());
            notifyListenerInMainThread(OnUpdateListener.UPDATE_LOAD_RESOURCES, OnUpdateListener.UPDATE_STATE_FAIL, "LoadImageTask is cancelled. image=" + ((LoadImageTask)asyncTask).getImagePath());

            return;       // 有图片加载失败, ActiveView就不展示.
        }

        mLoadImageTaskMap.put(asyncTask, true);
        if (!mLoadImageTaskMap.containsValue(false)) {
            notifyListenerInMainThread(OnUpdateListener.UPDATE_LOAD_RESOURCES, OnUpdateListener.UPDATE_STATE_SUCCESS, "url=" + mUrl);

            if (mMeasured) {
                this.setVisibility(VISIBLE);

                startFirstAnimation();

                if (mOnLoadImageListener != null) {
                    Bitmap bitmap = getActiveViewBitmap();
                    mOnLoadImageListener.onLoadFinished(OnLoadImageListener.LOADIMAGE_SUCESS, bitmap);
                }

                notifyListenerInMainThread(OnUpdateListener.UPDATE_FINISHED, OnUpdateListener.UPDATE_STATE_SUCCESS, "ActiveView is ready, and is added to a View. Url=" + mUrl);

                updateParallaxData();
            } else {
                notifyListenerInMainThread(OnUpdateListener.UPDATE_READY_NOT_ADDED, OnUpdateListener.UPDATE_STATE_SUCCESS, "ActiveView is ready, but not added to a View. Url=" + mUrl);
            }
        }
    }

    private void startFirstAnimation() {
        if (mAutoGradientDisplay && mAutpAlphaAnimation != null) {
            this.startAnimation(mAutpAlphaAnimation);

        } else {
            if (mAutoRunAnim) {
                startAnimation();
            }
        }
    }

    /**
     * Set the flag to control if auto run the animation when loading resources finished.
     * @param autoRunAnimation  The flag to set.
     */
    public void setAutoRunAnimation(boolean autoRunAnimation) {
        mAutoRunAnim = autoRunAnimation;
    }

    public void setAutoGradientDisplay(boolean autoGradientDisplay) {
        setAutoGradientDisplay(autoGradientDisplay, 800);
    }

    /**
     * Set the flag to control if auto use the gradient display animation when loading resources finished.
     * @param autoGradientDisplay  The flag to set.
     */
    public void setAutoGradientDisplay(boolean autoGradientDisplay, int duration) {
        mAutoGradientDisplay = autoGradientDisplay;
        mAutpAlphaAnimation = null;
        if (mAutoGradientDisplay) {
            mAutpAlphaAnimation = new AlphaAnimation(0, 1);
            mAutpAlphaAnimation.setDuration(duration);
            mAutpAlphaAnimation.setAnimationListener(new android.view.animation.Animation.AnimationListener() {
                @Override
                public void onAnimationStart(android.view.animation.Animation animation) {
                }

                @Override
                public void onAnimationEnd(android.view.animation.Animation animation) {
                    if (mAutoRunAnim) {
                        startAnimation();
                    }
                }

                @Override
                public void onAnimationRepeat(android.view.animation.Animation animation) {
                }
            });
        }
    }

    public Bitmap getActiveViewBitmap() {
        this.setDrawingCacheEnabled(true);
        this.buildDrawingCache();
        return this.getDrawingCache();
    }

    public void gotoAnimEnd() {
        if (mTimeline != null) {
            mTimeline.stop();
        }
    }

    public void gotoAnimStart() {
        if (mTimeline != null) {
            stopAnimation();
            mTimeline.setCurrentPlayTime(0);
        }
    }

    /**
     * Set ImageCache for the ActiveView. If set by app, it must be called before updateResource()
     *
     * @param imageCache  The cache used to cache image, it can be set by app.
     */
    public void setImageCache(ImageCache imageCache) {
        ImageCacheUtils.getInstance().setImageCache(imageCache);
    }

    public void clearImageCache() {
        ImageCacheUtils.getInstance().clearCache();
    }

    /**
     * Set event for view. The event will be sent to app if the OnEventListener is set.
     *
     * @param view  Which view's event to be set.
     * @param eId   The element's string id, it is correspond with view.
     * @param event The event list that this view will be listening.
     */
    private void setEvent(View view, final String eId, final List<Event> event) {
        if (view == null || event == null) {
            return;
        }
        int size = event.size();

        if (size == 0) {
            return;
        }

        for (int i = 0; i < size; i++) {
            final Event event1 = event.get(i);
            if (event1 == null) {
                continue;
            }

            EventHandler eventHandler = EventHandler.registerEventHandler(view, eId, event1);
            if (eventHandler != null) {
                eventHandler.setOnEventListener(mOnEventListener);
            }
        }
    }

    /**
     * Set OnEventListener.
     *
     * @param listener The listener set to the view as callback when event happened.
     */
    public void setOnEventListener(OnEventListener listener) {
        mOnEventListener = listener;
    }

    /**
     * Set OnVersionListener.
     *
     * @param listener The listener set to the ActiveView as callback when version changed.
     */
    public void setOnVersionListener(OnVersionListener listener) {
        mOnVersionListener = listener;
    }

    /**
     * Returns the visibility of this ActiveView.
     */
    public boolean isShowing() {
        return this.isShown();
    }

    /**
     * Start all timeline animation in this ActiveView.
     */
    public void startAnimation() {
        Collection<Timeline> timelines = mTimelineMap.values();
        Iterator iterator = timelines.iterator();
        while (iterator.hasNext()) {
            Timeline tl = (Timeline) iterator.next();
            if (tl != null) {
                tl.play();
            }
        }

        if (mGraphicsAnimViewMap != null) {
            Collection<ParticleView> particleViews = mGraphicsAnimViewMap.values();
            Iterator iterator2 = particleViews.iterator();
            while (iterator2.hasNext()) {
                ParticleView pv = (ParticleView) iterator2.next();
                if (pv != null) {
                    pv.start();
                }
            }
        }

        startGifAnim();

        startVideo();
    }

    /**
     * Stop all timeline animation in this ActiveView.
     */
    public void stopAnimation() {
        Collection<Timeline> timelines = mTimelineMap.values();
        Iterator iterator = timelines.iterator();
        while (iterator.hasNext()) {
            Timeline tl = (Timeline) iterator.next();
            if (tl != null) {
                tl.stop();
            }
        }

        if (mGraphicsAnimViewMap != null) {
            Collection<ParticleView> particleViews = mGraphicsAnimViewMap.values();
            Iterator iterator2 = particleViews.iterator();
            while (iterator2.hasNext()) {
                ParticleView pv = (ParticleView) iterator2.next();
                if (pv != null) {
                    pv.stop();
                }
            }
        }
        stopGifAnim();

        stopVideo();
    }

    /**
     * Pause all timeline animation in this ActiveView.
     */
    public void pauseAnimation() {
        Collection<Timeline> timelines = mTimelineMap.values();
        Iterator iterator = timelines.iterator();
        while (iterator.hasNext()) {
            Timeline tl = (Timeline) iterator.next();
            if (tl != null) {
                tl.pause();
            }
        }

        if (mGraphicsAnimViewMap != null) {
            Collection<ParticleView> particleViews = mGraphicsAnimViewMap.values();
            Iterator iterator2 = particleViews.iterator();
            while (iterator2.hasNext()) {
                ParticleView pv = (ParticleView) iterator2.next();
                if (pv != null) {
                    pv.pause();
                }
            }
        }
        pauseGifAnim();

        pauseVideo();
    }

    /**
     * Resume all timeline animation in this ActiveView.
     */
    public void resumeAnimation() {
        Collection<Timeline> timelines = mTimelineMap.values();
        Iterator iterator = timelines.iterator();
        while (iterator.hasNext()) {
            Timeline tl = (Timeline) iterator.next();
            if (tl != null && tl.isPaused()) {
                tl.resume();
            }
        }

        if (mGraphicsAnimViewMap != null) {
            Collection<ParticleView> particleViews = mGraphicsAnimViewMap.values();
            Iterator iterator2 = particleViews.iterator();
            while (iterator2.hasNext()) {
                ParticleView pv = (ParticleView) iterator2.next();
                if (pv != null) {
                    pv.resume();
                }
            }
        }
        resumeGifAnim();
        resumeVideo();
    }

    /**
     * Update some elements in this ActiveView, the update data is provided by the json the url pointing to.
     *
     * @param url The url point to the json.
     */
    private void updateData(String url) {
        updateData(url, null);
    }

    /**
     * Update some elements in this ActiveView, the update data is provided by the json the url pointing to.
     *
     * @param url         The url point to the json.
     * @param viewAdapter The adapter to provide views.
     */
    private void updateData(String url, final ViewAdapter viewAdapter) {
        if (url.isEmpty()) {
            return;
        }

        UpdaterUtils.getInstance(mContext).getJsonByUrl(url, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                LogUtil.e(LOG_TAG, "elementInfo: onResponse" + response.toString());

                JsonParser.parseJsonAsync(response.toString(), NewElementInfo.class, new OnJsonParserListener() {
                    @Override
                    public <T> void onParseResult(T t) {

                        NewElementInfo elementInfo = (NewElementInfo) t;
                        if (elementInfo == null) {
                            return;
                        }

                        // if viewAdapter is null, use the default adapter. The default adapter provide ImageView and TextView now.
                        updateData(elementInfo, viewAdapter != null ? viewAdapter : new ViewAdapter() {
                            @Override
                            public View getView(String viewType) {
                                if (viewType.equals(VIEW_TEXTVIEW)) {
                                    TextView textview = new TextView(mContext);
                                    textview.setTextSize(10);
                                    return textview;
                                } else if (viewType.equals(VIEW_IMAGEVIEW)) {
                                    ImageView imageView = new ImageView(mContext);
                                    return imageView;
                                }
                                return null;
                            }
                        });
                    }
                });
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });
    }

    public void cancelAllRunningTasks() {
        cancelDownload();
        cancelExtract();
        cancelLoadData();
        cancelLoadImage();
    }

    private void cancelLoadData() {
        if (mLoadDataTask != null) {
            mLoadDataTask.cancel(true);
        }
    }

    /**
     * Cancel all loading image tasks.
     */
    public void cancelLoadImage() {
        Set<AsyncTask> asyncTaskSet = mLoadImageTaskMap.keySet();
        Iterator<AsyncTask> it = asyncTaskSet.iterator();
        AsyncTask at;
        while (it.hasNext()) {
            at = it.next();
            if (at != null) {
                at.cancel(true);
            }
        }
        mLoadImageTaskMap.clear();
    }

    /**
     * Cancel download task.
     */
    public void cancelDownload() {
        if (mDownloadTask != null) {
            mDownloadTask.cancel(true);
        }
    }

    /**
     * Cancel extract task.
     */
    public void cancelExtract() {
        if (mZipExtractTask != null) {
            mZipExtractTask.cancel(true);
        }
    }

    /**
     * Pause video.
     */
    public void pauseVideo() {
        if (mSimpleVideoView != null) {
            mSimpleVideoView.pause();
        }

        if (mVideoViewMap != null) {
            Collection<TextureVideoView> simpleVideoViews = mVideoViewMap.values();
            Iterator iterator2 = simpleVideoViews.iterator();
            while (iterator2.hasNext()) {
                TextureVideoView sv = (TextureVideoView) iterator2.next();
                if (sv != null) {
                    sv.pause();
                }
            }
        }
    }

    /**
     * Resume video.
     */
    public void resumeVideo() {
        if (mSimpleVideoView != null) {
            mSimpleVideoView.start();
        }

        if (mVideoViewMap != null) {
            Collection<TextureVideoView> simpleVideoViews = mVideoViewMap.values();
            Iterator iterator2 = simpleVideoViews.iterator();
            while (iterator2.hasNext()) {
                TextureVideoView sv = (TextureVideoView) iterator2.next();
                if (sv != null) {
                    sv.start();
                }
            }
        }
    }

    /**
     * Start playing video.
     */
    public void startVideo() {
        if (mSimpleVideoView != null) {
            mSimpleVideoView.start();
        }

        if (mVideoViewMap != null) {
            Collection<TextureVideoView> simpleVideoViews = mVideoViewMap.values();
            Iterator iterator2 = simpleVideoViews.iterator();
            while (iterator2.hasNext()) {
                TextureVideoView sv = (TextureVideoView) iterator2.next();
                if (sv != null) {
                    sv.start();
                }
            }
        }
    }

    /**
     * Stop video playing.
     */
    public void stopVideo() {
        if (mSimpleVideoView != null) {
            mSimpleVideoView.pause();
        }

        if (mVideoViewMap != null) {
            Collection<TextureVideoView> simpleVideoViews = mVideoViewMap.values();
            Iterator iterator2 = simpleVideoViews.iterator();
            while (iterator2.hasNext()) {
                TextureVideoView sv = (TextureVideoView) iterator2.next();
                if (sv != null) {
                    sv.pause();
                }
            }
        }
    }

    private void startGifAnim() {
        if (mGifMovieViewMap != null) {
            Collection<GifMovieView> gifMovieViews = mGifMovieViewMap.values();
            Iterator iterator2 = gifMovieViews.iterator();
            while (iterator2.hasNext()) {
                GifMovieView gv = (GifMovieView) iterator2.next();
                if (gv != null) {
                    gv.start();
                }
            }
        }
    }

    private void stopGifAnim() {
        if (mGifMovieViewMap != null) {
            Collection<GifMovieView> gifMovieViews = mGifMovieViewMap.values();
            Iterator iterator2 = gifMovieViews.iterator();
            while (iterator2.hasNext()) {
                GifMovieView gv = (GifMovieView) iterator2.next();
                if (gv != null) {
                    gv.stop();
                }
            }
        }
    }

    private void pauseGifAnim() {
        if (mGifMovieViewMap != null) {
            Collection<GifMovieView> gifMovieViews = mGifMovieViewMap.values();
            Iterator iterator2 = gifMovieViews.iterator();
            while (iterator2.hasNext()) {
                GifMovieView gv = (GifMovieView) iterator2.next();
                if (gv != null) {
                    gv.pause();
                }
            }
        }
    }

    private void resumeGifAnim() {
        if (mGifMovieViewMap != null) {
            Collection<GifMovieView> gifMovieViews = mGifMovieViewMap.values();
            Iterator iterator2 = gifMovieViews.iterator();
            while (iterator2.hasNext()) {
                GifMovieView gv = (GifMovieView) iterator2.next();
                if (gv != null) {
                    gv.resume();
                }
            }
        }
    }

    /**
     * Update some elements with the new element info.
     *
     * @param newElementInfo The new element info from json.
     */
    private void updateData(NewElementInfo newElementInfo, ViewAdapter viewAdapter) {
        if (newElementInfo == null) {
            return;
        }

        updateElement(newElementInfo.getElements(), viewAdapter);
    }

    /**
     * Update view's image.
     *
     * @param v        The view to update.
     * @param imageUrl The image url to update.
     */
    private void updateImageView(ImageView v, String imageUrl) {
        if (v != null) {
            UpdaterUtils.getInstance(mContext).loadImage(v, imageUrl, 0, 0);
        }
    }

    /**
     * Update textview's text.
     *
     * @param v    The view to update.
     * @param text The image url to update.
     */
    private void updateTextView(TextView v, String text) {
        if (v != null) {
            v.setText(text);
        }
    }

    /**
     * If OnUpdateListener has been set, make sure onUpdateFinished is called in main thread.
     *
     * @param type
     * @param state
     * @param result
     */
    private void notifyListenerInMainThread(final int type, final int state, final String result) {
        if (mOnUpdateListener != null) {
            if (mMsgHandler == null) {
                mMsgHandler = new Handler(Looper.getMainLooper());
            }

            mMsgHandler.post(new Runnable() {
                @Override
                public void run() {
                    mOnUpdateListener.onUpdateFinished(type, state, result);
                }
            });
        }
    }

    /**
     * Update one element, its view type no changed.
     *
     * @param data The element data changed to.
     */
    private void updateElement(NewElementData data) {
        updateElement(data, null);
    }

    /**
     * Update one element, its view type maybe changed.
     *
     * @param newData The element data changed to.
     */
    private void updateElement(NewElementData newData, View newView) {
        if (newView == null) {
            String key = newData.getId();
            LogUtil.e(LOG_TAG, "elementInfo:  updateElement key=" + key);
            if (mViewElementCacheMap.containsKey(key)) {

                ViewElementData viewData = mViewElementCacheMap.get(key);
                LogUtil.e(LOG_TAG, "elementInfo:  containsKey, viewType=" + viewData.mViewType);
                if (viewData != null && newData.getData() != null) {
                    if (viewData.mViewType.equals(VIEW_IMAGEVIEW)) {
                        updateImageView((ImageView) viewData.mView, newData.getData().getUrl());
                    } else if (viewData.mViewType.equals(VIEW_TEXTVIEW)) {
                        updateTextView((TextView) viewData.mView, newData.getData().getText());
                    }
                }
                setEvent(viewData.mView, newData.getId(), newData.getEvents());
            }

        } else {
            // 用v替换mID指向的view.
            String key = newData.getId();
            LogUtil.e(LOG_TAG, "elementInfo:  updateElement key=" + key);
            if (mViewElementCacheMap.containsKey(key)) {

                ViewElementData oldViewData = mViewElementCacheMap.get(key);

                // set properties to the new view with the old data.
                setElementProperties(newView, oldViewData.mElementData, false);

                // replace the timeline animation target.
                ViewTweenItem viewTweenItem = mTweenItemMap.get(oldViewData.mView);
                if (viewTweenItem != null) {
                    viewTweenItem.setTarget(newView);
                    mTweenItemMap.remove(oldViewData.mView);
                    mTweenItemMap.put(newView, viewTweenItem);
                }

                // remove the old view and add the new view in the same place.
                ((FrameLayout) this.getChildAt(0)).removeView(oldViewData.mView);
                ((FrameLayout) this.getChildAt(0)).addView(newView);

                // cache the new view.
                ViewElementData cachedata = new ViewElementData();
                cachedata.mView = newView;
                cachedata.mViewType = newData.getType();
                cachedata.mElementData = oldViewData.mElementData;
                mViewElementCacheMap.put(newData.getId(), cachedata);

                if (newData != null && newData.getData() != null) {
                    if (newData.getType().equals(VIEW_IMAGEVIEW)) {
                        updateImageView((ImageView) newView, newData.getData().getUrl());
                    } else if (newData.getType().equals(VIEW_TEXTVIEW)) {
                        updateTextView((TextView) newView, newData.getData().getText());
                    }
                }
                setEvent(newView, newData.getId(), newData.getEvents());
            }
        }
    }

    /**
     * Update some elements at the same time, their view type maybe changed. If changed, view is provided by adapter.
     *
     * @param elementDatas The element data changed to.
     * @param viewAdapter  The adapter
     */
    private void updateElement(List<NewElementData> elementDatas, ViewAdapter viewAdapter) {
        if (elementDatas == null) {
            return;
        }

        int size = elementDatas.size();
        for (int i = 0; i < size; i++) {
            NewElementData data = elementDatas.get(i);
            if (data != null) {
                String newtype = data.getType();
                String oldType = mViewElementCacheMap.get(data.getId()).mViewType;
                updateElement(elementDatas.get(i), (newtype.equals(oldType) || viewAdapter == null) ? null : viewAdapter.getView(newtype));      //  view由客户端通过实现接口来提供.
            }
        }
    }

    /**
     * Update some elements at the same time, their view type no changed.
     *
     * @param elementDatas The element data changed to.
     */
    private void updateElement(List<NewElementData> elementDatas) {
        if (elementDatas == null) {
            return;
        }

        int size = elementDatas.size();
        for (int i = 0; i < size; i++) {
            updateElement(elementDatas.get(i));
        }
    }

    /**
     * A class for element info.
     */
    private class ViewElementData {
        View mView;                  // the element's view.
        String mViewType;            // the view's type string.
        Element mElementData;        // the element's data, including properties and animations info.
    }

    private class ParallaxData {
        View mView;
        Float[] mRange;
    }

    protected void setOnActiveViewUpgradeListener(OnActiveViewUpgradeListener onActiveViewUpgradeListener) {
        mOnActiveViewUpgradeListener = onActiveViewUpgradeListener;
    }

    @Override
    public void setFrameDelay(long time) {
        TimelineTicker.setFrameDelay(time);
    }

    private class AsyncTaskListener implements OnAsyncTaskListener {
        private ActiveViewImpl mActiveView;

        AsyncTaskListener(ActiveViewImpl bv) {
            mActiveView = bv;
        }

        @Override
        public void onLoadFinished(AsyncTask asyncTask) {
            if (mActiveView != null) {
                mActiveView.setLoadImageFinished(asyncTask);
            }
        }
    }
}
