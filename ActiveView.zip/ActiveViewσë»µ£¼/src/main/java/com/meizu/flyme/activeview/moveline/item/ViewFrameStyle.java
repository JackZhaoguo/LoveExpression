package com.meizu.flyme.activeview.moveline.item;

import android.graphics.Path;
import android.graphics.PathMeasure;
import android.util.Log;

import com.meizu.flyme.activeview.moveline.Config;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Created by suyouxiong on 2016/11/5.
 */
public class ViewFrameStyle implements FrameStyle {


    protected final Set<String> mToUpdateStyles;
    protected final Map<String, Object> mStyleValueMap;

    ViewFrameStyle() {
        mToUpdateStyles = new HashSet<>();
        mStyleValueMap = new HashMap<>();
    }


    public void setLeft(float left) {
        mStyleValueMap.put(ViewTweenItem.LEFT, left);
    }


    public void setTop(float top) {
        mStyleValueMap.put(ViewTweenItem.TOP, top);
    }

    public void setScaleY(float scaleY) {
        this.mStyleValueMap.put(ViewTweenItem.SCALE_Y, scaleY);
    }


    public void setScaleX(float scaleX) {
        this.mStyleValueMap.put(ViewTweenItem.SCALE_X, scaleX);
    }

    public void setRotationY(float rotationY) {
        this.mStyleValueMap.put(ViewTweenItem.ROTATION_Y, rotationY);
    }


    public void setRotationX(float rotationX) {
        this.mStyleValueMap.put(ViewTweenItem.ROTATION_X, rotationX);
    }


    public void setRotation(float rotation) {
        this.mStyleValueMap.put(ViewTweenItem.ROTATION, rotation);
    }

    public void setAlpha(float alpha) {
        if (alpha > 1f) alpha = 1f;
        else if (alpha < 0) alpha = 0f;
        mStyleValueMap.put(ViewTweenItem.ALPHA, alpha);
    }

    /**
     * 设置轨迹位置数据
     * @param trackPath
     */
    public void setTrackPath(List<float[]> trackPath) {
        //使用点数据构造贝赛尔曲线，并使用PathMeasure获取在曲线上的位置
        PathMeasure pathMeasure = buildPathMeasure(trackPath);
        if (pathMeasure != null) this.mStyleValueMap.put(ViewTweenItem.TRACK_PATH, pathMeasure);
    }

    private PathMeasure buildPathMeasure(List<float[]> trackPaths) {
        if (trackPaths == null || trackPaths.size() == 0) return null;
        Path path = new Path();
        float[] pointPrev = new float[2];
        for (int i = 0; i < trackPaths.size(); i += 1) {
            float[] point = trackPaths.get(i);
            if (i == 0) {
                path.moveTo(point[0], point[1]);
            } else {
                float cX = (point[0] + pointPrev[0]) / 2;
                float cY = (point[1] + pointPrev[1]) / 2;
                //控制点为上一个点，结束点为当前点和上一个点的中点，这样能尽可能和路径拟合
                path.quadTo(pointPrev[0], pointPrev[1], cX, cY);
                //path.lineTo(point[0], point[1]);
                if (i == trackPaths.size() - 1) {//最后一点
                    cX = (cX + point[0]) / 2;
                    cY = (cY + point[1]) / 2;
                    path.quadTo(cX, cY, point[0], point[1]);
                }
            }
            pointPrev = point;
        }
        return new PathMeasure(path, false);
    }

    @Override
    public Set<String> getUpdateProperties() {
        return mToUpdateStyles;
    }

    @Override
    public Object getPropertyValue(String propertyName) {
        return mStyleValueMap.get(propertyName);
    }

    @Override
    public PropertyValueType getPropertyValueType(String propertyName) {
        switch (propertyName) {
            case ViewTweenItem.LEFT:
            case ViewTweenItem.TOP:
            case ViewTweenItem.SCALE_X:
            case ViewTweenItem.SCALE_Y:
            case ViewTweenItem.ROTATION:
            case ViewTweenItem.ROTATION_X:
            case ViewTweenItem.ROTATION_Y:
            case ViewTweenItem.ALPHA:
                return PropertyValueType.FLOAT;
            case ViewTweenItem.TRACK_PATH:
                return PropertyValueType.OTHER;

        }
        return PropertyValueType.OTHER;
    }

    @Override
    public void setPropertyValue(String propertyName, Object value) {
        try {
            if (propertyName.equals(ViewTweenItem.LEFT)) {
                setLeft((Float) value);

            } else if (propertyName.equals(ViewTweenItem.TOP)) {
                setTop((Float) value);

            } else if (propertyName.equals(ViewTweenItem.SCALE_X)) {
                setScaleX((Float) value);

            } else if (propertyName.equals(ViewTweenItem.SCALE_Y)) {
                setScaleY((Float) value);

            } else if (propertyName.equals(ViewTweenItem.ROTATION_X)) {
                setRotationX((Float) value);

            } else if (propertyName.equals(ViewTweenItem.ROTATION_Y)) {
                setRotationY((Float) value);

            } else if (propertyName.equals(ViewTweenItem.ALPHA)) {
                setAlpha((Float) value);

            } else if (propertyName.equals(ViewTweenItem.ROTATION)) {
                setRotation((Float) value);
            } else if (propertyName.equals(ViewTweenItem.TRACK_PATH)) {
                setTrackPath((List<float[]>) value);
            }
        } catch (ClassCastException e) {
            Log.e(Config.MOVELINE_LOG_TAG, "the value type of the property " + propertyName + " is illegal:" + e.getMessage());
        }

        mToUpdateStyles.add(propertyName);

    }
}
