package com.meizu.flyme.activeview.listener;

/**
 * Called when a view has event.
 */
public interface OnVersionListener {
    /**
     * @param curVersion          The current version of this ActiveView.
     * @param requiredMiniVersion The new ActiveData required mini compatible version.
     */
    void onVersionNotCompatible(String curVersion, String requiredMiniVersion);
}