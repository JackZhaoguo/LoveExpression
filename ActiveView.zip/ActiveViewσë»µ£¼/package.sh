 #!/bin/bash
 #配置artifactory的用户信息，并临时修改使用打包专用的build.gradle脚本
localProp="local.properties" 
if [ ! -f "$localProp" ]; then 
    read -p "input user name:"  userName
    read -p "input password:"  password
    echo "meizu.artifactoryUser="$userName > "$localProp"
    echo "meizu.artifactoryPassword="$password >> "$localProp"
fi
    cat "$localProp"
    echo "如果用户名或密码错误导致无法上传，请删除local.properties文件再次运行本脚本"

mv build.gradle build.gradle.temp
mv build.gradle.package build.gradle

./gradlew clean
./gradlew upload

mv build.gradle build.gradle.package
mv build.gradle.temp build.gradle
