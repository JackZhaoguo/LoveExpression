package com.meizu.flyme.myandroidtestdemo;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;

/**
 * Created by meizu on 17/2/23.
 */
public class WaveDrawable extends AnimationDrawable {
    //图片的关键点阵对应的目标点阵
    private float[] mKeyPointVerts = null;
    private int mVCellNum = 0;
    private int mHcellNum = 0;
    private Paint mPaint = null;

    public WaveDrawable() {
        this(null);
    }

    public WaveDrawable(Bitmap orgBitmap) {
        super(orgBitmap);
        init();
    }


    int scale = 1;
    final Point[][] startPoints = new Point[][]{{new Point(0, 0), new Point(256 * scale, 0), new Point(512 * scale, 0)},
            {new Point(0, 256 * scale), new Point(256 * scale, 256 * scale), new Point(512 * scale, 256 * scale)},
            {new Point(0, 512 * scale), new Point(256 * scale, 512 * scale), new Point(512 * scale, 512 * scale)}};
    final Point[][] endPoints = new Point[][]{{new Point(0, 0), new Point(256, 0), new Point(512, 0)},
            {new Point(0, 256), new Point(394, 385), new Point(512, 256)},
            {new Point(0, 512), new Point(256, 512), new Point(512, 512)}};

    @Override
    public void setProgress(float fraction) {
        float[] verts = getKeyPointsVerts(startPoints, endPoints, 2, 2, fraction);
        try {
            setTargetKeyPoints(verts, 2, 2);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void init() {
        mPaint = new Paint();
        //bitmap进行滤波处理
        mPaint.setFilterBitmap(true);
        mPaint.setAntiAlias(true); //设置画笔边缘光滑，去掉锯齿
        mPaint.setColor(Color.BLUE);
        mPaint.setStrokeWidth(10);
        mPaint.setTextSize(40);
    }

//    @Override
//    public void draw(Canvas canvas) {
//        drawWave(mProcessingBitmap, canvas);
//    }
//
//    protected void drawWave(Bitmap bitmap, Canvas canvas) {
//        if (mKeyPointVerts != null) {
//            canvas.drawBitmapMesh(bitmap, mHcellNum, mVCellNum, mKeyPointVerts, 0, null, 0, null);
//        }
//    }

    @Override
    protected Bitmap getProgressedBitmap(Bitmap bitmap) {
        Bitmap localTempBitmap  = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_4444);

        mBufferCanvas.setBitmap(localTempBitmap);

        if (mKeyPointVerts != null) {
            mBufferCanvas.drawBitmapMesh(bitmap, mHcellNum, mVCellNum, mKeyPointVerts, 0, null, 0, null);
        } else {
            return bitmap;
        }

        return localTempBitmap;
    }

    /**
     * 确保该函数在initWave后调用， WaveImageView已经设置了drawable, 并且网格坐标点至少1行1列
     *
     * @param keyPointsVerts 设置网格关键坐标点数据
     * @param vCellNum       网格行数
     * @param hCellNum       网格列数
     */
    public void setTargetKeyPoints(float[] keyPointsVerts, int vCellNum, int hCellNum) throws Exception {
        mKeyPointVerts = keyPointsVerts;
        mVCellNum = vCellNum;
        mHcellNum = hCellNum;
        invalidateSelf();
    }


    /**
     * @param startPoints 协议中的开始网格状态的关键点坐标
     * @param endPoints   协议中的结束网格状态的关键点坐标
     * @param vCells      协议中的网格行数
     * @param hCells      协议中的网格列数
     * @param fraction    差值小数， 值为[0-1]
     * @return 返回setTargetKeyPoints 中使用的关键点格式的数据
     */
    public static float[] getKeyPointsVerts(Point[][] startPoints, Point[][] endPoints, int vCells, int hCells, float fraction) {
        float[] result = new float[2 * (vCells + 1) * (hCells + 1)];
        int index = 0;
        for (int i = 0; i <= vCells; i++) {
            for (int j = 0; j <= hCells; j++) {
                Point start = startPoints[i][j];
                Point end = endPoints[i][j];
                result[index * 2] = start.x + (end.x - start.x) * fraction;
                result[index * 2 + 1] = start.y + (end.y - start.y) * fraction;
                index++;
            }
        }
        return result;
    }
}
