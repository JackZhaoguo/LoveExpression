package com.meizu.flyme.myandroidtestdemo;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.util.Log;

/**
 * Created by meizu on 17/2/23.
 */
public class RoundImageDrawable extends Drawable implements Drawable.Callback {

    private Paint mPaint;
    private int mWidth;
    private Bitmap mBitmap ;

    private int mRealWidth;

    private int mViewHeight;
    private int mViewWidth;
    BitmapShader bitmapShader;

    public RoundImageDrawable(Bitmap bitmap)
    {
        mBitmap = bitmap ;

        bitmapShader = new BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        mPaint = new Paint();
        mPaint.setAntiAlias(true);
        mPaint.setShader(bitmapShader);

       // mWidth = Math.min(200, 450);
    }

    @Override
    public void draw(Canvas canvas)
    {
        canvas.drawCircle(mViewWidth / 2, mViewHeight / 2, mRealWidth / 2, mPaint);
    }

    /**
     * @param percent 时间插值
     */
    public void setPercent(float percent){
        mRealWidth = (int) (mWidth * percent);
        // 刷新 draw 图形
        invalidateSelf();
    }


    @Override
    protected void onBoundsChange(Rect bounds) {
        super.onBoundsChange(bounds);
        Log.e("TEST", "left=" + bounds.left + ", top=" + bounds.top + ", right" + bounds.right + ", bottom=" + bounds.bottom);
        mViewWidth = bounds.right - bounds.left;
        mViewHeight = bounds.bottom - bounds.top;
        mWidth = (int)Math.sqrt(Math.pow(Math.abs((double)(bounds.right - bounds.left)), 2) + Math.pow(Math.abs((double)(bounds.bottom - bounds.top)), 2));
    }

    @Override
    public int getIntrinsicWidth()
    {
        return -1;         // view的宽
    }

    @Override
    public int getIntrinsicHeight()
    {
        return -1;        // view的高
    }

    @Override
    public void setAlpha(int alpha)
    {
        mPaint.setAlpha(alpha);
    }

    @Override
    public void setColorFilter(ColorFilter cf)
    {
        mPaint.setColorFilter(cf);
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }


    @Override
    public void invalidateDrawable(Drawable who) {
        final Callback callback = getCallback();
        if (callback != null) {
            callback.invalidateDrawable(this);
        }
    }

    @Override
    public void scheduleDrawable(Drawable who, Runnable what, long when) {
        final Callback callback = getCallback();
        if (callback != null) {
            callback.scheduleDrawable(this, what, when);
        }
    }

    @Override
    public void unscheduleDrawable(Drawable who, Runnable what) {
        final Callback callback = getCallback();
        if (callback != null) {
            callback.unscheduleDrawable(this, what);
        }
    }
}
