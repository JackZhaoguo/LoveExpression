package com.meizu.flyme.myandroidtestdemo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;

/**
 * Created by meizu on 17/2/24.
 */
public class ActiveAnimationView extends ImageView {

    private ActiveDrawable mActiveDrawable = new ActiveDrawable();

    public ActiveAnimationView(Context context) {
        super(context);
    }

    @Override
    public void setImageDrawable(Drawable drawable) {
        BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
        if (bitmapDrawable != null) {
            mActiveDrawable.setBitmap(bitmapDrawable.getBitmap());
        }
        super.setImageDrawable(mActiveDrawable);
    }

    @Override
    public void setImageBitmap(Bitmap bm) {
        mActiveDrawable.setBitmap(bm);
        super.setImageDrawable(mActiveDrawable);
    }

    public void setActiveDrawable(ActiveDrawable activeDrawable) {
        mActiveDrawable = activeDrawable;
        super.setImageDrawable(mActiveDrawable);
    }

    public void addAnimDrawable(AnimationDrawable animationDrawable) {
        if (animationDrawable == null) {
            return;
        }
        mActiveDrawable.addDrawable(animationDrawable);
        super.setImageDrawable(mActiveDrawable);
    }

    public void setProgress(float fraction) {
        mActiveDrawable.setProgress(fraction);
    }
}
