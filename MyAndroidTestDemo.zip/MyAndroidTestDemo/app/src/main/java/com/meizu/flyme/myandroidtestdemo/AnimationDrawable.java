package com.meizu.flyme.myandroidtestdemo;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.Log;

/**
 * Created by meizu on 17/2/23.
 */
public abstract class AnimationDrawable extends Drawable implements Drawable.Callback  {

    protected Bitmap mOriBitmap;

    protected int mViewHeight;
    protected int mViewWidth;

    protected Canvas mBufferCanvas = new Canvas();

    public AnimationDrawable() {
        this(null);
    }

    public AnimationDrawable(Bitmap orgBitmap) {
        init(orgBitmap);
    }

    private void init(Bitmap orgBitmap) {
        if (orgBitmap == null) {
            return;
        }
        mOriBitmap = orgBitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        init(bitmap);
    }

    public Bitmap getBitmap() {
        return mOriBitmap;
    }

    public abstract void setProgress(float fraction);

    // subclass must return it's result bitmap.
    protected abstract Bitmap getProgressedBitmap(Bitmap bitmap);

    @Override
    protected void onBoundsChange(Rect bounds) {
        super.onBoundsChange(bounds);
        Log.e("TEST", "AnimationDrawable left=" + bounds.left + ", top=" + bounds.top + ", right" + bounds.right + ", bottom=" + bounds.bottom);
        mViewWidth = bounds.right - bounds.left;
        mViewHeight = bounds.bottom - bounds.top;
    }

    @Override
    public void draw(Canvas canvas) {
    }

    @Override
    public int getIntrinsicWidth() {
        return -1;         // view的宽
    }

    @Override
    public int getIntrinsicHeight() {
        return -1;        // view的高
    }

    @Override
    public void setAlpha(int alpha) {

    }

    @Override
    public void setColorFilter(ColorFilter cf) {

    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }

    @Override
    public void invalidateDrawable(Drawable who) {
        final Callback callback = getCallback();
        Log.e("TEST", "AnimationDrawable Callback=" + callback);
        if (callback != null) {
            callback.invalidateDrawable(this);
        }
    }

    @Override
    public void scheduleDrawable(Drawable who, Runnable what, long when) {
        final Callback callback = getCallback();
        if (callback != null) {
            callback.scheduleDrawable(this, what, when);
        }
    }

    @Override
    public void unscheduleDrawable(Drawable who, Runnable what) {
        final Callback callback = getCallback();
        if (callback != null) {
            callback.unscheduleDrawable(this, what);
        }
    }
}
