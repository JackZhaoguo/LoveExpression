package com.meizu.flyme.myandroidtestdemo;

import android.animation.ValueAnimator;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity {

    ActiveDrawable activeDrawable;
    ActiveAnimationView mImageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RelativeLayout relativeLayout = (RelativeLayout) findViewById(R.id.main_layout);
        relativeLayout.setBackgroundColor(0xffaa0000);

        final ImageView imageView2 = new ImageView(this);
        RelativeLayout.LayoutParams rcp2 = new RelativeLayout.LayoutParams(450, 450);
        imageView2.setBackgroundColor(0xff0000aa);
        imageView2.setLayoutParams(rcp2);


        mImageView = new ActiveAnimationView(this);
        RelativeLayout.LayoutParams rcp = new RelativeLayout.LayoutParams(450, 450);
        rcp.addRule(RelativeLayout.CENTER_IN_PARENT);
        mImageView.setLayoutParams(rcp);

        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);


//        final RoundImageDrawable roundImageDrawable = new RoundImageDrawable(bitmap);
//        imageView.setImageDrawable(roundImageDrawable);

        final ApertureDrawable apertureDrawable = new ApertureDrawable();
        final WaveDrawable waveDrawable = new WaveDrawable();

        int scale = 1;
        final Point[][] startPoints = new Point[][]{{new Point(0, 0), new Point(256 * scale, 0), new Point(512 * scale, 0)},
                {new Point(0, 256 * scale), new Point(256 * scale, 256 * scale), new Point(512 * scale, 256 * scale)},
                {new Point(0, 512 * scale), new Point(256 * scale, 512 * scale), new Point(512 * scale, 512 * scale)}};
        final Point[][] endPoints = new Point[][]{{new Point(0, 0), new Point(256, 0), new Point(512, 0)},
                {new Point(0, 256), new Point(394, 385), new Point(512, 256)},
                {new Point(0, 512), new Point(256, 512), new Point(512, 512)}};


        mImageView.setBackgroundColor(0xff00aaaa);

        // 用法1
//        activeDrawable = new ActiveDrawable(bitmap);
//        activeDrawable.addDrawable(waveDrawable);
//        activeDrawable.addDrawable(apertureDrawable);
//        mImageView.setActiveDrawable(activeDrawable);

        // 用法2
//        mImageView.setImageBitmap(bitmap);
//        mImageView.addAnimDrawable(waveDrawable);
//        mImageView.addAnimDrawable(apertureDrawable);

        // 用法3
        BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), bitmap);
        mImageView.setImageDrawable(bitmapDrawable);

        mImageView.addAnimDrawable(waveDrawable);
        mImageView.addAnimDrawable(apertureDrawable);


        relativeLayout.addView(mImageView);

        final ValueAnimator animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(6000);
        // animator.setRepeatCount(5);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator animation) {
                // roundImageDrawable.setPercent(((float) animation.getAnimatedValue()));
                // activeDrawable.setProgress((float) animation.getAnimatedValue());

                mImageView.setProgress((float) animation.getAnimatedValue());


            }
        });
        animator.start();
        // relativeLayout.addView(imageView2);

    }

    @Override
    protected void onResume() {
        super.onResume();
        mImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final ValueAnimator animator = ValueAnimator.ofFloat(0f, 1f);
                animator.setDuration(6000);
                animator.setRepeatCount(5);
                animator.setInterpolator(new LinearInterpolator());
                animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override public void onAnimationUpdate(ValueAnimator animation) {
                        // roundImageDrawable.setPercent(((float) animation.getAnimatedValue()));
                        activeDrawable.setProgress((float) animation.getAnimatedValue());


                    }
                });
                animator.start();
            }
        });
    }
}
