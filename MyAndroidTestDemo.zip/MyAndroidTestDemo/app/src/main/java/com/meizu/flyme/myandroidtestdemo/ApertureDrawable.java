package com.meizu.flyme.myandroidtestdemo;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Shader;
import android.util.Log;

/**
 * Created by meizu on 17/2/23.
 */
public class ApertureDrawable extends AnimationDrawable {

    private Paint mPaint;
    private int mRadiusValue;
    protected int mOriRadiusValue;

    public ApertureDrawable() {
        this(null);
    }

    public ApertureDrawable(Bitmap orgBitmap) {
        super(orgBitmap);
        init();
    }

    private void init() {
        mPaint = new Paint();
        mPaint.setAntiAlias(true);
    }

//    @Override
//    public void draw(Canvas canvas) {
//
////        canvas.drawCircle(mViewWidth / 2, mViewHeight / 2, mRadiusValue / 2, mPaint);
//
//        mPaint.setXfermode(null);
//
//        int canvasWidth = canvas.getWidth();
//        int canvasHeight = canvas.getHeight();
//        int layerId = canvas.saveLayer(0, 0, canvasWidth, canvasHeight, null, Canvas.ALL_SAVE_FLAG);
//        RectF rect = new RectF(0, 0, canvasWidth, canvasHeight); //设置宽高相等，（正方形)
//        mPaint.setColor(0xffffffff);
//        //　图片的格式可以这样设置
//        canvas.drawCircle(mViewWidth / 2, mViewHeight / 2, mRadiusValue / 2, mPaint);
//        //设置当两个图形相交时的模式，SRC_IN为取SRC图形相交的部分，多余的将被去掉
//        mPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
//        mPaint.setColor(0xFF66AAFF);
//
//        canvas.drawBitmap(mProcessingBitmap, null, rect, mPaint);
//        canvas.restoreToCount(layerId);
//    }

    @Override
    protected Bitmap getProgressedBitmap(Bitmap bitmap) {
        Bitmap localTempBitmap  = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_4444);

        mBufferCanvas.setBitmap(localTempBitmap);

        BitmapShader bitmapShader = new BitmapShader(bitmap, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        mPaint.setShader(bitmapShader);
        mBufferCanvas.drawCircle(mViewWidth / 2, mViewHeight / 2, mRadiusValue / 2, mPaint);
        mBufferCanvas.save(Canvas.ALL_SAVE_FLAG);
        mBufferCanvas.restore();

        return localTempBitmap;
    }

    /**
     * @param fraction 时间插值
     */
    @Override
    public void setProgress(float fraction) {
        mRadiusValue = (int) (mOriRadiusValue * fraction);
        // 刷新 draw 图形
        invalidateSelf();
    }

    @Override
    protected void onBoundsChange(Rect bounds) {
        super.onBoundsChange(bounds);
        mOriRadiusValue = (int)Math.sqrt(Math.pow(Math.abs(mViewWidth), 2) + Math.pow(Math.abs(mViewHeight), 2));
        Log.e("TEST", "ApertureDrawable mOriRadiusValue=" + mOriRadiusValue);
    }
}
