package com.meizu.flyme.myandroidtestdemo;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by meizu on 17/2/23.
 */
// 扮演LayerDrawable的角色,管理AnimatedDrawable数组

public class ActiveDrawable extends AnimationDrawable {

    final List<AnimationDrawable> mAnimationDrawables = new ArrayList<>();

    public ActiveDrawable() {
        this(null);
    }

    public ActiveDrawable(Bitmap orgBitmap) {
        super(orgBitmap);
    }

    Bitmap resultBitmap;

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
//        for (AnimationDrawable drawable : mAnimationDrawables) {
//            drawable.draw(canvas);
//        }

        if (resultBitmap != null && !mAnimationDrawables.isEmpty()) {
            resultBitmap.recycle();
        }
        resultBitmap = mOriBitmap;

        int size = mAnimationDrawables.size();
        for (int i = 0; i < size ; i++) {
            AnimationDrawable drawable = mAnimationDrawables.get(i);
            Bitmap tempResultBitmap = drawable.getProgressedBitmap(resultBitmap);
            if (i != 0 && i != size -1) {
                resultBitmap.recycle();
            }
            resultBitmap = tempResultBitmap;
        }

        canvas.drawBitmap(resultBitmap, 0, 0, new Paint());
    }

    protected Bitmap getProgressedBitmap(Bitmap bitmap) {
        return null;
    }

    @Override
    protected void onBoundsChange(Rect bounds) {
        super.onBoundsChange(bounds);
        for (AnimationDrawable drawable : mAnimationDrawables) {
            drawable.onBoundsChange(bounds);
        }
    }

    @Override
    public void setProgress(float fraction) {
        // super.setProgress(fraction);
        for (AnimationDrawable drawable : mAnimationDrawables) {
            drawable.setProgress(fraction);
        }
    }

    public void addDrawable(AnimationDrawable drawable) {
        if (drawable == null) {
            return;
        }

        drawable.setCallback(this);          // 将drawable的Callback设置为ActiveDrawable, 允许 Drawable 能够在需要重绘自己的时候告知 ActiveDrawable 重绘它.
        mAnimationDrawables.add(drawable);
    }

    @Override
    public void invalidateDrawable(Drawable who) {
        invalidateSelf();
    }
}
